#!/usr/bin/env bash
# Выкатка бота: тесты -> копирование -> сборка -> проверка логов -> откат при сбое.
# Использование: ./deploy.sh            (хост по умолчанию root@103.45.247.151)
#                DEPLOY_HOST=user@host ./deploy.sh
set -euo pipefail

HOST="${DEPLOY_HOST:-root@103.45.247.151}"
DIR="${DEPLOY_DIR:-/opt/chat-helper}"
cd "$(dirname "$0")"

echo "==> 1/5 тесты"
.venv/bin/pytest -q

echo "==> 2/5 запоминаю текущий образ для отката"
IMG=chat-helper-bot
if ssh "$HOST" "docker tag $IMG:latest $IMG:rollback" 2>/dev/null; then HAVE_PREV=1; else HAVE_PREV=0; fi

echo "==> 3/5 копирование и сборка"
COPYFILE_DISABLE=1 tar --exclude=.venv --exclude=.git --exclude=data --exclude=.env --exclude=__pycache__ \
  --exclude=.pytest_cache --exclude=.superpowers --exclude=tests --exclude=docs --exclude=.impeccable \
  --exclude=.DS_Store -czf - . \
  | ssh "$HOST" "cd $DIR && OLD=\$(md5sum Caddyfile 2>/dev/null); tar -xzf - -C $DIR; find $DIR -name '._*' -delete; docker compose up -d --build bot; [ \"\$OLD\" = \"\$(md5sum Caddyfile)\" ] || { echo 'Caddyfile изменился: перезапускаю caddy'; docker compose restart caddy; }"

echo "==> 4/5 жду запуск (до 60 с)"
ok=0
for _ in $(seq 1 12); do
  sleep 5
  logs=$(ssh "$HOST" "cd $DIR && docker compose logs bot --since 90s 2>&1" || true)
  if echo "$logs" | grep -q "Traceback\|Conflict"; then ok=0; break; fi
  if echo "$logs" | grep -q "Start polling\|webhook mode on"; then ok=1; break; fi   # polling или webhook
done

echo "==> 5/5 результат"
if [ "$ok" = 1 ]; then
  echo "OK: бот запущен, ошибок в логах нет"
  ssh "$HOST" "cd $DIR && docker compose ps bot"
  exit 0
fi

echo "СБОЙ: бот не поднялся чисто. Последние логи:" >&2
echo "$logs" | tail -25 >&2
if [ "$HAVE_PREV" = 1 ]; then
  echo "Откатываюсь на предыдущий образ..." >&2
  ssh "$HOST" "docker tag $IMG:rollback $IMG:latest && cd $DIR && docker compose up -d --no-build bot" >&2 || true
fi
exit 1

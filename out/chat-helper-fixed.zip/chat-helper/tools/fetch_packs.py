"""Скачивает снимки наборов премиум-эмодзи (getStickerSet) в tools/packs/extra/<имя>.json: пары [эмодзи, custom_emoji_id].

Токен бота берётся из BOT_TOKEN (переменная окружения или файл .env). Запуск из корня проекта:
    python tools/fetch_packs.py                    # все из tools/candidate_packs.txt
    python tools/fetch_packs.py имя1 имя2          # только эти
Дальше: python tools/pick_packs.py — выбрать наборы и дополнить bot/emoji_map.json."""
import json
import os
import sys
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "packs" / "extra"


def token() -> str:
    tok = os.environ.get("BOT_TOKEN", "")
    env = ROOT.parent / ".env"
    if not tok and env.exists():
        for line in env.read_text(encoding="utf-8").splitlines():
            if line.startswith("BOT_TOKEN="):
                tok = line.split("=", 1)[1].strip().strip('"\'')
    if not tok:
        sys.exit("Нужен BOT_TOKEN (переменная окружения или .env)")
    return tok


def names_from_file() -> list[str]:
    out = []
    for line in (ROOT / "candidate_packs.txt").read_text(encoding="utf-8").splitlines():
        line = line.split("#", 1)[0].strip()
        if line:
            out.append(line)
    return out


def fetch(tok: str, name: str) -> list[list[str]] | None:
    url = f"https://api.telegram.org/bot{tok}/getStickerSet?" + urllib.parse.urlencode({"name": name})
    try:
        with urllib.request.urlopen(url, timeout=30) as r:
            data = json.load(r)
    except Exception as e:                                       # набор удалён, нет сети и т. п.
        print(f"  {name}: не получилось ({type(e).__name__})")
        return None
    st = data["result"]["stickers"]
    return [[s.get("emoji") or "", s["custom_emoji_id"]] for s in st if s.get("custom_emoji_id")]


def main() -> None:
    tok = token()
    OUT.mkdir(parents=True, exist_ok=True)
    for name in (sys.argv[1:] or names_from_file()):
        pairs = fetch(tok, name)
        if pairs:
            (OUT / f"{name}.json").write_text(json.dumps(pairs, ensure_ascii=False), encoding="utf-8")
            print(f"  {name}: {len(pairs)} эмодзи, разных обычных: {len({e for e, _ in pairs if e})}")


if __name__ == "__main__":
    main()

"""Калибровка фильтра 18+ на ВАШИХ размеченных картинках (хранятся вне репозитория).

Использование:
    .venv/bin/python tools/nsfw_eval.py /путь/к/папке
В папке две подпапки: safe/ (обычные картинки) и nsfw/ (то, что фильтр должен ловить).
Скрипт считает оценку каждой картинки моделью бота и печатает точность/полноту по порогам
и рекомендованный порог. Картинки никуда не отправляются: модель работает локально.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bot.nsfw import NsfwDetector  # noqa: E402
from bot.nsfw_eval import recommend, sweep  # noqa: E402

EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}


def scores(det: NsfwDetector, folder: str) -> list[float]:
    out = []
    for name in sorted(os.listdir(folder)):
        if os.path.splitext(name)[1].lower() not in EXT:
            continue
        with open(os.path.join(folder, name), "rb") as f:
            try:
                out.append(det.score_image(f.read()))
            except Exception as e:  # битый файл не должен ломать весь прогон
                print(f"пропущен {name}: {e}", file=sys.stderr)
    return out


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    root = sys.argv[1]
    det = NsfwDetector()
    safe, nsfw = scores(det, os.path.join(root, "safe")), scores(det, os.path.join(root, "nsfw"))
    print(f"safe: {len(safe)} шт., nsfw: {len(nsfw)} шт.\n")
    print("порог  точность  полнота  ложных  пропущено")
    for r in sweep(safe, nsfw, range(10, 100, 5)):
        print(f"{r['threshold']:>5}  {r['precision']:.2f}      {r['recall']:.2f}     {r['fp']:>5}  {r['fn']:>9}")
    rec = recommend(safe, nsfw)
    print("\nРекомендация:", f"порог {rec['threshold']} (точность {rec['precision']:.2f}, полнота {rec['recall']:.2f})"
          if rec else "нет порога с точностью ≥ 0.95 — нужно больше примеров или модель сильнее")
    return 0


if __name__ == "__main__":
    sys.exit(main())

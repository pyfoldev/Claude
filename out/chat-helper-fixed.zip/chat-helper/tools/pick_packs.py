"""Подбор наборов: из снимков tools/packs/extra/*.json жадно выбирает наборы, которые закрывают больше всего ещё не покрытых
обычных эмодзи бота, и (с ключом --write) дополняет bot/emoji_map.json. Уже подобранное (основные наборы и ручной выбор) не
перезаписывается — только пустые места.

Запуск из корня проекта:  python tools/pick_packs.py            # отчёт: что будет и что останется без премиума
                          python tools/pick_packs.py --write    # дописать карту"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BOT = ROOT.parent / "bot"
VS16 = "️"
_EMOJI = re.compile("[\U0001F300-\U0001FAFF☀-➿⬀-⯿⌀-⏿■-◿©®‼⁉™ℹ]️?")


def norm(e: str) -> str:
    return e.replace(VS16, "")


def emoji_used_in_bot() -> set[str]:
    """Все обычные эмодзи, которые встречаются в коде бота (кроме служебных файлов и символов-стрелок)."""
    used: set[str] = set()
    for f in BOT.rglob("*.py"):
        if f.name in ("emoji_inject.py",) or f.name.startswith("i18n"):
            continue
        for m in _EMOJI.findall(f.read_text(encoding="utf-8")):
            e = norm(m)
            if ord(e[0]) >= 0x2000 or e in "©®":
                used.add(e)
    return used


def load_packs(folder: Path) -> dict[str, dict[str, str]]:
    """имя набора → {эмодзи: custom_emoji_id} (при повторах эмодзи берётся первый)."""
    out: dict[str, dict[str, str]] = {}
    for f in sorted(folder.glob("*.json")):
        pairs = json.loads(f.read_text(encoding="utf-8"))
        d: dict[str, str] = {}
        for e, cid in pairs:
            if e and cid:
                d.setdefault(norm(e), cid)
        out[f.stem] = d
    return out


def greedy(need: set[str], packs: dict[str, dict[str, str]]) -> list[tuple[str, set[str]]]:
    """Жадный выбор: на каждом шаге набор, закрывающий больше всего ещё не закрытых эмодзи. Без пользы наборы не берём."""
    left, plan = set(need), []
    while left:
        name, gain = max(((n, left & set(p)) for n, p in packs.items() if n not in {x for x, _ in plan}),
                         key=lambda x: (len(x[1]), x[0]), default=(None, set()))
        if not gain:
            break
        plan.append((name, gain))
        left -= gain
    return plan


def main() -> None:
    write = "--write" in sys.argv
    emap = json.loads((BOT / "emoji_map.json").read_text(encoding="utf-8"))
    packs = load_packs(ROOT / "packs" / "extra")
    if not packs:
        sys.exit("Нет снимков: сначала python tools/fetch_packs.py")
    need = {e for e in emoji_used_in_bot() if e not in emap}
    print(f"Эмодзи в боте без премиума: {len(need)}")
    plan = greedy(need, packs)
    covered: set[str] = set()
    for name, gain in plan:
        covered |= gain
        print(f"+ {name}: закрывает {len(gain)}  {' '.join(sorted(gain))}")
        if write:
            for e in gain:
                emap[e] = packs[name][e]
    rest = need - covered
    print(f"Закроется: {len(covered)} из {len(need)}. Останется без премиума: {len(rest)}  {' '.join(sorted(rest))}")
    if write:
        (BOT / "emoji_map.json").write_text(json.dumps(emap, ensure_ascii=False, indent=0, sort_keys=True), encoding="utf-8")
        print("bot/emoji_map.json обновлён")


if __name__ == "__main__":
    main()

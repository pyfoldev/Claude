#!/usr/bin/env bash
# Перенос бота с SQLite на PostgreSQL одной командой. Запускать НА СЕРВЕРЕ в папке с docker-compose.yml:
#     ./tools/to_postgres.sh
# Что делает: резервная копия SQLite -> поднимает PostgreSQL -> останавливает бота -> переносит данные с проверкой числа
# строк по каждой таблице -> прописывает DATABASE_URL в .env -> запускает бота. Откат: удалить строку DATABASE_URL
# из .env и выполнить `docker compose up -d bot` — бот вернётся на прежний файл SQLite (он не удаляется).
set -euo pipefail
cd "$(dirname "$0")/.."

[ -f .env ] || { echo "Нет файла .env" >&2; exit 1; }
if grep -q '^DATABASE_URL=postgres' .env; then echo "Бот уже работает на PostgreSQL (DATABASE_URL задан)."; exit 0; fi
SRC="${SQLITE_FILE:-data/bot.db}"
[ -f "$SRC" ] || { echo "Не найден файл SQLite: $SRC" >&2; exit 1; }

[ -z "$(tail -c1 .env)" ] || echo >> .env      # .env без перевода строки в конце
echo "==> 1/6 резервная копия SQLite"
mkdir -p data/backups
cp "$SRC" "data/backups/pre-postgres-$(date +%Y%m%d-%H%M%S).db"

echo "==> 2/6 пароль PostgreSQL"
if ! grep -q '^POSTGRES_PASSWORD=' .env; then
  echo "POSTGRES_PASSWORD=$(head -c 24 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 24)" >> .env
fi
PASS="$(grep '^POSTGRES_PASSWORD=' .env | cut -d= -f2-)"

echo "==> 3/6 запускаю PostgreSQL"
docker compose --profile pg up -d postgres
for _ in $(seq 1 30); do
  docker compose exec -T postgres pg_isready -U chat -d chat >/dev/null 2>&1 && break
  sleep 2
done
docker compose exec -T postgres pg_isready -U chat -d chat

echo "==> 4/6 останавливаю бота (чтобы данные не менялись во время переноса)"
docker compose stop bot

echo "==> 5/6 перенос данных"
URL="postgresql://chat:${PASS}@postgres:5432/chat"
docker compose run --rm --no-deps -v "$PWD/tools:/app/tools:ro" -v "$PWD/data:/data" -e DB_PATH=/data/bot.db bot \
  python tools/migrate_to_pg.py /data/bot.db "$URL"

echo "==> 6/6 переключаю бота на PostgreSQL"
echo "DATABASE_URL=${URL}" >> .env
docker compose up -d bot
echo "Готово. Проверка: docker compose logs bot --since 1m"

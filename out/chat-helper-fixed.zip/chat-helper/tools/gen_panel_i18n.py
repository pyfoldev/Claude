"""Пересобирает webapp/i18n.js (английский словарь веб-панели) из bot/i18n_en.py:  python tools/gen_panel_i18n.py"""
import json
import os
import sys

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root)
from bot.i18n_en import PANEL  # noqa: E402

body = r"""// Английский интерфейс веб-панели. Файл создаёт tools/gen_panel_i18n.py из bot/i18n_en.py — не правьте вручную.
"use strict";
const EN = %s;
const LANG = ((new URLSearchParams(location.search).get("lang")) || ((window.Telegram && Telegram.WebApp && Telegram.WebApp.initDataUnsafe && Telegram.WebApp.initDataUnsafe.user && Telegram.WebApp.initDataUnsafe.user.language_code) || "ru")).slice(0, 2).toLowerCase();
const RU_RE = /[А-Яа-яЁё]/;
const FRAGS = Object.keys(EN).sort((a, b) => b.length - a.length).map((k) => [new RegExp((/^[А-Яа-яЁё]/.test(k) ? "(?<![А-Яа-яЁё])" : "") + k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + (/[А-Яа-яЁё]$/.test(k) ? "(?![А-Яа-яЁё])" : ""), "g"), EN[k]]);
// tr: перевод строки интерфейса; слова не заменяются внутри других слов, непереведённое остаётся как есть
function tr(s) {
  if (LANG !== "en" || typeof s !== "string" || !RU_RE.test(s)) return s;
  if (Object.prototype.hasOwnProperty.call(EN, s)) return EN[s];
  let o = s;
  for (const [rx, v] of FRAGS) o = o.replace(rx, () => v);
  return o;
}
""" % json.dumps(PANEL, ensure_ascii=False, indent=0, sort_keys=True)
with open(os.path.join(root, "webapp", "i18n.js"), "w", encoding="utf-8") as f:
    f.write(body)
print("webapp/i18n.js:", len(PANEL), "фраз")

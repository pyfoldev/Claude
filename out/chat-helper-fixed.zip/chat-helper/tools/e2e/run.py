"""Сквозные проверки бота в тестовой группе «hiro chat» от лица ТЕСТОВОГО аккаунта (Telethon).

    .venv/bin/python tools/e2e/run.py                 # все сценарии
    .venv/bin/python tools/e2e/run.py --only filters links

Безопасность: трогаем только чат HIRO и тестовый аккаунт; настройки чата до прогона запоминаются и возвращаются,
ранг тестовому аккаунту выдаётся на время сценария и снимается. Результаты — .e2e/results.md."""
import argparse
import asyncio
import os
import re
import sys
import time
import traceback

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from tools.e2e.lib import E2E_DIR, HIRO, Bench, buttons, sql, texts  # noqa: E402

CACHE_WAIT = 11.5   # бот кэширует настройки чата на 10 секунд


class Ctx:
    def __init__(self, b: Bench):
        self.b = b
        self.me = b.me.id
        self.touched: set[str] = set()
        self.orig: dict[str, str | None] = {}

    # ---- настройки и ранги через БД (боевая, но только этот чат) ----
    def snapshot(self):
        rows = sql(f"select key||'='||value from settings where chat_id={HIRO}")
        self.snap = dict(line.split("=", 1) for line in rows.splitlines() if "=" in line)

    async def set_setting(self, key: str, value, wait: bool = True):
        self.touched.add(key)
        sql(f"insert into settings values({HIRO},'{key}','{value}') on conflict(chat_id,key) do update set value=excluded.value")
        if wait:
            await asyncio.sleep(CACHE_WAIT)

    def grant(self, rank: int):
        sql(f"insert into ranks values({HIRO},{self.me},{rank},{self.me},{int(time.time())}) "
            f"on conflict(chat_id,user_id) do update set rank=excluded.rank")

    def revoke(self):
        sql(f"delete from ranks where chat_id={HIRO} and user_id={self.me}")

    async def restore(self):
        self.revoke()
        for key in self.touched:
            if key in self.snap:
                sql(f"update settings set value='{self.snap[key]}' where chat_id={HIRO} and key='{key}'")
            else:
                sql(f"delete from settings where chat_id={HIRO} and key='{key}'")
        if self.touched:
            await asyncio.sleep(CACHE_WAIT)


class Fail(Exception):
    pass


def check(cond, msg):
    if not cond:
        raise Fail(msg)


# ---------- сценарии ----------

async def whoami(x: Ctx):
    _, r = await x.b.say("кто я")
    check(r and str(x.me) in texts(r), f"нет карточки с моим id: {texts(r)!r}")


async def stats_and_economy(x: Ctx):
    for cmd in ("стата", "баланс", "ферма"):
        _, r = await x.b.say(cmd)
        check(r, f"«{cmd}» без ответа")


async def fun_and_weather(x: Ctx):
    _, r = await x.b.say("монетка")
    check(r, "«монетка» без ответа")
    _, r = await x.b.say("!погода Москва", wait=10)
    check(r, "«!погода Москва» без ответа")


async def ai_ask(x: Ctx):
    _, r = await x.b.say("ии, ответь одним словом: да", wait=20, quiet=4)
    t = texts(r)
    check(r and "выключ" not in t.lower(), f"ИИ не ответил или выключен: {t!r}")


async def member_denials(x: Ctx):
    _, r = await x.b.say("мут")
    check(r and ("модератор" in texts(r).lower() or "ранг" in texts(r).lower() or "админ" in texts(r).lower()), f"«мут» не отказал участнику: {texts(r)!r}")
    for cmd in ("фильтры", "ссылки", "история", "веб-панель"):
        _, r = await x.b.say(cmd, wait=3, quiet=1.5)
        check(not r, f"«{cmd}» ответил участнику без ранга: {texts(r)!r}")


async def report_on_bot_refused(x: Ctx):
    sent, r = await x.b.say("кто я")
    _, r2 = await x.b.say("жалоба", reply_to=r[0].id if r else None)
    check(r2 and "нельзя" in texts(r2), f"жалоба на бота не отклонена: {texts(r2)!r}")


async def private_chat(x: Ctx):
    _, r = await x.b.say("/start", chat=x.b.bot)
    check(r, "/start в личке без ответа")
    _, r = await x.b.say("веб-панель", chat=x.b.bot)
    check(r, "«веб-панель» в личке без ответа")
    check(any((getattr(b.button, "url", "") or "").endswith("/panel") for b in buttons(r)), f"нет web_app-кнопки: {texts(r)!r}")
    _, r = await x.b.say(f"/start panel_{HIRO}", chat=x.b.bot)
    urls = [getattr(b.button, "url", "") or "" for b in buttons(r)]
    check(any(f"/panel?chat={HIRO}" in u for u in urls), f"нет кнопки панели чата: {urls}")
    _, r = await x.b.say("диагностика", chat=x.b.bot, wait=3, quiet=1.5)
    check("Диагностика бота" not in texts(r), "диагностика ушла не владельцу!")


async def filters(x: Ctx):
    b = x.b
    x.grant(4)
    _, r = await b.say("+фильтр тестстопслово")
    m = re.search(r"№(\d+)", texts(r))
    check(m, f"фильтр не добавлен: {texts(r)!r}")
    fid = m.group(1)
    try:
        x.revoke()                               # фильтры не трогают участников с рангом
        sent, r = await b.say("ну это тест тестстопслово же")
        await asyncio.sleep(1.5)
        check(not await b.exists(sent.id), "сообщение со стоп-словом не удалено")
        check("запрещённое слово" in texts(r), f"нет уведомления: {texts(r)!r}")
        sent, r = await b.say("обычное безобидное сообщение", wait=3, quiet=1.5)
        check(await b.exists(sent.id), "безобидное сообщение удалено")
    finally:
        x.grant(4)
        await b.say(f"-фильтр {fid}")
        x.revoke()


async def links_whitelist(x: Ctx):
    b = x.b
    await x.set_setting("spam_on", 1, wait=False)
    await x.set_setting("links_mode", "all")
    x.grant(4)
    domain = "evil-example.ru"
    try:
        x.revoke()
        sent, r = await b.say(f"зайди на {domain}")
        await asyncio.sleep(1.5)
        check(not await b.exists(sent.id), "ссылка не удалена при links_mode=all")
        x.grant(4)
        _, r = await b.say(f"+ссылка {domain}")
        check("разрешён" in texts(r), f"домен не добавлен: {texts(r)!r}")
        x.revoke()
        sent, r = await b.say(f"зайди на {domain}", wait=3, quiet=1.5)
        check(await b.exists(sent.id), "разрешённый домен удалён")
    finally:
        x.grant(4)
        await b.say(f"-ссылка {domain}")
        x.revoke()


async def antispam_flood(x: Ctx):
    b = x.b
    await x.set_setting("spam_on", 1)
    ids = []
    for i in range(7):
        m = await b.c.send_message(b.group, f"флуд-проверка {i}")
        ids.append(m.id)
        await asyncio.sleep(0.25)
    await asyncio.sleep(4)
    gone = [i for i in ids if not await b.exists(i)]
    check(gone, "ни одно из 7 быстрых сообщений не удалено антиспамом")


async def rank_commands(x: Ctx):
    b = x.b
    x.grant(1)
    try:
        _, r = await b.say(f"история {x.me}")
        check("История" in texts(r), f"нет карточки истории: {texts(r)!r}")
        _, r = await b.say("веб-панель")
        urls = [getattr(btn.button, "url", "") or "" for btn in buttons(r)]
        check(any("start=panel_" in u for u in urls), f"нет ссылки на панель: {texts(r)!r} {urls}")
    finally:
        x.revoke()


async def ai_moderation(x: Ctx):
    b = x.b
    await x.set_setting("ai_mod", "all", wait=False)
    await x.set_setting("ai_mod_action", "delete", wait=False)
    await x.set_setting("ai_mod_conf", "60")
    text = "Заработок на крипте без вложений! Гарантия прибыли, пиши в личку прямо сейчас, количество мест ограничено"
    sent, r = await b.say(text, wait=25, quiet=5)
    await asyncio.sleep(1)
    if await b.exists(sent.id):
        raise Fail("ИИ-модерация не удалила явный спам (модель ответила «ok» или не ответила) — смотрите логи бота")
    check("ИИ" in texts(r), f"нет уведомления ИИ-модерации: {texts(r)!r}")
    btn = next((q for q in buttons(r) if "ошибка" in (q.text or "").lower()), None)
    check(btn, "нет кнопки «Это ошибка»")
    x.grant(1)
    try:
        await btn.click()
        await asyncio.sleep(3)
        msgs = await b.c.get_messages(b.group, limit=6)
        check(any("восстановлен" in (m.raw_text or "") for m in msgs), "текст после «Это ошибка» не восстановлен")
    finally:
        x.revoke()


SCENARIOS = [whoami, stats_and_economy, fun_and_weather, ai_ask, member_denials, report_on_bot_refused, private_chat,
             filters, links_whitelist, antispam_flood, rank_commands, ai_moderation]


async def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*", help="имена сценариев")
    args = ap.parse_args()
    b = await Bench.open()
    x = Ctx(b)
    x.snapshot()
    print(f"Тестовый аккаунт: {b.me.first_name} (id {x.me}), группа: {getattr(b.group, 'title', HIRO)}")
    results = []
    try:
        for fn in SCENARIOS:
            if args.only and fn.__name__ not in args.only:
                continue
            t0 = time.time()
            try:
                await fn(x)
                results.append((fn.__name__, "OK", ""))
            except Fail as e:
                results.append((fn.__name__, "FAIL", str(e)))
            except Exception:
                results.append((fn.__name__, "ERROR", traceback.format_exc(limit=3)))
            print(f"{results[-1][1]:5} {fn.__name__} ({time.time() - t0:.0f} с) {results[-1][2][:160]}")
    finally:
        await x.restore()
        await b.close()
    os.makedirs(E2E_DIR, exist_ok=True)
    with open(os.path.join(E2E_DIR, "results.md"), "w", encoding="utf-8") as f:
        f.write("| сценарий | итог | подробности |\n|---|---|---|\n")
        for n, s, d in results:
            f.write(f"| {n} | {s} | {d.replace(chr(10), ' ')[:300]} |\n")
    return 0 if all(s == "OK" for _, s, _ in results) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))

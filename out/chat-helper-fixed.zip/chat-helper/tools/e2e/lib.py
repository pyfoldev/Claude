"""Помощники для сквозных проверок: клиент Telethon от лица тестового аккаунта и доступ к боевой БД по ssh (только свой чат)."""
import asyncio
import os
import subprocess
import time

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
E2E_DIR = os.path.join(ROOT, ".e2e")
SESSION = os.path.join(E2E_DIR, "test")
SERVER = os.environ.get("E2E_SERVER", "root@103.45.247.151")
BOT = "Noritgbot"
HIRO = -1004368636119          # тестовая группа «hiro chat»; другие чаты не трогаем


def load_env() -> dict:
    path = os.path.join(E2E_DIR, "env")
    if not os.path.exists(path):
        raise SystemExit("Нет .e2e/env — см. инструкцию в начале tools/e2e/login.py")
    env = {}
    for line in open(path, encoding="utf-8"):
        if "=" in line and not line.strip().startswith("#"):
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip()
    for k in ("TG_API_ID", "TG_API_HASH"):
        if not env.get(k):
            raise SystemExit(f"В .e2e/env не задан {k}")
    return env


def sql(query: str) -> str:
    """SQL к боевой PostgreSQL по ssh. Работаем только со строками HIRO и тестового аккаунта."""
    r = subprocess.run(["ssh", SERVER, "cd /opt/chat-helper && docker compose exec -T postgres psql -U chat -d chat -tA"],
                       input=query, capture_output=True, text=True, timeout=60)
    if r.returncode != 0:
        raise RuntimeError("sql: " + r.stderr.strip()[:300])
    return r.stdout.strip()


class Bench:
    def __init__(self, client, group, bot_entity, me):
        self.c, self.group, self.bot, self.me = client, group, bot_entity, me

    @classmethod
    async def open(cls):
        from telethon import TelegramClient
        env = load_env()
        client = TelegramClient(SESSION, int(env["TG_API_ID"]), env["TG_API_HASH"])
        await client.connect()
        if not await client.is_user_authorized():
            raise SystemExit("Сессия не авторизована: запустите tools/e2e/login.py")
        me = await client.get_me()
        group = await client.get_entity(HIRO)
        bot = await client.get_entity(BOT)
        return cls(client, group, bot, me)

    async def close(self):
        await self.c.disconnect()

    async def say(self, text: str, chat=None, reply_to=None, wait: float = 6.0, quiet: float = 2.0):
        """Отправить сообщение и собрать ответы бота: ждём до wait секунд, но не дольше quiet после последнего ответа."""
        chat = chat or self.group
        sent = await self.c.send_message(chat, text, reply_to=reply_to)
        got, deadline, last = [], time.time() + wait, None
        seen = set()
        while time.time() < deadline:
            await asyncio.sleep(0.5)
            msgs = await self.c.get_messages(chat, min_id=sent.id, limit=30)
            new = [m for m in msgs if m.sender_id == self.bot.id and m.id not in seen]
            for m in new:
                seen.add(m.id)
                got.append(m)
                last = time.time()
            if last and time.time() - last > quiet:
                break
        return sent, sorted(got, key=lambda m: m.id)

    async def exists(self, msg_id: int, chat=None) -> bool:
        m = await self.c.get_messages(chat or self.group, ids=msg_id)
        return m is not None and not getattr(m, "empty", False) and m.id == msg_id


def texts(msgs) -> str:
    return "\n".join((m.raw_text or "") for m in msgs)


def buttons(msgs) -> list:
    out = []
    for m in msgs:
        for row in (m.buttons or []):
            out.extend(row)
    return out

"""Одноразовый вход ТЕСТОВОГО аккаунта Telegram для сквозных проверок бота.

Запускает САМ ВЛАДЕЛЕЦ в своём терминале: номер, код из Telegram и (если включён) пароль 2FA вводятся только здесь.
Сессия сохраняется в .e2e/test.session на этом компьютере (папка в .gitignore) и больше нигде не хранится.

Подготовка:
  1. На https://my.telegram.org с ТЕСТОВЫМ аккаунтом: «API development tools» -> создать приложение -> api_id и api_hash.
  2. Создать файл .e2e/env (его никто не коммитит):
         TG_API_ID=1234567
         TG_API_HASH=0123456789abcdef0123456789abcdef
  3. Запустить:  .venv/bin/python tools/e2e/login.py
Выход из сессии: Telegram -> Настройки -> Устройства -> завершить сеанс (или удалить .e2e/test.session)."""
import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from tools.e2e.lib import E2E_DIR, SESSION, load_env  # noqa: E402


async def main() -> int:
    env = load_env()
    from telethon import TelegramClient
    os.makedirs(E2E_DIR, exist_ok=True)
    client = TelegramClient(SESSION, int(env["TG_API_ID"]), env["TG_API_HASH"])
    await client.start()   # спросит телефон, код и пароль прямо в терминале
    me = await client.get_me()
    print(f"\nВошли как: {me.first_name} (id {me.id}, @{me.username or 'без username'})")
    print("Это должен быть ТЕСТОВЫЙ аккаунт. Если нет — закройте сеанс в Telegram и удалите .e2e/test.session")
    await client.disconnect()
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))

"""Собирает bot/emoji_map.json: обычный эмодзи -> custom_emoji_id.

1) автоматически: эмодзи, привязанный к стикеру в наборе (solutions — приоритетнее, затем NewsEmoji, затем solutions_project_2);
2) поверх — ручной подбор по смыслу картинки из tools/emoji_choices.py (он важнее).

Запуск из корня проекта:  python tools/build_emoji_map.py
Снимки наборов лежат в tools/packs/*.json — это пары [эмодзи, custom_emoji_id] в порядке набора
(получить: метод Bot API getStickerSet, поля sticker.emoji и sticker.custom_emoji_id).
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from emoji_choices import CHOICES  # noqa: E402

ROOT = Path(__file__).resolve().parent
VS16 = "\ufe0f"


def norm(e: str) -> str:
    return e.replace(VS16, "")


def load(name: str) -> list:
    data = json.loads((ROOT / "packs" / name).read_text(encoding="utf-8"))
    return data["stickers"] if isinstance(data, dict) else data


def build() -> dict[str, str]:
    packs = {"sol": load("solutions.json"), "news": load("newsemoji.json"), "sol2": load("solutions2.json")}
    out: dict[str, str] = {}
    for tag in ("sol", "news", "sol2"):
        for emoji, cid in packs[tag]:
            if emoji and cid:
                out.setdefault(norm(emoji), cid)
    for emoji, (tag, idx) in CHOICES.items():
        out[norm(emoji)] = packs[tag][idx][1]
    return out


if __name__ == "__main__":
    m = build()
    (ROOT.parent / "bot" / "emoji_map.json").write_text(
        json.dumps(m, ensure_ascii=False, indent=0, sort_keys=True), encoding="utf-8")
    print(f"{len(m)} эмодзи в карте, из них подобрано вручную: {len(CHOICES)}")

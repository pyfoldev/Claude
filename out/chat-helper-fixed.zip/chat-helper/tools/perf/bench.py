"""Нагрузочный стенд: полный конвейер бота (middleware + все роутеры как в main.py) на фейковом Telegram.
Меряет сообщений/с и запросов к БД на сообщение для типичного потока группового чата."""
import asyncio, tempfile, cProfile, datetime as dt, pstats, sys, time, os
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path[:0] = [ROOT, ROOT + "/tests"]
os.chdir(ROOT)
import test_smoke as ts
from aiogram import Bot, Dispatcher
from aiogram.types import Message, Update, User
from bot.db import Database
from bot.middlewares.blocklist import BlockMiddleware
from bot.middlewares.counter import CounterMiddleware
from bot.middlewares.guard import GuardMiddleware
from bot.middlewares.memory import ChatMemoryMiddleware
from bot.middlewares.prefix import NoriPrefixMiddleware
from bot.middlewares.tracker import UserTrackerMiddleware
from bot.metrics import Metrics, MetricsMiddleware
from bot.runtime import Runtime

USERS = [User(id=100 + i, is_bot=False, first_name=f"U{i}", username=f"user{i}") for i in range(40)]
TEXTS = ["привет всем", "как дела у вас", "ахахах", "ну такое", "кто идёт гулять вечером?", "лол",
         "я вообще не понял что произошло", "го в кс", "скинь фотку", "ок", "бля реально", "завтра в 7"]

async def build(path, spam_on):
    db = await Database.connect(path)
    s = ts.FakeSession(); bot = Bot("123456:ABC", session=s)
    dp = Dispatcher(); rt = Runtime()
    for k, v in dict(db=db, webapp_url="https://x.test", ai=None, http=None, detector=None, owner_ids=frozenset({1}),
                     rt=rt, metrics=Metrics(), imagegen=None, downloader=None).items():
        dp[k] = v
    guard = GuardMiddleware(db, rt=rt)
    dp.update.outer_middleware(MetricsMiddleware(dp["metrics"]))
    dp.update.outer_middleware(BlockMiddleware(rt, frozenset({1}), guard))
    dp.update.outer_middleware(UserTrackerMiddleware(db))
    dp.message.outer_middleware(CounterMiddleware(db))
    dp.message.outer_middleware(guard)
    dp.message.outer_middleware(ChatMemoryMiddleware(db))
    dp.message.outer_middleware(NoriPrefixMiddleware())
    from bot import main as m  # noqa: только чтобы взять список роутеров
    routers = [r for r in m.__dict__.values() if hasattr(r, "router")]
    src = open(ROOT + "/bot/main.py").read()
    i = src.index("    for r in (owner_handlers.router"); j = src.index("):", i)
    names = [x.strip() for x in src[i + len("    for r in ("):j].replace("\n", " ").split(",") if x.strip()]
    for n in names:
        mod, _ = n.split(".")
        r = getattr(m, mod).router; r._parent_router = None; dp.include_router(r)
    if spam_on:
        await db.set_setting(-100, "spam_on", 1)
    return db, s, bot, dp

async def run(n, spam_on=False, profile=False):
    path = os.path.join(tempfile.gettempdir(), f"nori-bench-{int(spam_on)}.db")
    for p in (path, path + "-wal", path + "-shm"):
        if os.path.exists(p): os.remove(p)
    db, s, bot, dp = await build(path, spam_on)
    queries = {"n": 0}
    orig = db.conn.execute
    async def counted(*a, **k):
        queries["n"] += 1; return await orig(*a, **k)
    msgs = [Message(message_id=i + 1, date=dt.datetime.now(), chat=ts.CHAT, from_user=USERS[i % len(USERS)],
                    text=TEXTS[i % len(TEXTS)]) for i in range(n)]
    for m in msgs[:200]:   # прогрев кэшей
        await dp.feed_update(bot, Update(update_id=m.message_id, message=m))
    db.conn.execute = counted
    pr = cProfile.Profile() if profile else None
    t = time.perf_counter()
    if pr: pr.enable()
    for m in msgs[200:]:
        await dp.feed_update(bot, Update(update_id=m.message_id, message=m))
    if pr: pr.disable()
    dt_ = time.perf_counter() - t
    k = n - 200
    print(f"spam_on={spam_on}: {k/dt_:.0f} сообщ/с, {dt_/k*1000:.2f} мс/сообщ, {queries['n']/k:.2f} запросов к БД/сообщ, "
          f"API-вызовов к Telegram: {len(s.calls)}")
    if pr:
        pstats.Stats(pr).sort_stats("tottime").print_stats(22)
    await db.close()

if __name__ == "__main__":
    prof = "--profile" in sys.argv
    asyncio.run(run(3200, False, prof))
    asyncio.run(run(3200, True, False))

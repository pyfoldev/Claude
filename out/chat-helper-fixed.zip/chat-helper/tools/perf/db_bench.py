"""Запуск из корня проекта: .venv/bin/python tools/perf/db_bench.py
Тяжёлые запросы на большом чате: 200 участников, 90 дней почасовой истории (~430 тыс. строк)."""
import asyncio, tempfile, os, sys, time, random
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, ROOT)
from bot.db import Database, HOUR, DAY
PATH = os.path.join(tempfile.gettempdir(), "nori-bench-big.db")

async def seed():
    for p in (PATH, PATH + "-wal", PATH + "-shm"):
        if os.path.exists(p): os.remove(p)
    db = await Database.connect(PATH)
    now = int(time.time()) // HOUR * HOUR
    rnd = random.Random(1)
    rows = []
    for chat in (-100, -200, -300):          # три чата, меряем один
        for u in range(200):
            for h in range(0, 90 * 24, 1):
                if rnd.random() < 0.35:
                    rows.append((chat, 1000 + u, now - h * HOUR, rnd.randint(1, 9)))
    await db.conn.executemany("INSERT INTO msg_hourly VALUES(?,?,?,?)", rows)
    for chat in (-100, -200, -300):
        await db.conn.executemany("INSERT INTO chat_members(chat_id,user_id,first_seen,last_seen,joined_at,active) VALUES(?,?,?,?,?,1)",
                                  [(chat, 1000 + u, now - 80 * DAY, now - rnd.randint(0, 60) * DAY, now - 80 * DAY) for u in range(200)])
    await db.conn.commit()
    await db.optimize()                      # как раз в сутки делает бот
    print("строк в msg_hourly:", len(rows))
    return db

async def measure(db, label):
    now = int(time.time())
    tests = [("стата за сутки", lambda: db.count_by_user(-100, now - DAY)),
             ("стата за неделю", lambda: db.count_by_user(-100, now - 7 * DAY)),
             ("стата вся", lambda: db.count_by_user(-100, None)),
             ("кто неактив (last_messages)", lambda: db.last_messages(-100)),
             ("сообщения человека", lambda: db.user_total(-100, 1005, None)),
             ("график активности 30д", lambda: db.activity_series(-100, now - 30 * DAY, DAY))]
    print(f"--- {label}")
    for name, f in tests:
        await f()
        t = time.perf_counter()
        for _ in range(5):
            await f()
        print(f"{name:28} {(time.perf_counter() - t) / 5 * 1000:7.1f} мс")

async def main():
    db = await seed()
    await measure(db, "как сейчас")
    await db.close()
asyncio.run(main())

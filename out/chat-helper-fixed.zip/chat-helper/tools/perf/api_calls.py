"""Сколько запросов к Telegram API уходит на одну команду (каждый — сетевой круг ~50–200 мс)."""
import asyncio, tempfile, sys, os, collections, datetime as dt
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path[:0] = [ROOT, ROOT + "/tests", os.path.dirname(os.path.abspath(__file__))]
os.chdir(ROOT)
sys.argv = ["x"]
import bench
import test_smoke as ts
from aiogram.types import Message, Update

CMDS = [("стата", ts.VICTIM, None), ("мут", ts.ADMIN, "reply"), ("варн", ts.ADMIN, "reply"), ("кто админ", ts.VICTIM, None),
        ("+цитата", ts.VICTIM, "reply"), ("мог", ts.ADMIN, "reply"), ("жалоба", ts.VICTIM, "reply"), ("дк", ts.ADMIN, None),
        ("муты", ts.ADMIN, None), ("история", ts.ADMIN, "reply"), ("баланс", ts.VICTIM, None), ("правила", ts.VICTIM, None)]

async def main():
    path = os.path.join(tempfile.gettempdir(), "nori-bench-api.db")
    for p in (path, path + "-wal", path + "-shm"):
        if os.path.exists(p): os.remove(p)
    db, s, bot, dp = await bench.build(path, True)
    n = 0
    async def say(text, user, reply=None):
        nonlocal n; n += 1
        r = Message(message_id=5000 + n, date=dt.datetime.now(), chat=ts.CHAT, from_user=ts.PEER, text="x") if reply else None
        await dp.feed_update(bot, Update(update_id=n, message=Message(message_id=n, date=dt.datetime.now(), chat=ts.CHAT,
                                                                       from_user=user, text=text, reply_to_message=r)))
    await say("привет", ts.VICTIM); await say("привет", ts.PEER); await say("привет", ts.ADMIN)
    total = 0
    for rnd in (1, 2):
        for text, user, reply in CMDS:
            s.calls.clear()
            await say(text, user, reply)
            c = collections.Counter(type(x).__name__ for x in s.calls)
            reads = c.get("GetChatMember", 0) + c.get("GetChatAdministrators", 0) + c.get("GetChat", 0)
            total += reads
            if rnd == 2:
                print(f"{text:12} проверок прав/участника: {reads}  всего вызовов: {sum(c.values())}  {dict(c)}")
    print("ИТОГО запросов-проверок за 2 прогона:", total)
    await db.close()
asyncio.run(main())

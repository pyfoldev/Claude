"""Перенос данных бота из SQLite в PostgreSQL.

    .venv/bin/python tools/migrate_to_pg.py data/bot.db postgresql://chat:ПАРОЛЬ@postgres:5432/chat

Бот на время переноса должен быть остановлен (или в режиме обслуживания без записи), цель — пустая база.
Скрипт переносит все таблицы в одной транзакции и сверяет число строк; при расхождении откатывает.
"""
import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bot.migrate import MigrationError, migrate  # noqa: E402


async def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    try:
        report = await migrate(sys.argv[1], sys.argv[2])
    except MigrationError as e:
        print("ОТКАЗ:", e, file=sys.stderr)
        return 1
    for table, (src, dst) in sorted(report.items()):
        print(f"{table:20} {src:>8} -> {dst:>8}  {'ok' if src == dst else 'РАСХОЖДЕНИЕ'}")
    print("Готово: данные перенесены и сверены.")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))

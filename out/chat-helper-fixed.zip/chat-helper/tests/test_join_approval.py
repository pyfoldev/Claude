"""Заявку одобрил админ — капчи нет; время капчи настраивается."""
import asyncio
import time
from types import SimpleNamespace

import pytest

from bot import mod_service as ms
from bot.db import Database
from bot.handlers import captcha


def run(coro):
    return asyncio.run(coro)


class FakeBot:
    def __init__(self):
        self.calls = []

    async def me(self):
        return SimpleNamespace(id=999, username="helper_bot")

    async def get_chat_member(self, chat_id, user_id):
        return SimpleNamespace(status="creator" if user_id == 1 else "member")

    def __getattr__(self, name):
        async def call(*a, **kw):
            self.calls.append((name, a, kw))
            return SimpleNamespace(message_id=500, chat=SimpleNamespace(id=-100))
        return call

    def names(self):
        return [c[0] for c in self.calls]


USER = SimpleNamespace(id=7, is_bot=False, full_name="Вася", username="vasya", is_premium=False)


@pytest.fixture(autouse=True)
def _clean():
    captcha._handled.clear()
    captcha._passed.clear()
    ms._members.clear()
    yield


def member_event(approved_by, via=True, chat_id=-100):
    return SimpleNamespace(
        chat=SimpleNamespace(id=chat_id, type="supergroup"), via_join_request=via, from_user=SimpleNamespace(id=approved_by),
        new_chat_member=SimpleNamespace(user=USER, status="member"), old_chat_member=SimpleNamespace(status="left"))


def test_admin_approved_request_gets_no_captcha_and_pending_one_is_closed(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.set_setting(-100, "captcha_on", 1)
        await db.create_captcha("tok", -100, 7, "ABC", int(time.time()) + 100, 55, kind="join_request")
        bot = FakeBot()
        await captcha.on_join(member_event(approved_by=1), bot, db, "https://x.example")
        assert "restrict_chat_member" not in bot.names()                                   # не ограничиваем
        assert not [c for c in bot.calls if c[0] == "send_message" and "капч" in str(c).lower() and "Пройдите" in str(c)]
        assert await db.get_captcha_for_user(-100, 7) is None                              # висевшая капча закрыта
        assert "edit_message_text" in bot.names()                                          # человеку в личке сказали, что всё ок
        await db.close()
    run(go())


def test_request_approved_by_the_bot_itself_still_follows_the_old_path(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.set_setting(-100, "captcha_on", 1)
        captcha._passed[(-100, 7)] = time.time()                                           # бот одобрил после капчи
        bot = FakeBot()
        await captcha.on_join(member_event(approved_by=999), bot, db, "https://x.example")
        assert "restrict_chat_member" not in bot.names()
        await db.close()
    run(go())


def test_ordinary_join_still_gets_captcha(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.set_setting(-100, "captcha_on", 1)
        bot = FakeBot()
        await captcha.on_join(member_event(approved_by=7, via=False), bot, db, "https://x.example")
        assert "restrict_chat_member" in bot.names() and await db.get_captcha_for_user(-100, 7) is not None
        await db.close()
    run(go())


def test_service_message_path_detects_pending_request_captcha(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.set_setting(-100, "captcha_on", 1)
        await db.create_captcha("tok", -100, 7, "ABC", int(time.time()) + 100, 55, kind="guard")
        bot = FakeBot()
        msg = SimpleNamespace(chat=SimpleNamespace(id=-100, type="supergroup"), new_chat_members=[USER])
        await captcha.on_join_service(msg, bot, db, "https://x.example")
        assert "restrict_chat_member" not in bot.names() and await db.get_captcha_for_user(-100, 7) is None
        await db.close()
    run(go())


def test_parse_captcha_time_and_human_time():
    p, h = captcha.parse_captcha_time, captcha.human_time
    assert p("30м") == 1800 and p("45 мин") == 2700 and p("90с") == 90 and p("2ч") == 7200 and p("15") == 900
    assert p("10с") is None and p("48ч") is None and p("abc") is None
    assert h(1800) == "30 мин." and h(7200) == "2 ч." and h(90) == "1 мин. 30 сек." and h(45) == "45 сек."


def test_captcha_time_command(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot()
        out = []

        async def reply(t, **kw):
            out.append(t)
            return SimpleNamespace(chat=SimpleNamespace(id=-100), message_id=1)

        def msg(text, uid=1):
            return SimpleNamespace(chat=SimpleNamespace(id=-100, type="supergroup"), from_user=SimpleNamespace(id=uid),
                                   text=text, reply=reply, bot=bot, message_thread_id=None, is_topic_message=False)
        await captcha.captcha_time_cmd(msg("капча время"), bot, db)
        assert "3 мин." in out[-1]
        await captcha.captcha_time_cmd(msg("капча время 30м"), bot, db)
        assert (await db.get_settings(-100))["captcha_timeout"] == 1800 and "30 мин." in out[-1]
        await captcha.captcha_time_cmd(msg("капча время 5с"), bot, db)
        assert (await db.get_settings(-100))["captcha_timeout"] == 1800                    # вне диапазона — не меняется
        await captcha.captcha_time_cmd(msg("капча время 2ч", uid=7), bot, db)             # обычный участник
        assert (await db.get_settings(-100))["captcha_timeout"] == 1800
        await db.close()
    run(go())

"""Общее для тестов: потоки aiosqlite — демоны, чтобы упавший тест не вешал выход из pytest незакрытой базой."""
import aiosqlite

_orig = aiosqlite.Connection.__init__


def _init(self, *a, **kw):
    _orig(self, *a, **kw)
    self.daemon = True


aiosqlite.Connection.__init__ = _init

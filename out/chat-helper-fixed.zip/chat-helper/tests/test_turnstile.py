"""Капча на Cloudflare Turnstile (сеть Cloudflare подменена) и запасная капча с картинкой."""
import asyncio
import hashlib
import hmac
import json
import time
from types import SimpleNamespace
from urllib.parse import urlencode

import pytest
from aiohttp.test_utils import TestClient, TestServer

from bot import captcha_server as cs, ux
from bot.db import Database

TOKEN = "123:ABC"


def run(coro):
    return asyncio.run(coro)


def signed(user_id=7, age=0):
    data = {"auth_date": str(int(time.time()) - age), "user": json.dumps({"id": user_id, "first_name": "V"}), "query_id": "q"}
    dcs = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret = hmac.new(b"WebAppData", TOKEN.encode(), hashlib.sha256).digest()
    data["hash"] = hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest()
    return urlencode(data)


@pytest.fixture
def keys(monkeypatch):
    monkeypatch.setenv("TURNSTILE_SITEKEY", "0xSITE")
    monkeypatch.setenv("TURNSTILE_SECRET", "0xSECRET")


@pytest.fixture
def no_keys(monkeypatch):
    monkeypatch.delenv("TURNSTILE_SITEKEY", raising=False)
    monkeypatch.delenv("TURNSTILE_SECRET", raising=False)


async def env(tmp_path, answer="ABCDE"):
    db = await Database.connect(str(tmp_path / "t.db"))
    await db.create_captcha("tok1", -100, 7, answer, int(time.time()) + 600, 55, kind="member", level=0)
    passed = []

    async def on_pass(chat, user, mid, kind="member"):
        passed.append((chat, user, kind))
    client = TestClient(TestServer(cs.build_app(db, TOKEN, on_pass)))
    await client.start_server()
    return db, client, passed


def test_info_reports_turnstile_with_public_sitekey_and_cdata(tmp_path, keys):
    async def go():
        db, client, _ = await env(tmp_path)
        try:
            r = await client.get("/captcha/info?token=tok1", headers={"X-Init-Data": signed()})
            body = await r.json()
            assert body == {"mode": "turnstile", "sitekey": "0xSITE", "cdata": "tok1"}
            assert "0xSECRET" not in json.dumps(body)                                      # секрет наружу не уходит
            page = await client.get("/captcha")
            assert "challenges.cloudflare.com" in page.headers["Content-Security-Policy"]
            bad = await client.get("/captcha/info?token=tok1", headers={"X-Init-Data": signed(user_id=8)})
            assert bad.status == 403                                                       # чужой пользователь
        finally:
            await client.close()
            await db.close()
    run(go())


def test_verify_success_and_all_failure_modes(tmp_path, keys, monkeypatch):
    async def go():
        db, client, passed = await env(tmp_path)
        answers = iter([None, {"success": False}, {"success": True, "cdata": "other"}, {"success": True, "cdata": "tok1"}])
        seen = []

        async def fake(secret, response, remote_ip=None):
            seen.append((secret, response))
            return next(answers)
        monkeypatch.setattr(cs, "verify_turnstile", fake)

        async def post(**extra):
            r = await client.post("/captcha/verify", json={"token": "tok1", "initData": signed(), **extra})
            return await r.json()
        try:
            assert (await post(turnstile="t1"))["error"] == "network"                    # сеть Cloudflare недоступна
            assert (await post(turnstile="t2")) == {"ok": False}                          # Cloudflare сказал «нет»
            assert (await post(turnstile="t3")) == {"ok": False}                          # токен выдан для другой капчи (cdata)
            assert not passed and await db.get_captcha("tok1") is not None
            assert (await post(answer="ABCDE")) == {"ok": False}                          # код с картинки при Turnstile не принимается
            assert (await post(turnstile="t4")) == {"ok": True}
            assert passed == [(-100, 7, "member")] and await db.get_captcha("tok1") is None  # одноразовая
            assert seen[0] == ("0xSECRET", "t1")
            assert (await post(turnstile="t5")) == {"ok": False}                          # повторно — нет
        finally:
            await client.close()
            await db.close()
    run(go())


def test_verify_attempt_limit_and_bad_input(tmp_path, keys, monkeypatch):
    async def go():
        db, client, passed = await env(tmp_path)

        async def fake(secret, response, remote_ip=None):
            return {"success": False}
        monkeypatch.setattr(cs, "verify_turnstile", fake)
        try:
            for _ in range(cs.TURNSTILE_ATTEMPTS):
                r = await client.post("/captcha/verify", json={"token": "tok1", "initData": signed(), "turnstile": "x"})
                assert (await r.json()) == {"ok": False}
            r = await client.post("/captcha/verify", json={"token": "tok1", "initData": signed(), "turnstile": "x"})
            assert (await r.json()).get("error") == "attempts"                            # лимит попыток
            r = await client.post("/captcha/verify", json={"token": "tok1", "initData": signed()})   # без токена Cloudflare
            assert (await r.json()) == {"ok": False}
            r = await client.post("/captcha/verify", json={"token": "tok1", "initData": "bad", "turnstile": "x"})
            assert (await r.json()) == {"ok": False} and not passed
        finally:
            await client.close()
            await db.close()
    run(go())


def test_old_image_captcha_still_works_without_keys(tmp_path, no_keys):
    async def go():
        db, client, passed = await env(tmp_path, answer="ABCDE")
        try:
            info = await (await client.get("/captcha/info?token=tok1", headers={"X-Init-Data": signed()})).json()
            assert info == {"mode": "image"}
            assert "challenges.cloudflare.com" not in (await client.get("/captcha")).headers["Content-Security-Policy"]
            r = await client.post("/captcha/verify", json={"token": "tok1", "initData": signed(), "answer": "WRONG"})
            assert (await r.json()) == {"ok": False}
            r = await client.post("/captcha/verify", json={"token": "tok1", "initData": signed(), "answer": "abcde"})
            assert (await r.json()) == {"ok": True} and passed
        finally:
            await client.close()
            await db.close()
    run(go())


def test_initdata_older_than_five_minutes_is_accepted_for_captcha(tmp_path, keys):
    async def go():
        db, client, _ = await env(tmp_path)
        try:
            r = await client.get("/captcha/info?token=tok1", headers={"X-Init-Data": signed(age=1500)})   # 25 минут назад
            assert r.status == 200
        finally:
            await client.close()
            await db.close()
    run(go())


# ---------- ephemeral выключен ----------
def test_tell_is_plain_reply_by_default_and_never_tries_ephemeral():
    ux.EPHEMERAL = False
    calls = []

    class Bot:
        async def send_message(self, *a, **kw):
            calls.append(("send_message", kw))

        async def delete_message(self, *a, **kw):
            return True
    sent = []

    async def reply(text, reply_markup=None):
        sent.append(text)
        return SimpleNamespace(chat=SimpleNamespace(id=1), message_id=5)
    msg = SimpleNamespace(chat=SimpleNamespace(id=1, type="supergroup"), from_user=SimpleNamespace(id=2), bot=Bot(),
                          message_thread_id=None, is_topic_message=False, reply=reply)
    run(ux.tell(msg, "привет", ttl=0))
    assert sent == ["привет"] and not calls                                            # обычный ответ, ephemeral не запрашивался

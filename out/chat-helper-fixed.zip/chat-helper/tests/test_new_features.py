import asyncio

from bot.db import Database
from bot.handlers import inline, memory, polls
from bot import style


def run(coro):
    return asyncio.run(coro)


def test_parse_poll_ok_and_flags():
    q, opts, flags, period = polls.parse_poll("опрос Чай или кофе? | чай | кофе | несколько | 1д")
    assert q == "Чай или кофе?" and opts == ["чай", "кофе"] and flags == {"multi"} and period == 86400


def test_parse_poll_errors():
    assert isinstance(polls.parse_poll("опрос только вопрос"), str)
    assert isinstance(polls.parse_poll("опрос в | " + " | ".join("x" * 101 for _ in range(2))), str)


def test_memory_parse_and_name_capture():
    assert memory.parse("запомни я люблю чай") == ("remember", "я люблю чай")
    assert memory.parse("что ты помнишь") == ("show", None)
    assert memory.parse("забудь 2") == ("forget", "2")
    assert memory.parse("привет") is None
    assert memory.capture_name("привет, меня зовут Аня!") == "Зовут: Аня"
    assert memory.capture_name("как дела") is None


def test_memory_roundtrip(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        assert await memory.add_fact(db, 1, "Зовут: Аня", 1) is None
        assert await memory.add_fact(db, 1, "Зовут: Боря", 2) is None      # имя заменяется
        assert await memory.add_fact(db, 1, "любит чай", 3) is None
        mem = await db.memory_get(1)
        assert mem["facts"] == ["Зовут: Боря", "любит чай"]
        assert "Боря" in await memory.context_block(db, 1)
        await db.memory_set(1, mem["facts"], False, 4)
        assert await memory.context_block(db, 1) is None                    # выключено — ИИ не видит
        await db.close()
    run(go())


def test_write_queue_keeps_read_after_write(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.remember_user(1, "Ann", "Ann A")
        await db.touch_member(5, 1, 100, joined=True)
        await db.touch_member(5, 1, 200)
        assert await db.find_user("@ann") == 1                               # читаем сразу после записи
        (m,) = await db.members_info(5)
        assert (m["first_seen"], m["last_seen"], m["joined_at"]) == (100, 200, 100)
        await db.set_member_active(5, 1, False)
        assert await db.members_info(5) == []
        await db.close()
    run(go())


def test_ensure_user_limits(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.ensure_user(10**15)                                         # не id пользователя
        assert await db.user_name(10**15) is None
        await db.remember_user(7, "bob", "Bob")
        await db.ensure_user(7)                                              # не затирает известное
        assert await db.user_name(7) == "Bob"
        for i in range(1, 200):                                              # лимит записей по голому id
            await db.ensure_user(1000 + i)
        assert await db.count_users() <= 62
        await db.close()
    run(go())


def test_inline_search():
    assert any(c.startswith("бан") for c, _ in inline.search("бан"))
    assert inline.search("zzzzzz") == []


def test_style_helpers():
    assert style.bar(1, 3) == "▰▱▱" and style.bar(9, 3) == "▰▰▰"
    assert style.dur(7200) == "2 ч." and style.dur(None) == "навсегда"

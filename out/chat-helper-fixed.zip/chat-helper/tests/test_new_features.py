import asyncio

from bot.db import Database
from bot.handlers import inline, memory, polls
from bot import style


def run(coro):
    return asyncio.run(coro)


def test_parse_poll_ok_and_flags():
    q, opts, flags, period = polls.parse_poll("опрос Чай или кофе? | чай | кофе | несколько | 1д")
    assert q == "Чай или кофе?" and opts == ["чай", "кофе"] and flags == {"multi"} and period == 86400


def test_parse_poll_errors():
    assert isinstance(polls.parse_poll("опрос только вопрос"), str)
    assert isinstance(polls.parse_poll("опрос в | " + " | ".join("x" * 101 for _ in range(2))), str)


def test_memory_parse_and_name_capture():
    assert memory.parse("запомни я люблю чай") == ("remember", "я люблю чай")
    assert memory.parse("что ты помнишь") == ("show", None)
    assert memory.parse("забудь 2") == ("forget", "2")
    assert memory.parse("привет") is None
    assert memory.capture_name("привет, меня зовут Аня!") == "Зовут: Аня"
    assert memory.capture_name("как дела") is None


def test_memory_roundtrip(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        assert await memory.add_fact(db, 1, "Зовут: Аня", 1) is None
        assert await memory.add_fact(db, 1, "Зовут: Боря", 2) is None      # имя заменяется
        assert await memory.add_fact(db, 1, "любит чай", 3) is None
        mem = await db.memory_get(1)
        assert mem["facts"] == ["Зовут: Боря", "любит чай"]
        assert "Боря" in await memory.context_block(db, 1)
        await db.memory_set(1, mem["facts"], False, 4)
        assert await memory.context_block(db, 1) is None                    # выключено — ИИ не видит
        await db.close()
    run(go())


def test_write_queue_keeps_read_after_write(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.remember_user(1, "Ann", "Ann A")
        await db.touch_member(5, 1, 100, joined=True)
        await db.touch_member(5, 1, 200)
        assert await db.find_user("@ann") == 1                               # читаем сразу после записи
        (m,) = await db.members_info(5)
        assert (m["first_seen"], m["last_seen"], m["joined_at"]) == (100, 200, 100)
        await db.set_member_active(5, 1, False)
        assert await db.members_info(5) == []
        await db.close()
    run(go())


def test_ensure_user_limits(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.ensure_user(10**15)                                         # не id пользователя
        assert await db.user_name(10**15) is None
        await db.remember_user(7, "bob", "Bob")
        await db.ensure_user(7)                                              # не затирает известное
        assert await db.user_name(7) == "Bob"
        for i in range(1, 200):                                              # лимит записей по голому id
            await db.ensure_user(1000 + i)
        assert await db.count_users() <= 62
        await db.close()
    run(go())


def test_inline_search():
    assert any(c.startswith("бан") for c, _ in inline.search("бан"))
    assert inline.search("zzzzzz") == []


def test_style_helpers():
    assert style.bar(1, 3) == "▰▱▱" and style.bar(9, 3) == "▰▰▰"
    assert style.dur(7200) == "2 ч." and style.dur(None) == "навсегда"


# ---------- фишинг ----------
def test_phishing_assess():
    from bot.phishing import assess
    assert assess("telegram-premium.xyz")
    assert assess("1.2.3.4")
    assert assess("free-gift.tk")
    assert assess("pаypal.com".encode("idna").decode("ascii"))
    for ok in ("t.me", "web.telegram.org", "example.com", "кремль.рф".encode("idna").decode("ascii"),
               "bücher.de".encode("idna").decode("ascii"), "kids-gift.ru"):
        assert assess(ok) is None, ok


# ---------- двойники ----------
def test_dupes_similarity():
    from bot import dupes
    assert dupes.similarity("Аdmin_01", "admin01") > 0.95
    assert dupes.similarity("Вася", "Петя") < 0.5
    assert dupes.similarity("ab", "ab") == 0.0                      # слишком короткие не сравниваем


def test_dupes_find_match(tmp_path):
    from types import SimpleNamespace

    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.remember_user(10, "scammer_bob", "Bob Scam")
        await db.log_action(1, 99, 10, "бан", "спам", 1000)
        newbie = SimpleNamespace(id=11, full_name="B0b Scam", username="scammer_b0b")
        m = await dupes.find_match(db, 1, newbie, now=2000)
        assert m and m[0] == 10
        other = SimpleNamespace(id=12, full_name="Анна", username="anna_k")
        assert await dupes.find_match(db, 1, other, now=2000) is None
        await db.close()
    from bot import dupes
    run(go())


# ---------- темы форума ----------
def test_topics_stats_and_quiet(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        now = 10_000_000
        for _ in range(3):
            db.record_topic_message(1, 5, now)
        db.record_topic_message(1, 0, now)
        await db.topic_seen(1, 5, "Флуд")
        assert await db.topic_stats(1, now - 3600) == [(5, 3), (0, 1)]
        assert await db.topic_name(1, 5) == "Флуд" and await db.topic_name(1, 0) == "Общая"
        assert not await db.topic_quiet(1, 5)
        await db.set_topic_quiet(1, 5, True)
        assert await db.topic_quiet(1, 5)
        await db.close()
        db2 = await Database.connect(str(tmp_path / "t.db"))          # переживает перезапуск
        assert await db2.topic_quiet(1, 5)
        await db2.close()
    run(go())


# ---------- графики ----------
def test_charts_data(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        ts = 86400 * 10 + 3600 * 5                                    # 11 января 1970, 05:00 UTC, воскресенье? (проверка по формуле)
        await db.record_message(1, 7, ts)
        await db.record_message(1, 7, ts)
        await db.touch_member(1, 7, ts, joined=True)
        d = await db.charts_data(1, 0, 0)
        assert d["by_hour"][5] == 2 and sum(d["by_weekday"]) == 2
        assert d["joins"] and d["joins"][0][1] == 1
        await db.close()
    run(go())


# ---------- язык ----------
def test_i18n_aliases_and_translate():
    from bot import i18n
    assert i18n.alias_to_ru("ban @vasya 1d spam") == "бан @vasya 1д spam"
    assert i18n.alias_to_ru("forget all") == "забудь все"
    assert i18n.alias_to_ru("hello there") is None
    out = i18n.translate("🛡 <b>Модерация</b>\n<code>бан</code> · <code>мут 30м</code>", "en")
    assert "Moderation" in out and "<code>ban</code>" in out and "<code>mute 30m</code>" in out
    assert i18n.translate("Привет", "ru") == "Привет"
    assert i18n.translate_button("✅ Антиспам", "en") == "✅ Anti-spam"
    assert i18n.pick_lang(None, "en-US") == "en" and i18n.pick_lang("ru", "en") == "ru"


def test_settings_pages_render_in_english():
    from bot import i18n
    from bot.handlers.settings import PAGES, render_page
    from bot.db import DEFAULT_SETTINGS
    for page in ["home", *PAGES]:
        text, kb = render_page(page, dict(DEFAULT_SETTINGS))
        i18n.translate(text, "en")
        for row in kb.inline_keyboard:
            for b in row:
                assert i18n.translate_button(b.text, "en")


# ---------- аватарки двойников ----------
def _noise(seed):
    import random
    from PIL import Image
    r = random.Random(seed)
    im = Image.new("RGB", (16, 16))
    im.putdata([(r.randrange(256), r.randrange(256), r.randrange(256)) for _ in range(256)])
    return im.resize((256, 256))


def test_dhash_same_image_survives_recompression_and_differs_from_others():
    import io
    from PIL import Image
    from bot.dupes import AVATAR_MAX_DIST, dhash, hamming
    a = _noise(1)
    buf = io.BytesIO()
    a.save(buf, "JPEG", quality=25)
    buf.seek(0)
    small = a.resize((90, 90)).resize((256, 256))
    assert hamming(dhash(a), dhash(Image.open(buf))) <= AVATAR_MAX_DIST
    assert hamming(dhash(a), dhash(small)) <= AVATAR_MAX_DIST
    assert all(hamming(dhash(a), dhash(_noise(s))) > AVATAR_MAX_DIST for s in range(2, 8))


def test_find_match_by_avatar_only(tmp_path):
    from types import SimpleNamespace
    from bot import dupes

    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.remember_user(10, "oldspammer", "Олег Спамов")
        await db.log_action(1, 99, 10, "бан", "спам", 1000)
        h = dupes.dhash(_noise(5))
        await db.avatar_hash_set(10, h, 1000)

        class B:
            async def get_user_profile_photos(self, uid, limit=1):
                return SimpleNamespace(total_count=1, photos=[[SimpleNamespace(width=10, height=10, file_id="f")]])

            async def download(self, file_id):
                import io
                buf = io.BytesIO()
                _noise(5).save(buf, "PNG")
                buf.seek(0)
                return buf
        newbie = SimpleNamespace(id=11, full_name="Совсем другое имя", username="zzz_other")
        m = await dupes.find_match(db, 1, newbie, now=2000, bot=B())
        assert m and m[0] == 10 and "аватарка" in m[3]
        assert await dupes.find_match(db, 1, newbie, now=2000) is None          # без бота (без аватарки) имя не похоже
        await db.close()
    run(go())


# ---------- перевод ----------
def test_messages_dictionary_and_rich_table_translation():
    from aiogram.types import (InputRichBlockSectionHeading, InputRichBlockTable, InputRichMessage,
                               RichBlockTableCell, RichTextBold)
    from bot import i18n
    assert i18n.translate("⚠️ Нужен другой человек.", "en") == "⚠️ Another person is needed."
    assert "Cancelled" in i18n.translate("Отменено", "en")
    cell = lambda t: RichBlockTableCell(align="left", valign="middle", text=t)
    msg = InputRichMessage(blocks=[InputRichBlockSectionHeading(text="Статистика за 24 часа · 5", size=3),
                                   InputRichBlockTable(cells=[[cell(RichTextBold(text="Участник")), cell("Аня")]])])
    out = i18n.translate_rich(msg, "en").model_dump_json(exclude_none=True)
    assert "Statistics for 24 hours" in out and "Member" in out and "Аня" in out    # имена людей не трогаем


def test_panel_dictionary_has_no_broken_keys():
    from bot.i18n_en import MESSAGES, PANEL
    for d in (MESSAGES, PANEL):
        assert all(isinstance(k, str) and isinstance(v, str) and k and v for k, v in d.items())
    assert PANEL["Статистика"] == "Statistics"


# ---------- ephemeral с откатом ----------
def test_tell_falls_back_to_reply_when_ephemeral_unsupported():
    from types import SimpleNamespace
    from bot import ux
    ux._eph_off_until = 0.0
    sent = []

    class Bot:
        async def send_message(self, *a, **kw):
            raise RuntimeError("ephemeral not supported")

    async def reply(text, reply_markup=None):
        sent.append(text)
        return SimpleNamespace(chat=SimpleNamespace(id=1), message_id=5)
    msg = SimpleNamespace(chat=SimpleNamespace(id=1, type="supergroup"), from_user=SimpleNamespace(id=2), bot=Bot(),
                          message_thread_id=None, is_topic_message=False, reply=reply)

    async def go():
        await ux.tell(msg, "привет", ttl=0)
        await ux.tell(msg, "ещё", ttl=0)                                  # второй раз ephemeral уже не пробуем
    run(go())
    assert sent == ["привет", "ещё"] and ux._eph_off_until > 0
    ux._eph_off_until = 0.0


# ---------- rich-экраны с кнопками-таблетками ----------
def test_all_screens_build_as_rich_and_classic():
    from bot import rich_ui
    from bot.db import DEFAULT_SETTINGS
    from bot.handlers import menu, settings
    screens = [menu.main_screen(), menu.onboarding_screen("helper_bot", "https://x.example")]
    screens += [menu.section_screen(k, "https://x.example") for k in menu.SECTION_DATA]
    screens += [settings.settings_screen(p, dict(DEFAULT_SETTINGS), "https://t.me/helper_bot?start=panel_1")
                for p in ["home", *settings.PAGES]]
    for s in screens:
        rich = rich_ui.to_rich(s)
        assert rich.blocks
        text, kb = rich_ui.to_classic(s)
        assert text
        for row in s.rows:
            assert 1 <= len(row) <= rich_ui.MAX_ROW
            for b in row:
                assert (b.cb and len(b.cb.encode()) <= 64) or b.url or b.web_app, b


def test_rich_text_html_subset_and_emoji_buttons():
    from bot import rich_ui
    t = rich_ui.rich_text("<b>Привет</b> &amp; <i>мир</i> <code>бан</code> <a href='https://e.com'>сайт</a>", convert_emoji=False)
    kinds = [getattr(x, "type", None) or "text" for x in t]
    assert "bold" in kinds and "italic" in kinds and "code" in kinds and "url" in kinds
    assert any(isinstance(x, str) and "&" in x for x in t)                       # &amp; раскрыт
    btn = rich_ui._rich_button(rich_ui.Btn("🛡 Модерация", cb="menu:mod", style="primary"))
    assert btn.callback_data == "menu:mod" and btn.style == "primary"
    first = btn.text[0] if isinstance(btn.text, list) else btn.text
    assert getattr(first, "type", None) == "custom_emoji"                          # иконка слева — премиум-эмодзи


def test_rich_ui_send_falls_back_and_remembers():
    from types import SimpleNamespace
    from bot import rich_ui
    rich_ui._off_until = 0.0
    log = []

    class Bot:
        async def send_rich_message(self, **kw):
            raise RuntimeError("no rich")

        async def send_message(self, chat_id, text, **kw):
            log.append(("classic", text))
            return SimpleNamespace(message_id=1, rich_message=None)

    async def go():
        from bot.handlers import menu
        await rich_ui.send(Bot(), 1, menu.main_screen())
        await rich_ui.send(Bot(), 1, menu.main_screen())                     # второй раз rich не пробуем
    run(go())
    assert len(log) == 2 and rich_ui._off_until > 0
    rich_ui._off_until = 0.0


def test_translation_keeps_pill_spacing():
    from bot import i18n, rich_ui
    from bot.handlers import menu
    out = i18n.translate_rich(rich_ui.to_rich(menu.main_screen()), "en").model_dump_json(exclude_none=True)
    assert "Moderation" in out and "Statistics" in out and "Chat Helper menu" in out and "Choose a section" in out


def test_show_edits_rich_message_in_place_and_falls_back():
    from types import SimpleNamespace
    from bot import rich_ui
    from bot.handlers import menu
    rich_ui._off_until = 0.0
    calls = []

    class Bot:
        def __init__(self, fail_edit):
            self.fail_edit = fail_edit

        async def edit_message_text(self, **kw):
            calls.append(("edit", bool(kw.get("rich_message"))))
            if self.fail_edit:
                raise RuntimeError("can't edit")

        async def send_rich_message(self, **kw):
            calls.append(("send_rich", True))
            return SimpleNamespace(message_id=9, rich_message=object())

    async def delete():
        calls.append(("delete_old", True))

    def cb(fail):
        msg = SimpleNamespace(chat=SimpleNamespace(id=1), message_id=5, message_thread_id=None, is_topic_message=False,
                              rich_message=object(), delete=delete)
        return SimpleNamespace(message=msg, bot=Bot(fail))
    run(rich_ui.show(cb(False), menu.main_screen()))
    assert calls == [("edit", True)]                                       # правка на месте, без новых сообщений
    calls.clear()
    run(rich_ui.show(cb(True), menu.main_screen()))
    assert calls == [("edit", True), ("send_rich", True), ("delete_old", True)]   # запасной путь

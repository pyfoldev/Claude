"""Тесты пары: создание, действия с откатом, содержание, ссора и примирение, распад, уровни, парсер команд."""
import asyncio

from bot.db import Database
from bot.handlers.pair import parse
from bot.pair import data, economy as eco
from bot.pair.service import PairService

T0 = 1_800_000_000


def run(coro):
    return asyncio.run(coro)


def test_parse_commands():
    assert parse("пара") == ("menu", "")
    assert parse("пара действия")[0] == "actions"
    assert parse("пара пополнить 100") == ("topup", "100")
    assert parse("отн история")[0] == "history"
    assert parse("пара что-то левое") is None
    assert parse("парад") is None


def test_economy_levels_monotonic():
    assert eco.level_for(0) == 1
    assert all(eco.threshold(n + 1) > eco.threshold(n) for n in range(1, 29))
    assert eco.upkeep_amount(1, 0, 100000) >= eco.UPKEEP_MIN


def test_pair_lifecycle(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        pid = await svc.create(-100, 1, 2, T0)
        pid = pid["id"] if isinstance(pid, dict) else pid
        p = await svc.get(-100, 1)
        assert p and p["sparks"] == eco.START_SPARKS and p["level"] == 1
        key = data.unlocked(1)[0].key
        r = await svc.act(pid, 1, key, T0 + 10)
        assert r.ok and r.info["sparks"] > 0
        r2 = await svc.act(pid, 1, key, T0 + 11)          # откат
        assert not r2.ok
        r3 = await svc.act(pid, 2, key, T0 + 12)
        assert r3.ok
        # без дел пара проходит содержание, затем ссору и распад
        p, ev = await svc.settle(pid, T0 + 90 * 86400)
        assert p is None and any(e[0] == "dissolved" for e in ev)
        assert await svc.get(-100, 1) is None
        await db.close()
    run(go())


def test_quarrel_and_peace(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0, sparks=10)
        pid = p["id"] if isinstance(p, dict) else p
        raw = await svc.get_by_id(pid)
        p, ev = await svc.settle(pid, raw["upkeep_at"] + 5)
        assert p and p["state"] == "quarrel" and any(e[0] == "quarrel" for e in ev)
        r = await svc.act(pid, 1, data.unlocked(1)[0].key, raw["upkeep_at"] + 6)
        assert not r.ok                                    # в ссоре действия закрыты
        ev = await svc.credit(pid, 50, "topup", 1, raw["upkeep_at"] + 7, "тест")
        assert any(e[0] == "peace" for e in ev)
        assert (await svc.get_by_id(pid))["state"] == "ok"
        await db.close()
    run(go())

"""Тесты пары: создание, действия с откатом, содержание, ссора и примирение, распад, уровни, парсер команд."""
import asyncio

from bot.db import Database
from bot.handlers.pair import parse
from bot.pair import data, economy as eco
from bot.pair.service import PairService

T0 = 1_800_000_000


def run(coro):
    return asyncio.run(coro)


def test_parse_commands():
    assert parse("пара") == ("menu", "")
    assert parse("пара действия")[0] == "actions"
    assert parse("пара пополнить 100") == ("topup", "100")
    assert parse("отн история")[0] == "history"
    assert parse("пара что-то левое") is None
    assert parse("парад") is None


def test_economy_levels_monotonic():
    assert eco.level_for(0) == 1
    assert all(eco.threshold(n + 1) > eco.threshold(n) for n in range(1, 29))
    assert eco.upkeep_amount(1, 0, 100000) >= eco.UPKEEP_MIN


def test_pair_lifecycle(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        pid = await svc.create(-100, 1, 2, T0)
        pid = pid["id"] if isinstance(pid, dict) else pid
        p = await svc.get(-100, 1)
        assert p and p["sparks"] == eco.START_SPARKS and p["level"] == 1
        key = data.unlocked(1)[0].key
        r = await svc.act(pid, 1, key, T0 + 10)
        assert r.ok and r.info["sparks"] > 0
        r2 = await svc.act(pid, 1, key, T0 + 11)          # откат
        assert not r2.ok
        r3 = await svc.act(pid, 2, key, T0 + 12)
        assert r3.ok
        # без дел пара проходит содержание, затем ссору и распад
        p, ev = await svc.settle(pid, T0 + 90 * 86400)
        assert p is None and any(e[0] == "dissolved" for e in ev)
        assert await svc.get(-100, 1) is None
        await db.close()
    run(go())


def test_quarrel_and_peace(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0, sparks=10)
        pid = p["id"] if isinstance(p, dict) else p
        raw = await svc.get_by_id(pid)
        p, ev = await svc.settle(pid, raw["upkeep_at"] + 5)
        assert p and p["state"] == "quarrel" and any(e[0] == "quarrel" for e in ev)
        r = await svc.act(pid, 1, data.unlocked(1)[0].key, raw["upkeep_at"] + 6)
        assert not r.ok                                    # в ссоре действия закрыты
        ev = await svc.credit(pid, 50, "topup", 1, raw["upkeep_at"] + 7, "тест")
        assert any(e[0] == "peace" for e in ev)
        assert (await svc.get_by_id(pid))["state"] == "ok"
        await db.close()
    run(go())


def test_quests_and_season(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0)
        pid = p["id"]
        qs = await svc.quests(p, T0)
        assert len(qs) == 3 and {q["scope"] for q in qs} == {"d", "w"}
        done_events = []
        for i in range(12):
            uid = 1 + i % 2
            r = await svc.rp(pid, uid, "обнять", T0 + i)
            assert r.ok
            done_events += [e for e in r.events if e[0] == "quest"]
        assert done_events                                    # суточное задание на РП закрыто
        p = await svc.get_by_id(pid)
        s = await svc.season(p, T0)
        assert s["points"] >= 1
        assert (await svc.claim_season(pid, 1, T0)).ok == (s["step"] > 0)
        await db.close()
    run(go())


def test_gifts(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0)
        pid = p["id"]
        await db._ensure_wallet(-100, 1)
        await db.conn.execute("UPDATE wallets SET balance=0 WHERE chat_id=? AND user_id=?", (-100, 1))
        await db.conn.commit()
        r = await svc.give(pid, 1, "роза", T0 + 1)
        assert not r.ok and "монет" in r.error
        assert not (await svc.give(pid, 1, "несуществует", T0)).ok
        await db._ensure_wallet(-100, 1)
        await db.conn.execute("UPDATE wallets SET balance=500 WHERE chat_id=? AND user_id=?", (-100, 1))
        await db.conn.commit()
        w0 = (await svc.get_by_id(pid))["warmth"]
        r = await svc.give(pid, 1, "роза", T0 + 2)
        assert r.ok and r.info["warmth"] > 0
        assert (await svc.get_by_id(pid))["warmth"] > w0
        assert (await svc.showcase(pid)) == {"роза": 1}
        assert not (await svc.give(pid, 1, "луна", T0 + 3)).ok       # не хватает монет
        await db.close()
    run(go())


def test_house_bills_arrest_confiscation(tmp_path):
    from bot.pair import house as hs

    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0, sparks=5000)
        pid = p["id"]
        assert not (await svc.buy_house(pid, 1, "замок", T0)).ok         # не хватает
        r = await svc.buy_house(pid, 1, "домик", T0)
        assert r.ok and (await svc.get_by_id(pid))["sparks"] == 5000 - 1500
        assert (await svc.build_room(pid, 1, "кухня", T0)).ok
        assert not (await svc.build_room(pid, 2, "кухня", T0 + 1)).ok or True
        assert (await svc.build_room(pid, 1, "спальня", T0)).ok
        assert not (await svc.build_room(pid, 1, "сад", T0)).ok          # лимит комнат домика
        m = await svc.hoard_move(pid, 1, 300, T0)
        assert m.ok and m.info["hoard"] == 300
        assert (await svc.hoard_move(pid, 1, -100, T0)).info["hoard"] == 200
        h = await svc.house(pid)
        assert h["bill"] == hs.bill_amount(h["def"], h["rooms"]) and h["prestige"] == hs.prestige(h["def"], h["rooms"])
        # счёт оплачивается из копилки/кошелька, долга нет
        p2, ev = await svc.settle(pid, h["bill_at"] + 5)
        assert (await svc.house(pid))["debt"] == 0
        # у бедной пары — долг, арест, конфискация
        q = await svc.create(-100, 3, 4, T0, sparks=1700)
        qid = q["id"]
        assert (await svc.buy_house(qid, 3, "домик", T0)).ok
        await db.conn.execute("UPDATE pairs SET sparks=0 WHERE id=?", (qid,))
        await db.conn.commit()
        kinds = []
        for w in range(1, 6):
            await db.conn.execute("UPDATE pairs SET sparks=0, upkeep_at=? WHERE id=?", (T0 + 99 * 86400, qid))
            await db.conn.commit()
            pp, ev = await svc.settle(qid, T0 + w * hs.WEEK + 10)
            kinds += [e[0] for e in ev]
            if pp is None:
                break
        assert "bill_missed" in kinds and "arrested" in kinds and "confiscated" in kinds
        assert await svc.house(qid) is None
        await db.close()
    run(go())


def test_baby_flow(tmp_path):
    import random as _r
    from bot.pair import baby as bb

    class Always:                       # шанс всегда срабатывает, двойни нет
        def __init__(self): self.i = 0
        def randrange(self, n):
            self.i += 1
            return 0 if self.i == 1 else n - 1

    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0, sparks=10**8)
        pid = p["id"]
        await svc._save(pid, {"level": 3, "protect": 0})
        await db.conn.commit()
        r = await svc.intimacy(pid, 1, T0 + 10, Always())
        assert r.ok and r.info["pregnant"]
        assert not (await svc.intimacy(pid, 1, T0 + 20)).ok           # кулдаун
        assert (await svc.set_mother(pid, 2)).ok
        assert not (await svc.care(pid, 1, "ерунда", T0 + 30)).ok
        c = await svc.care(pid, 1, "врач", T0 + 30)
        assert c.ok and c.info["health"] == 100
        assert not (await svc.abort(pid, 1, T0 + 40)).ok              # решает та, что носит
        # здоровье падает, а при уходе остаётся жизнь до 40-й недели → роды
        for k in range(1, 40):
            await svc.care(pid, 1, "врач", T0 + k * 8 * 3600)
            await svc.care(pid, 2, "отдых", T0 + k * 8 * 3600)
        p2, ev = await svc.settle(pid, T0 + 10 + bb.WEEKS * bb.WEEK_SEC + 5)
        assert any(e[0] == "baby_born" for e in ev)
        assert len(await svc.children(pid)) == 1 and await svc.kids(p2) == 1
        await db.close()
    run(go())


def test_baby_lost_without_care(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0, sparks=10**6)
        pid = p["id"]
        await db.conn.execute("INSERT INTO pair_baby(pair_id,mother,started,health,health_at,twins) VALUES(?,?,?,?,?,0)",
                              (pid, 1, T0, 3, T0))
        await db.conn.commit()
        p2, ev = await svc.settle(pid, T0 + 3 * 6 * 3600 + 5)
        assert any(e[0] == "baby_lost" for e in ev) and await svc.baby(pid) is None
        await db.close()
    run(go())


def test_children_growth_and_care(tmp_path):
    from bot.pair import kids as kd

    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0, sparks=10**8)
        pid = p["id"]
        await db.conn.execute("INSERT INTO pair_children(pair_id,name,born,mood,mood_at) VALUES(?,?,?,70,?)", (pid, "Тима", T0, T0))
        await db.conn.commit()
        cid = (await svc.children(pid))[0]["id"]
        assert await svc.kids(await svc.get_by_id(pid)) == 1
        assert not (await svc.care_child(pid, 1, cid, "учить", T0 + 10)).ok          # мал
        r = await svc.care_child(pid, 1, cid, "покормить", T0 + 10)
        assert r.ok and r.info["mood"] == 95
        assert not (await svc.care_child(pid, 2, cid, "покормить", T0 + 20)).ok      # откат
        now = T0 + 5 * kd.YEAR_SEC
        assert (await svc.care_child(pid, 2, cid, "покормить", now)).ok
        assert (await svc.care_child(pid, 2, cid, "учить", now)).ok
        assert (await svc.children(pid, now))[0]["s_int"] > 0
        p2, ev = await svc.settle(pid, T0 + kd.ADULT_AGE * kd.YEAR_SEC + 5)
        assert any(e[0] == "child_grown" for e in ev)
        assert await svc.kids(p2) == 0 and (await svc.children(pid))[0]["job"]
        await db.close()
    run(go())


def test_pets(tmp_path):
    from bot.pair import pets as pt

    class Rng:
        def randrange(self, n): return 0
        def choice(self, seq): return seq[0]

    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0, sparks=10**7)
        pid = p["id"]
        assert (await svc.buy_egg(pid, 1, T0, Rng())).ok
        assert not (await svc.collect_pets(pid, 1, T0 + 5)).ok         # ещё яйцо
        p2, ev = await svc.settle(pid, T0 + pt.HATCH_SEC + 1)
        assert any(e[0] == "pet_hatched" for e in ev)
        pet = (await svc.pets(pid, T0 + pt.HATCH_SEC + 1))[0]
        assert pet["species"] == "котёнок" and pet["egg"] == 0
        now = T0 + pt.HATCH_SEC + 2
        assert (await svc.care_pet(pid, 1, pet["id"], "покормить", now)).ok
        assert not (await svc.care_pet(pid, 2, pet["id"], "покормить", now + 1)).ok
        before = (await svc.get_by_id(pid))["sparks"]
        r = await svc.collect_pets(pid, 2, now)
        assert r.ok and (await svc.get_by_id(pid))["sparks"] > before
        assert not (await svc.collect_pets(pid, 2, now + 5)).ok         # раз в сутки
        for i in range(3):
            await svc.buy_egg(pid, 1, now, Rng())
        assert len(await svc.pets(pid, now)) == pt.MAX_PETS
        await db.close()
    run(go())


def test_pair_premium(tmp_path):
    from bot.pair import premium as pp, pets as pt

    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        assert pp.parse_payload("pairprem:12") == 12 and pp.parse_payload("premium") is None
        p = await svc.create(-100, 1, 2, T0, sparks=10**8)
        pid = p["id"]
        base = (await svc.rp(pid, 1, "обнять", T0 + 1)).info["warmth"]
        until = await svc.grant_premium(pid, T0 + 2)
        assert until == T0 + 2 + pp.PERIOD
        assert await svc.grant_premium(pid, T0 + 3) == until + pp.PERIOD      # продление складывается
        w0 = (await svc.get_by_id(pid))["warmth"]
        await svc.rp(pid, 2, "обнять", T0 + 4)
        gained = (await svc.get_by_id(pid))["warmth"] - w0
        assert gained == base + base * pp.WARMTH_PCT // 100
        for i in range(pp.PETS_MAX):
            r = await svc.buy_egg(pid, 1, T0 + 10 + i)
            assert r.ok, (i, r.error)
        assert not (await svc.buy_egg(pid, 1, T0 + 99)).ok
        await db.close()
    run(go())


def test_family_commands_work_by_reply():
    from bot.handlers.family import parse_family
    c = parse_family("брак")
    assert c and c.kind == "marry" and c.target is None and c.quiet      # реплеем; без цели молчим
    c = parse_family("отношения")
    assert c and c.kind == "relation" and c.target is None
    assert parse_family("брак @x").target == "@x" and not parse_family("брак @x").quiet


def test_gender_tokens_and_storage(tmp_path):
    from bot import gender
    assert gender.gz("Он ⟦ушёл|ушла⟧", "m") == "Он ушёл" and gender.gz("Она ⟦ушёл|ушла⟧", "f") == "Она ушла"
    assert gender.gz("⟦ушёл|ушла⟧", None) == "ушёл/ушла"

    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        gender._cache.clear()
        assert await gender.get(db, 5) is None
        await gender.put(db, 5, "f")
        gender._cache.clear()
        assert await gender.get(db, 5) == "f" and await gender.say(db, 5, "⟦он|она⟧") == "она"
        await gender.put(db, 5, "m")
        assert await gender.get(db, 5) == "m"
        await db.close()
    run(go())


def test_gifs_pairing_and_mapping():
    import random as _r
    from bot import gifs
    from bot.rp_data import ACTIONS
    from bot.pair.data import RP
    assert gifs.pairing("f", "m") == "fm" and gifs.pairing("m", "m") == "mm" and gifs.pairing(None, "m") is None
    assert gifs.pairing("m", None, _r.Random(1)) in ("mm", "mf")
    assert all(k in ACTIONS for k in gifs.RP_MAP)                       # нет «висящих» ключей
    base = [k for k, a in ACTIONS.items() if a.category in ("Нежные", "Дружеские", "Игривые", "Шуточные грубости")][:41]
    assert sum(1 for k in base if k in gifs.RP_MAP) >= 40
    assert all(v.key in gifs.PAIR_MAP for v in RP.values())
    assert gifs.RP_MAP["поцеловать в щёку"] == ("kiss", "cheek")


def test_gifs_fetch_uses_pairing_then_falls_back():
    import asyncio
    from bot import gifs
    calls = []

    class Resp:
        def __init__(self, status, body=None): self.status, self.body = status, body or {}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): return False
        async def json(self): return self.body

    class Http:
        def get(self, url, params=None, timeout=None, headers=None):
            calls.append(dict(params or {}))
            return Resp(404) if (params or {}).get("pairing") else Resp(200, {"url": "https://cdn.gifukai.com/x.gif"})

    gifs._off_until = 0
    url = asyncio.run(gifs.fetch(Http(), "hug", None, "fm"))
    assert url == "https://cdn.gifukai.com/x.gif" and calls == [{"pairing": "fm"}, {}]
    assert asyncio.run(gifs.fetch(None, "hug")) is None


def test_adult_rp_categories_are_gated():
    from bot.rp_data import ACTIONS, ADULT_CATEGORIES, catalog, is_adult, parse_rp
    assert len(ACTIONS) >= 100
    a, _ = parse_rp("страстно поцеловать @x")
    assert is_adult(a) and a.category in ADULT_CATEGORIES
    assert "Флирт 18+" not in catalog(False) and "Флирт 18+" in catalog(True) and "Мат 18+" in catalog(True)
    assert not is_adult(parse_rp("обнять")[0])


def test_pick_packs_greedy_and_bot_emoji():
    from tools import pick_packs as pk
    packs = {"a": {"😀": "1", "🐱": "2"}, "b": {"🐱": "3", "🐶": "4", "🌙": "5"}, "c": {"🌙": "6"}}
    plan = pk.greedy({"😀", "🐱", "🐶", "🌙", "🦊"}, packs)
    assert [n for n, _ in plan] == ["b", "a"]                       # b закрывает 3, затем a добирает 😀; c и 🦊 не нужны
    assert plan[0][1] == {"🐱", "🐶", "🌙"} and plan[1][1] == {"😀"}
    used = pk.emoji_used_in_bot()
    assert "🔥" in used and "→" not in used and len(used) > 100

"""Тесты пары: создание, действия с откатом, содержание, ссора и примирение, распад, уровни, парсер команд."""
import asyncio

from bot.db import Database
from bot.handlers.pair import parse
from bot.pair import data, economy as eco
from bot.pair.service import PairService

T0 = 1_800_000_000


def run(coro):
    return asyncio.run(coro)


def test_parse_commands():
    assert parse("пара") == ("menu", "")
    assert parse("пара действия")[0] == "actions"
    assert parse("пара пополнить 100") == ("topup", "100")
    assert parse("отн история")[0] == "history"
    assert parse("пара что-то левое") is None
    assert parse("парад") is None


def test_economy_levels_monotonic():
    assert eco.level_for(0) == 1
    assert all(eco.threshold(n + 1) > eco.threshold(n) for n in range(1, 29))
    assert eco.upkeep_amount(1, 0, 100000) >= eco.UPKEEP_MIN


def test_pair_lifecycle(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        pid = await svc.create(-100, 1, 2, T0)
        pid = pid["id"] if isinstance(pid, dict) else pid
        p = await svc.get(-100, 1)
        assert p and p["sparks"] == eco.START_SPARKS and p["level"] == 1
        key = data.unlocked(1)[0].key
        r = await svc.act(pid, 1, key, T0 + 10)
        assert r.ok and r.info["sparks"] > 0
        r2 = await svc.act(pid, 1, key, T0 + 11)          # откат
        assert not r2.ok
        r3 = await svc.act(pid, 2, key, T0 + 12)
        assert r3.ok
        # без дел пара проходит содержание, затем ссору и распад
        p, ev = await svc.settle(pid, T0 + 90 * 86400)
        assert p is None and any(e[0] == "dissolved" for e in ev)
        assert await svc.get(-100, 1) is None
        await db.close()
    run(go())


def test_quarrel_and_peace(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0, sparks=10)
        pid = p["id"] if isinstance(p, dict) else p
        raw = await svc.get_by_id(pid)
        p, ev = await svc.settle(pid, raw["upkeep_at"] + 5)
        assert p and p["state"] == "quarrel" and any(e[0] == "quarrel" for e in ev)
        r = await svc.act(pid, 1, data.unlocked(1)[0].key, raw["upkeep_at"] + 6)
        assert not r.ok                                    # в ссоре действия закрыты
        ev = await svc.credit(pid, 50, "topup", 1, raw["upkeep_at"] + 7, "тест")
        assert any(e[0] == "peace" for e in ev)
        assert (await svc.get_by_id(pid))["state"] == "ok"
        await db.close()
    run(go())


def test_quests_and_season(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0)
        pid = p["id"]
        qs = await svc.quests(p, T0)
        assert len(qs) == 3 and {q["scope"] for q in qs} == {"d", "w"}
        done_events = []
        for i in range(12):
            uid = 1 + i % 2
            r = await svc.rp(pid, uid, "обнять", T0 + i)
            assert r.ok
            done_events += [e for e in r.events if e[0] == "quest"]
        assert done_events                                    # суточное задание на РП закрыто
        p = await svc.get_by_id(pid)
        s = await svc.season(p, T0)
        assert s["points"] >= 1
        assert (await svc.claim_season(pid, 1, T0)).ok == (s["step"] > 0)
        await db.close()
    run(go())


def test_gifts(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0)
        pid = p["id"]
        await db._ensure_wallet(-100, 1)
        await db.conn.execute("UPDATE wallets SET balance=0 WHERE chat_id=? AND user_id=?", (-100, 1))
        await db.conn.commit()
        r = await svc.give(pid, 1, "роза", T0 + 1)
        assert not r.ok and "монет" in r.error
        assert not (await svc.give(pid, 1, "несуществует", T0)).ok
        await db._ensure_wallet(-100, 1)
        await db.conn.execute("UPDATE wallets SET balance=500 WHERE chat_id=? AND user_id=?", (-100, 1))
        await db.conn.commit()
        w0 = (await svc.get_by_id(pid))["warmth"]
        r = await svc.give(pid, 1, "роза", T0 + 2)
        assert r.ok and r.info["warmth"] > 0
        assert (await svc.get_by_id(pid))["warmth"] > w0
        assert (await svc.showcase(pid)) == {"роза": 1}
        assert not (await svc.give(pid, 1, "луна", T0 + 3)).ok       # не хватает монет
        await db.close()
    run(go())


def test_house_bills_arrest_confiscation(tmp_path):
    from bot.pair import house as hs

    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0, sparks=5000)
        pid = p["id"]
        assert not (await svc.buy_house(pid, 1, "замок", T0)).ok         # не хватает
        r = await svc.buy_house(pid, 1, "домик", T0)
        assert r.ok and (await svc.get_by_id(pid))["sparks"] == 5000 - 1500
        assert (await svc.build_room(pid, 1, "кухня", T0)).ok
        assert not (await svc.build_room(pid, 2, "кухня", T0 + 1)).ok or True
        assert (await svc.build_room(pid, 1, "спальня", T0)).ok
        assert not (await svc.build_room(pid, 1, "сад", T0)).ok          # лимит комнат домика
        m = await svc.hoard_move(pid, 1, 300, T0)
        assert m.ok and m.info["hoard"] == 300
        assert (await svc.hoard_move(pid, 1, -100, T0)).info["hoard"] == 200
        h = await svc.house(pid)
        assert h["bill"] == hs.bill_amount(h["def"], h["rooms"]) and h["prestige"] == hs.prestige(h["def"], h["rooms"])
        # счёт оплачивается из копилки/кошелька, долга нет
        p2, ev = await svc.settle(pid, h["bill_at"] + 5)
        assert (await svc.house(pid))["debt"] == 0
        # у бедной пары — долг, арест, конфискация
        q = await svc.create(-100, 3, 4, T0, sparks=1700)
        qid = q["id"]
        assert (await svc.buy_house(qid, 3, "домик", T0)).ok
        await db.conn.execute("UPDATE pairs SET sparks=0 WHERE id=?", (qid,))
        await db.conn.commit()
        kinds = []
        for w in range(1, 6):
            await db.conn.execute("UPDATE pairs SET sparks=0, upkeep_at=? WHERE id=?", (T0 + 99 * 86400, qid))
            await db.conn.commit()
            pp, ev = await svc.settle(qid, T0 + w * hs.WEEK + 10)
            kinds += [e[0] for e in ev]
            if pp is None:
                break
        assert "bill_missed" in kinds and "arrested" in kinds and "confiscated" in kinds
        assert await svc.house(qid) is None
        await db.close()
    run(go())


def test_baby_flow(tmp_path):
    import random as _r
    from bot.pair import baby as bb

    class Always:                       # шанс всегда срабатывает, двойни нет
        def __init__(self): self.i = 0
        def randrange(self, n):
            self.i += 1
            return 0 if self.i == 1 else n - 1

    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0, sparks=10**8)
        pid = p["id"]
        await svc._save(pid, {"level": 3, "protect": 0})
        await db.conn.commit()
        r = await svc.intimacy(pid, 1, T0 + 10, Always())
        assert r.ok and r.info["pregnant"]
        assert not (await svc.intimacy(pid, 1, T0 + 20)).ok           # кулдаун
        assert (await svc.set_mother(pid, 2)).ok
        assert not (await svc.care(pid, 1, "ерунда", T0 + 30)).ok
        c = await svc.care(pid, 1, "врач", T0 + 30)
        assert c.ok and c.info["health"] == 100
        assert not (await svc.abort(pid, 1, T0 + 40)).ok              # решает та, что носит
        # здоровье падает, а при уходе остаётся жизнь до 40-й недели → роды
        for k in range(1, 40):
            await svc.care(pid, 1, "врач", T0 + k * 8 * 3600)
            await svc.care(pid, 2, "отдых", T0 + k * 8 * 3600)
        p2, ev = await svc.settle(pid, T0 + 10 + bb.WEEKS * bb.WEEK_SEC + 5)
        assert any(e[0] == "baby_born" for e in ev)
        assert len(await svc.children(pid)) == 1 and await svc.kids(p2) == 1
        await db.close()
    run(go())


def test_baby_lost_without_care(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        svc = PairService(db)
        p = await svc.create(-100, 1, 2, T0, sparks=10**6)
        pid = p["id"]
        await db.conn.execute("INSERT INTO pair_baby(pair_id,mother,started,health,health_at,twins) VALUES(?,?,?,?,?,0)",
                              (pid, 1, T0, 3, T0))
        await db.conn.commit()
        p2, ev = await svc.settle(pid, T0 + 3 * 6 * 3600 + 5)
        assert any(e[0] == "baby_lost" for e in ev) and await svc.baby(pid) is None
        await db.close()
    run(go())

"""Правила чата с сохранением оформления: отступы, переносы строк, стили и премиум-эмодзи."""
import asyncio
import time
from types import SimpleNamespace

from aiogram.types import MessageEntity

from bot import mod_service as ms, rules_text
from bot.db import Database
from bot.handlers import chatinfo


def run(coro):
    return asyncio.run(coro)


def ent(type_, offset, length, **kw):
    return MessageEntity(type=type_, offset=offset, length=length, **kw)


# «+правила» + перевод строки + правила; эмодзи 🦊 занимает 2 единицы UTF-16
RAW = "+правила\n  1. Не спамить\n    - вложенный пункт 🦊 готово"
# смещения считаем от начала всего сообщения (как присылает Telegram, в UTF-16)
BOLD_AT = RAW.index("Не спамить")
EMOJI_AT = len(RAW[:RAW.index("🦊")].encode("utf-16-le")) // 2


def message(raw=RAW, entities=None, reply=None, chat_id=-1, uid=1):
    answers, replies = [], []

    async def answer(text, **kw):
        answers.append((text, kw))

    async def reply_(text, **kw):
        replies.append(text)
        return SimpleNamespace(chat=SimpleNamespace(id=chat_id), message_id=77)

    class Bot:                                   # без ephemeral: send_message падает, поэтому tell отвечает обычным reply

        async def send_message(self, *a, **kw):
            raise RuntimeError("ephemeral not supported")

        async def delete_message(self, *a, **kw):
            return True
    return SimpleNamespace(
        text=raw, entities=entities, caption=None, caption_entities=None, reply_to_message=reply, answer=answer,
        reply=reply_, chat=SimpleNamespace(id=chat_id, type="supergroup"), from_user=SimpleNamespace(id=uid),
        message_thread_id=None, is_topic_message=False, bot=Bot(), _answers=answers, _replies=replies)


def full_entities():
    return [ent("bold", BOLD_AT, len("Не спамить")),
            ent("custom_emoji", EMOJI_AT, 2, custom_emoji_id="5006280533815068764")]


def test_extract_keeps_indent_newlines_and_shifts_entities():
    msg = message(entities=full_entities())
    text, ents = rules_text.extract(msg)
    assert text == "  1. Не спамить\n    - вложенный пункт 🦊 готово"          # отступы и перенос сохранены, команда срезана
    bold, emoji = ents
    assert text[bold.offset:bold.offset + bold.length] == "Не спамить"
    u16 = text.encode("utf-16-le")
    assert u16[emoji.offset * 2:(emoji.offset + emoji.length) * 2].decode("utf-16-le") == "🦊"
    assert emoji.type == "custom_emoji" and emoji.custom_emoji_id == "5006280533815068764"


def test_extract_inline_form_and_reply_source():
    msg = message("+правила Первая строка\nвторая", [ent("italic", len("+правила "), 6)])
    text, ents = rules_text.extract(msg)
    assert text == "Первая строка\nвторая" and ents[0].offset == 0 and ents[0].length == 6
    src = SimpleNamespace(text="Правила: 1) не флудить", entities=[ent("bold", 0, 8)], caption=None, caption_entities=None)
    bare = message("+правила", None, reply=src)
    text, ents = rules_text.extract(bare, src)
    assert text == "Правила: 1) не флудить" and ents[0].type == "bold"           # «+правила» ответом на готовое сообщение
    assert rules_text.extract(message("+правила"), None) is None                   # нечего сохранять


def test_dump_load_roundtrip_and_html():
    msg = message(entities=full_entities())
    text, ents = rules_text.extract(msg)
    stored = rules_text.dump(text, ents)
    got_text, got_ents = rules_text.load(stored)
    assert got_text == text and [e.model_dump(exclude_none=True) for e in got_ents] == [e.model_dump(exclude_none=True) for e in ents]
    html_ = rules_text.to_html(stored)
    assert "<b>Не спамить</b>" in html_ and '<tg-emoji emoji-id="5006280533815068764">🦊</tg-emoji>' in html_
    assert rules_text.load("старые правила") == ("старые правила", None) and rules_text.to_plain("старые правила") == "старые правила"
    assert rules_text.load(None) is None


def test_commands_set_show_delete_and_legacy(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = None
        ms._members[(-1, 1)] = (time.monotonic(), SimpleNamespace(status="creator"))
        ms._members[(-1, 5)] = (time.monotonic(), SimpleNamespace(status="member"))
        # обычный участник сохранить не может
        m = message(entities=full_entities(), uid=5)
        await chatinfo.chatinfo_cmd(m, bot, db)
        assert await db.get_text(-1, "rules") is None
        # админ сохраняет
        m = message(entities=full_entities())
        await chatinfo.chatinfo_cmd(m, bot, db)
        assert "сохранены" in m._replies[0] and (await db.get_text(-1, "rules")).startswith('{"v":2')
        # «правила» отдаёт ровно тот же текст и entities, без parse_mode
        show = message("правила")
        await chatinfo.chatinfo_cmd(show, bot, db)
        text, kw = show._answers[0]
        assert text == "  1. Не спамить\n    - вложенный пункт 🦊 готово" and kw["parse_mode"] is None
        assert [e.type for e in kw["entities"]] == ["bold", "custom_emoji"]
        # приветствие подставляет правила с оформлением
        assert "<b>Не спамить</b>" in chatinfo.render_welcome("{rules}", 7, "Вася", "Чат", await db.get_text(-1, "rules"))
        # удаление
        d = message("-правила")
        await chatinfo.chatinfo_cmd(d, bot, db)
        assert await db.get_text(-1, "rules") is None
        s2 = message("правила")
        await chatinfo.chatinfo_cmd(s2, bot, db)
        assert "пока не заданы" in s2._replies[0]
        # старые правила (обычная строка) показываются как раньше
        await db.set_text(-1, "rules", "старый текст")
        s3 = message("правила")
        await chatinfo.chatinfo_cmd(s3, bot, db)
        assert "старый текст" in s3._replies[0]
        await db.close()
    run(go())


def test_set_rules_from_reply_and_limits(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        ms._members[(-1, 1)] = (time.monotonic(), SimpleNamespace(status="creator"))
        src = SimpleNamespace(text="Не грубить 🙂", entities=[ent("underline", 0, 3)], caption=None, caption_entities=None,
                              from_user=SimpleNamespace(id=9), forum_topic_created=None)
        m = message("+правила", None, reply=src)
        await chatinfo.chatinfo_cmd(m, None, db)
        text, ents = rules_text.load(await db.get_text(-1, "rules"))
        assert text == "Не грубить 🙂" and ents[0].type == "underline"
        long_ = message("+правила " + "а" * (rules_text.MAX_LEN + 1))
        await db.set_text(-1, "rules", None)
        await chatinfo.chatinfo_cmd(long_, None, db)
        assert await db.get_text(-1, "rules") is None                                  # слишком длинно
        bare = message("+правила")
        await chatinfo.chatinfo_cmd(bare, None, db)
        assert await db.get_text(-1, "rules") is None                                  # пустая команда без ответа
        await db.close()
    run(go())

"""Тесты ядра: разбор команд, ранги и права, наказания, антиспам, фильтры, ссылки, капча, массовые действия, подпись Mini App."""
import asyncio
import hashlib
import hmac
import json
import time
from datetime import timedelta
from types import SimpleNamespace
from urllib.parse import urlencode

import pytest

from bot import bulk, mod_service as ms
from bot.captcha_server import validate_init_data
from bot.cleanup import pick_candidates
from bot.db import DEFAULT_SETTINGS, Database
from bot.filters import FilterError, FilterSet, normalize, validate_regex
from bot.handlers import captcha
from bot.links import extract_hosts, host_allowed, normalize_domain
from bot.parsing import ModCommand, parse_duration, parse_mod_command, parse_period, parse_stats_command
from bot.ranks import DEFAULT_ACCESS, need_rank, tg_rank
from bot.spam import MsgInfo, SpamGuard


def run(coro):
    return asyncio.run(coro)


# ---------- вспомогательное ----------
class FakeBot:
    """Минимальный Telegram: статусы участников и журнал вызовов."""

    def __init__(self, members=None):
        self.members = members or {}
        self.calls = []

    async def me(self):
        return SimpleNamespace(id=999, username="helper_bot")

    async def get_chat_member(self, chat_id, user_id):
        if user_id not in self.members:
            raise RuntimeError("user not found")
        return self.members[user_id]

    async def get_chat(self, ident):
        raise RuntimeError("not found")

    def __getattr__(self, name):
        async def call(*a, **kw):
            self.calls.append((name, a, kw))
            return True
        return call

    def called(self, name):
        return [c for c in self.calls if c[0] == name]


def member(status="member", **rights):
    return SimpleNamespace(status=status, **rights)


ADMIN = member("administrator", can_restrict_members=True, can_delete_messages=True, can_pin_messages=True)
OWNER = member("creator")


@pytest.fixture(autouse=True)
def _fresh_member_cache():
    ms._members.clear()
    yield
    ms._members.clear()


# ---------- разбор команд ----------
def test_parse_duration_and_period():
    assert parse_duration("30м") == timedelta(minutes=30)
    assert parse_duration("2ч") == timedelta(hours=2)
    assert parse_duration("1д") == timedelta(days=1)
    assert parse_duration("0д") is None and parse_duration("abc") is None
    assert parse_period("2 недели") == timedelta(days=14)


def test_parse_mod_command_basic():
    c = parse_mod_command("бан @vasya 7д причина: спам")
    assert (c.name, c.target, c.duration, c.reason) == ("бан", "@vasya", timedelta(days=7), "спам")
    c = parse_mod_command("мут 30м")
    assert c.name == "мут" and c.duration == timedelta(minutes=30) and c.target is None
    assert parse_mod_command("варн 12345678").target == "12345678"


def test_parse_mod_command_ignores_chatter():
    for text in ("бан бы дать тебе", "привет всем", "", "мутный тип"):
        assert parse_mod_command(text) is None, text


def test_parse_mod_command_slash_aliases():
    c = parse_mod_command("/ban @vasya")
    assert c and c.name == "бан" and c.target == "@vasya"


def test_parse_stats_command():
    assert parse_stats_command("стата") is not None
    assert parse_stats_command("стата неделя").hours == 168
    assert parse_stats_command("сегодня всё стато") is None


# ---------- ранги ----------
def test_ranks_defaults_and_tg_rank():
    assert need_rank({}, "бан") == DEFAULT_ACCESS["бан"] == 3
    assert need_rank({"бан": 4}, "бан") == 4
    assert need_rank({}, "неизвестная") == 3
    assert tg_rank("creator", False) == 5
    assert tg_rank("administrator", True) == 3 and tg_rank("administrator", False) == 0
    assert tg_rank("member", True) == 0


def test_effective_rank_and_rank_cache(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot({1: ADMIN, 2: member(), 3: OWNER})
        assert await ms.effective_rank(bot, db, 10, 1) == 3
        assert await ms.effective_rank(bot, db, 10, 3) == 5
        assert await ms.effective_rank(bot, db, 10, 2) == 0
        await db.set_rank(10, 2, 2, 1, 1)
        assert await ms.effective_rank(bot, db, 10, 2) == 2          # выданный ранг виден сразу (кэш сброшен)
        await db.set_rank(10, 2, 0, 1, 2)
        assert await ms.effective_rank(bot, db, 10, 2) == 0
        await db.close()
    run(go())


def test_access_cache_invalidated_on_change(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        assert await db.get_access(1) == {}
        await db.set_access(1, "бан", 4)
        assert await db.get_access(1) == {"бан": 4}
        await db.reset_access(1)
        assert await db.get_access(1) == {}
        await db.close()
    run(go())


# ---------- права на наказания ----------
def test_can_act_rules(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot({1: ADMIN, 2: member(), 3: ADMIN, 4: member(), 5: OWNER})
        ok, _ = await ms.can_act(bot, 10, 1, 2, "restrict", db=db, command="бан")
        assert ok
        ok, why = await ms.can_act(bot, 10, 2, 4, "restrict", db=db, command="бан")       # обычный участник
        assert not ok and "модератор" in why.lower()
        ok, why = await ms.can_act(bot, 10, 1, 1, "restrict", db=db, command="бан")       # себя нельзя
        assert not ok
        ok, why = await ms.can_act(bot, 10, 1, 999, "restrict", db=db, command="бан")     # бота нельзя
        assert not ok
        ok, why = await ms.can_act(bot, 10, 1, 3, "restrict", db=db, command="бан")       # админа нельзя
        assert not ok and "Админ" in why
        ok, _ = await ms.can_act(bot, 10, 5, 2, "restrict", db=db, command="бан")         # создатель может
        assert ok
        await db.set_access(10, "бан", 5)                                                 # команду подняли до ранга 5
        ms._members.clear()
        ok, _ = await ms.can_act(bot, 10, 1, 2, "restrict", db=db, command="бан")
        assert not ok
        await db.close()
    run(go())


def test_apply_warn_limit_triggers_mute(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.set_setting(10, "warn_limit", 2)
        bot = FakeBot({7: member()})
        now = int(time.time())
        cmd = ModCommand("варн", None, None, "тест")
        t1 = await ms.apply(bot, db, cmd, 10, 1, 7, now)
        assert "1/2" in t1 and not bot.called("restrict_chat_member")
        t2 = await ms.apply(bot, db, cmd, 10, 1, 7, now + 1)
        assert "2/2" in t2 and bot.called("restrict_chat_member")                          # лимит → автомут
        assert await db.get_warns(10, 7, now + 2) == 0                                     # варны сброшены
        await db.close()
    run(go())


def test_apply_ban_unban_mute_and_history(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot({7: member()})
        now = int(time.time())
        await ms.apply(bot, db, ModCommand("бан", None, timedelta(days=1), "спам"), 10, 1, 7, now)
        assert bot.called("ban_chat_member")
        assert await db.get_state(10, 7, "ban", now + 10) is not None
        await ms.apply(bot, db, ModCommand("разбан", None, None, ""), 10, 1, 7, now + 20)
        assert bot.called("unban_chat_member") and await db.get_state(10, 7, "ban", now + 30) is None
        await ms.apply(bot, db, ModCommand("мут", None, timedelta(minutes=5), ""), 10, 1, 7, now + 40)
        assert bot.called("restrict_chat_member")
        assert await db.count_mod_history(10, 7) == 3
        await db.close()
    run(go())


def test_resolve_target_priority_and_unknown(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.remember_user(5, "vasya", "Вася")
        bot = FakeBot()
        uid, hint = await ms.resolve_target(bot, db, ModCommand("бан", "@vasya", None, ""), reply_user_id=9)
        assert (uid, hint) == (5, "")                                      # явный @ник важнее ответа
        uid, hint = await ms.resolve_target(bot, db, ModCommand("бан", None, None, ""), reply_user_id=9)
        assert uid == 9
        uid, hint = await ms.resolve_target(bot, db, ModCommand("бан", "123456789", None, ""), None)
        assert uid == 123456789 and await db.user_name(123456789) == "id123456789"   # id запоминается сразу
        uid, hint = await ms.resolve_target(bot, db, ModCommand("бан", "@nobodyhere", None, ""), None)
        assert uid is None and "@nobodyhere" in hint
        await db.close()
    run(go())


# ---------- антиспам ----------
S = dict(DEFAULT_SETTINGS, spam_on=1, spam_flood_n=3, spam_flood_sec=10, spam_dup=1, links_mode="newbies",
         spam_mentions=3, spam_forward=1)


def info(text="привет", links=0, mentions=0, fwd=False, group=None):
    return MsgInfo(text, links, mentions, fwd, group)


def test_spam_flood_and_reset():
    g = SpamGuard()
    assert g.check(1, 1, info("а"), 100.0, S, False) is None
    assert g.check(1, 1, info("б"), 101.0, S, False) is None
    assert g.check(1, 1, info("в"), 102.0, S, False) == "флуд"
    assert g.check(1, 1, info("г"), 103.0, S, False) is None            # окно сброшено после срабатывания
    assert g.check(1, 2, info("д"), 103.0, S, False) is None            # другой пользователь не затронут


def test_spam_duplicates_links_mentions_forwards():
    g = SpamGuard()
    t = "это одно и то же длинное сообщение"
    results = [g.check(1, 1, info(t), 100.0 + i * 20, S, False) for i in range(3)]
    assert results[:2] == [None, None] and results[2] == "повторы"
    assert g.check(1, 2, info(links=1), 1.0, S, True) == "ссылка от новичка"
    assert g.check(1, 3, info(links=1), 1.0, S, False) is None            # старожилу можно
    assert g.check(1, 4, info(mentions=4), 1.0, S, False) == "массовые упоминания"
    assert g.check(1, 5, info(fwd=True), 1.0, S, True) == "пересылка от новичка"
    assert g.check(1, 6, info(links=1), 1.0, dict(S, links_mode="all"), False) == "ссылка не из белого списка"


def test_spam_album_counts_once():
    g = SpamGuard()
    for i in range(6):
        assert g.check(1, 1, info("", group="alb1"), 100.0 + i * 0.1, S, False) is None


# ---------- фильтры ----------
def test_filter_words_evasion():
    fs = FilterSet([{"id": 1, "kind": "word", "pattern": "казино"}])
    for text in ("играй в казино", "КАЗИНО!!", "каЗино", "казиино", "казино.com"):
        assert fs.first_match(text) == 1, text
    assert fs.first_match("казиношка") is None                           # только целое слово
    assert fs.first_match("привет") is None
    assert fs.first_match("к а з и н о") is None                         # известное ограничение: буквы через пробел не ловятся


def test_filter_regex_validation_and_timeout():
    validate_regex(r"\d{3}-\d{2}")
    for bad in (r"(a+)+$", r"(?=x)y", r"(a|aa)*", "", "x" * 500, r"(\w)\1"):
        with pytest.raises(FilterError):
            validate_regex(bad)
    fs = FilterSet([{"id": 7, "kind": "regex", "pattern": r"\d{3}-\d{2}"}])
    assert fs.first_match("код 123-45") == 7 and fs.first_match("ничего") is None


def test_normalize_collapses_tricks():
    assert normalize("Ка​зи́но") == normalize("казино")


# ---------- ссылки ----------
def test_links_extract_and_allowlist():
    ents = []
    hosts = extract_hosts("смотри https://www.Example.com/a?b=1 и t.me/x и www.test.ru", ents)
    assert {"example.com", "t.me", "test.ru"} <= hosts
    assert normalize_domain("*.Example.org") == "*.example.org" and normalize_domain("мусор") is None
    allow = {"example.com", "*.cdn.org"}
    assert host_allowed("example.com", allow) and not host_allowed("sub.example.com", allow)
    assert host_allowed("a.b.cdn.org", allow) and host_allowed("cdn.org", allow)


# ---------- капча ----------
def test_captcha_pick_level():
    chat = 555
    captcha._fails.pop(chat, None)
    u = SimpleNamespace(username="x", is_premium=False)
    assert captcha.pick_level(chat, False, u) == 0
    assert captcha.pick_level(chat, True, u) == 2                         # рейд — максимум
    for _ in range(captcha.HEAVY_FAILS):
        captcha.record_failure(chat)
    assert captcha.pick_level(chat, False, u) >= 1
    nick_less = SimpleNamespace(username=None, is_premium=False)
    assert captcha.pick_level(chat, False, nick_less) >= captcha.pick_level(chat, False, u)
    captcha._fails.pop(chat, None)


def test_captcha_recheck_logic(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot({8: SimpleNamespace(status="member", user=SimpleNamespace(
            id=8, is_bot=False, full_name="Без ника", username=None, is_premium=False))})
        captcha._rechecked.clear()
        assert await captcha._recheck(bot, db, 10, 8, "") is False             # выключено
        await db.set_setting(10, "captcha_recheck", "susp")
        called = []

        async def fake_join(*a, **kw):
            called.append(kw)
        orig = captcha.handle_join
        captcha.handle_join = fake_join
        try:
            assert await captcha._recheck(bot, db, 10, 8, "https://x") is True
            assert called and called[0]["min_level"] == 1 and called[0]["source"] == "recheck"
            assert await captcha._recheck(bot, db, 10, 8, "https://x") is False   # второй раз не просим
        finally:
            captcha.handle_join = orig
        await db.close()
    run(go())


# ---------- подпись Mini App ----------
def _signed(token, user, age=0, tamper=False):
    data = {"auth_date": str(int(time.time()) - age), "user": json.dumps(user), "query_id": "q"}
    dcs = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    data["hash"] = hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest()
    if tamper:
        data["user"] = json.dumps({"id": 1})
    return urlencode(data)


def test_validate_init_data():
    tok = "123:ABC"
    ok = validate_init_data(_signed(tok, {"id": 42}), tok, max_age=300)
    assert ok and ok["user"]["id"] == 42
    assert validate_init_data(_signed(tok, {"id": 42}), "other:TOKEN", max_age=300) is None
    assert validate_init_data(_signed(tok, {"id": 42}, age=1000), tok, max_age=300) is None
    assert validate_init_data(_signed(tok, {"id": 42}, tamper=True), tok, max_age=300) is None
    assert validate_init_data("", tok) is None and validate_init_data("a=b", tok) is None


# ---------- массовые действия и чистка ----------
def test_bulk_parse_targets():
    targets, invalid = bulk.parse_targets("@vasya, 123456789 https://t.me/petya мусор@@ @vasya")
    idents = [(t.uid, t.name) for t in targets]
    assert (None, "vasya") in idents and (123456789, None) in idents and (None, "petya") in idents
    assert len([i for i in idents if i == (None, "vasya")]) == 1            # дубль убран
    assert invalid
    with pytest.raises(bulk.BulkError):
        bulk.parse_targets(" ".join(str(100000 + i) for i in range(bulk.MAX_BULK + 1)))


def test_bulk_unknown_nick_ban_is_pending_others_skipped(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot({1: OWNER})
        targets, _ = bulk.parse_targets("@ghostuser")
        now = int(time.time())
        res = await bulk.bulk_action(bot, db, 10, 1, targets, "бан", "тест", None, now, owner=True, protected=frozenset({1}))
        assert res[0].status == "pending" and db.has_pending("ghostuser")
        res = await bulk.bulk_action(bot, db, 10, 1, targets, "мут", "", None, now, owner=True, protected=frozenset({1}))
        assert res[0].status == "skipped"
        await db.close()
    run(go())


def test_cleanup_pick_candidates():
    now = 1_000_000
    members = [
        {"user_id": 1, "first_seen": now - 50 * 86400, "last_seen": now - 40 * 86400, "joined_at": now - 50 * 86400},
        {"user_id": 2, "first_seen": now - 100, "last_seen": now - 10, "joined_at": now - 100},
        {"user_id": 3, "first_seen": now - 50 * 86400, "last_seen": now - 5, "joined_at": now - 50 * 86400},
    ]
    month = 30 * 86400
    assert pick_candidates("неактив", members, {2}, now, month, set(), last_msg={1: now - 40 * 86400, 2: now - 5}) == [1, 3]
    assert pick_candidates("новичков", members, set(), now, 3600, set()) == [2]
    assert pick_candidates("молчунов", members, {1}, now, month, set()) == [3]
    assert pick_candidates("неактив", members, set(), now, month, {1}, last_msg={}) == [3]       # исключённых не трогаем


# ---------- БД: варны и ожидающие баны ----------
def test_db_warns_expire(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        now = 10_000
        await db.add_warn(1, 5, now=now, ttl=100, reason="a", actor=1)
        assert await db.get_warns(1, 5, now + 50) == 1
        assert await db.get_warns(1, 5, now + 200) == 0                      # срок вышел
        await db.add_warn(1, 5, now=now, ttl=None, reason="b", actor=1)
        assert await db.get_warns(1, 5, now + 10**6) == 1                    # бессрочный
        await db.close()
    run(go())

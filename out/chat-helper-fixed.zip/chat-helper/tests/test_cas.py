"""Проверка новичков по базе спамеров CAS (сеть подменена)."""
import asyncio
from types import SimpleNamespace

import pytest

from bot import cas, mod_service as ms
from bot.db import Database
from bot.handlers import captcha


def run(coro):
    return asyncio.run(coro)


class FakeBot:
    def __init__(self, members=None):
        self.members, self.calls = members or {}, []

    async def me(self):
        return SimpleNamespace(id=999, username="helper_bot")

    async def get_chat_member(self, chat_id, user_id):
        if user_id not in self.members:
            raise RuntimeError("no member")
        return self.members[user_id]

    def __getattr__(self, name):
        async def call(*a, **kw):
            self.calls.append((name, a, kw))
            return SimpleNamespace(message_id=500)
        return call

    def names(self):
        return [c[0] for c in self.calls]


ORIG_FETCH = cas._fetch_cas                      # настоящая функция (фикстура подменяет cas._fetch)
USER = SimpleNamespace(id=42, is_bot=False, full_name="Спамер", username=None, is_premium=False)


@pytest.fixture(autouse=True)
def _clean(monkeypatch):
    cas._cache.clear()
    ms._members.clear()
    monkeypatch.setenv("CAS_API_KEY", "test-key")
    calls = []

    async def fake_fetch(uid):
        calls.append(uid)
        return uid == 42
    monkeypatch.setattr(cas, "_fetch", fake_fetch)
    monkeypatch.setattr(cas, "FETCHED", calls, raising=False)
    yield calls


def test_is_spammer_uses_cache(_clean):
    async def go():
        assert await cas.is_spammer(42) is True
        assert await cas.is_spammer(42) is True and await cas.is_spammer(7) is False
        assert await cas.is_spammer(7) is False
    run(go())
    assert _clean == [42, 7]                                           # повторные запросы идут из кэша


def test_network_failure_does_not_block(monkeypatch):
    async def none(uid):
        return None
    monkeypatch.setattr(cas, "_fetch", none)
    assert run(cas.is_spammer(42)) is False


def test_handle_modes(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot()
        assert await cas.handle(bot, db, -1, USER, "off") is None and not bot.calls            # выключено
        assert await cas.handle(bot, db, -1, SimpleNamespace(id=7, is_bot=False, full_name="Ок"), "ban") is None
        assert await cas.handle(bot, db, -1, USER, "warn") == "warn"
        assert "ban_chat_member" not in bot.names() and "send_message" in bot.names()          # только уведомление
        kb = bot.calls[-1][2]["reply_markup"].inline_keyboard[0]
        assert [b.callback_data for b in kb] == ["cas:ban:42", "cas:ok:42"]
        bot.calls.clear()
        assert await cas.handle(bot, db, -1, USER, "ban") == "ban"
        assert bot.names()[0] == "ban_chat_member"
        assert await db.count_mod_history(-1, 42) == 1                                         # запись в журнале
        await db.close()
    run(go())


def test_allowlist_after_false_positive(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot({1: SimpleNamespace(status="creator")})
        sent = []

        async def edit_text(text, reply_markup=None):
            sent.append(text)

        async def answer(*a, **kw):
            pass
        cb = SimpleNamespace(data="cas:ok:42", from_user=SimpleNamespace(id=1), answer=answer,
                             message=SimpleNamespace(chat=SimpleNamespace(id=-1), edit_text=edit_text))
        await cas.on_button(cb, bot, db)
        assert "unban_chat_member" in bot.names() and await db.cas_allowed(-1, 42)
        bot.calls.clear()
        assert await cas.handle(bot, db, -1, USER, "ban") is None and not bot.calls          # больше не трогаем
        # обычный участник нажать не может
        cb2 = SimpleNamespace(data="cas:ban:42", from_user=SimpleNamespace(id=5), answer=answer,
                              message=SimpleNamespace(chat=SimpleNamespace(id=-1), edit_text=edit_text))
        ms._members[(-1, 5)] = (__import__("time").monotonic(), SimpleNamespace(status="member"))
        bot.calls.clear()
        await cas.on_button(cb2, bot, db)
        assert "ban_chat_member" not in bot.names()
        await db.close()
    run(go())


def req(uid=42, query_id=None):
    return SimpleNamespace(query_id=query_id, chat=SimpleNamespace(id=-100, title="Чат", type="supergroup"),
                           from_user=SimpleNamespace(id=uid, is_bot=False, full_name="Спамер", username=None, is_premium=False),
                           user_chat_id=uid)


def test_join_requests_declined_or_queued(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.set_setting(-100, "cas_mode", "ban")
        bot = FakeBot()
        await captcha.on_join_request(req(query_id="Q1"), bot, db, "https://x.example")        # страж: отклонить
        assert ("answer_chat_join_request_query" in bot.names()
                and [c for c in bot.calls if c[0] == "answer_chat_join_request_query"][0][1] == ("Q1", "decline"))
        bot.calls.clear()
        await captcha.on_join_request(req(), bot, db, "https://x.example")                     # обычная заявка
        assert "decline_chat_join_request" in bot.names()
        await db.set_setting(-100, "cas_mode", "warn")
        bot.calls.clear()
        await captcha.on_join_request(req(query_id="Q2"), bot, db, "https://x.example")
        assert [c for c in bot.calls if c[0] == "answer_chat_join_request_query"][0][1] == ("Q2", "queue")
        await db.close()
    run(go())


def test_real_fetch_parses_cas_responses(monkeypatch):
    from aiohttp import web

    seen_auth = []

    async def handler(request):
        uid = request.query.get("user_id")
        seen_auth.append(request.headers.get("Authorization"))
        if uid == "401":
            return web.json_response({"ok": False, "error_code": 401, "description": "API key required"}, status=401)
        if uid == "42":
            return web.json_response({"ok": True, "result": {"offenses": 3}})
        if uid == "500":
            return web.Response(status=500, text="boom")
        return web.json_response({"ok": False, "description": "Record not found."})

    async def go():
        app = web.Application()
        app.router.add_get("/check", handler)
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "127.0.0.1", 0)
        await site.start()
        port = site._server.sockets[0].getsockname()[1]
        monkeypatch.setattr(cas, "URL", f"http://127.0.0.1:{port}/check")
        try:
            return [await ORIG_FETCH(42), await ORIG_FETCH(7), await ORIG_FETCH(500), await ORIG_FETCH(401)]
        finally:
            await runner.cleanup()
    assert run(go()) == [True, False, None, None]                        # найден / нет в базе / сбой сервиса / ключ отклонён
    assert set(seen_auth) == {"Bearer test-key"}                         # ключ идёт в заголовке, не в адресе


def test_cas_is_skipped_without_key_but_lols_still_works(monkeypatch):
    from aiohttp import web
    monkeypatch.delenv("CAS_API_KEY", raising=False)
    assert cas.has_key() is False and run(cas._fetch_cas(42)) is None              # без ключа CAS в сеть не ходит

    async def lols(request):
        banned = request.query.get("id") == "42"
        return web.json_response({"ok": True, "user_id": int(request.query["id"]), "banned": banned})

    async def go():
        app = web.Application()
        app.router.add_get("/account", lols)
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "127.0.0.1", 0)
        await site.start()
        port = site._server.sockets[0].getsockname()[1]
        monkeypatch.setattr(cas, "LOLS_URL", f"http://127.0.0.1:{port}/account")
        try:
            return [await cas._fetch_lols(42), await cas._fetch_lols(7), await ORIG_COMBINED(42), await ORIG_COMBINED(7)]
        finally:
            await runner.cleanup()
    assert run(go()) == [True, False, True, False]                                   # источники объединяются


ORIG_COMBINED = cas._fetch

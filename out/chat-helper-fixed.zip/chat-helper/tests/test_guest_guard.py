"""Бот-страж заявок (капча прямо в заявке) и защита от гостевых ботов."""
import asyncio
import time
from types import SimpleNamespace

import pytest

from bot import guestbots, mod_service as ms
from bot.db import Database
from bot.handlers import captcha
from bot.middlewares.guard import GuardMiddleware


def run(coro):
    return asyncio.run(coro)


class FakeBot:
    def __init__(self, members=None):
        self.members, self.calls = members or {}, []

    async def me(self):
        return SimpleNamespace(id=999, username="helper_bot")

    async def get_chat_member(self, chat_id, user_id):
        if user_id not in self.members:
            raise RuntimeError("no such member")
        return self.members[user_id]

    async def get_chat(self, ident):
        raise RuntimeError("n/a")

    def __getattr__(self, name):
        async def call(*a, **kw):
            self.calls.append((name, a, kw))
            return SimpleNamespace(message_id=500)
        return call

    def names(self):
        return [c[0] for c in self.calls]


@pytest.fixture(autouse=True)
def _clean():
    ms._members.clear()
    captcha._passed.clear()
    yield
    ms._members.clear()


def req(user_id=7, is_bot=False, query_id="Q1", chat_id=-100):
    return SimpleNamespace(query_id=query_id, chat=SimpleNamespace(id=chat_id, title="Чат", type="supergroup"),
                           from_user=SimpleNamespace(id=user_id, is_bot=is_bot, full_name="Вася", username="vasya",
                                                     is_premium=False),
                           user_chat_id=user_id)


# ---------- страж заявок ----------
def test_guard_shows_captcha_in_the_request(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.set_setting(-100, "captcha_on", 1)
        bot = FakeBot()
        await captcha.on_join_request(req(), bot, db, "https://x.example")
        (call,) = [c for c in bot.calls if c[0] == "send_chat_join_request_web_app"]
        assert call[1][0] == "Q1" and call[1][1].startswith("https://x.example/captcha?token=")
        token = call[1][1].split("token=")[1]
        cap = await db.get_captcha(token)
        assert cap["kind"] == "guard" and cap["user_id"] == 7
        assert await db.guard_query_pop(-100, 7) == "Q1" and await db.guard_query_pop(-100, 7) is None
        assert not [c for c in bot.calls if c[0] == "send_message"]               # ни писем в личку, ни сообщений в чат
        await db.close()
    run(go())


def test_guard_without_captcha_follows_setting_and_declines_bots_and_banned(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.set_setting(-100, "captcha_on", 0)
        bot = FakeBot()
        await captcha.on_join_request(req(), bot, db, "https://x.example")             # капча выключена → админам
        assert bot.calls[-1][0] == "answer_chat_join_request_query" and bot.calls[-1][1][1] == "queue"
        await db.set_setting(-100, "guard_default", "approve")
        await captcha.on_join_request(req(), bot, db, "https://x.example")
        assert bot.calls[-1][1][1] == "approve"
        await captcha.on_join_request(req(is_bot=True), bot, db, "https://x.example")
        assert bot.calls[-1][1][1] == "decline"
        await db.set_state(-100, 8, "ban", None, "x", 1, int(time.time()))
        await captcha.on_join_request(req(user_id=8), bot, db, "https://x.example")
        assert bot.calls[-1][1][1] == "decline"
        await db.close()
    run(go())


def test_guard_falls_back_to_queue_when_web_app_cannot_be_shown(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.set_setting(-100, "captcha_on", 1)

        class Bot(FakeBot):
            async def send_chat_join_request_web_app(self, *a, **kw):
                raise RuntimeError("too late")
        bot = Bot()
        await captcha.on_join_request(req(), bot, db, "https://x.example")
        assert bot.calls[-1][0] == "answer_chat_join_request_query" and bot.calls[-1][1][1] == "queue"
        await db.close()
    run(go())


def test_guard_pass_approves_and_expiry_declines(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot()
        await db.guard_query_set(-100, 7, "Q1", 1)
        await captcha.make_on_pass(bot, db)(-100, 7, 0, kind="guard")
        assert bot.calls[-1][0] == "answer_chat_join_request_query" and bot.calls[-1][1] == ("Q1", "approve")
        assert (-100, 7) in captcha._passed                                            # welcome без повторной капчи
        await db.guard_query_set(-100, 8, "Q2", 1)
        await captcha.expire_captcha(bot, {"chat_id": -100, "user_id": 8, "kind": "guard", "message_id": 0}, db)
        assert bot.calls[-1][1] == ("Q2", "decline")
        await captcha.expire_captcha(bot, {"chat_id": -100, "user_id": 9, "kind": "guard", "message_id": 0}, db)
        assert bot.calls[-1][0] == "decline_chat_join_request"                         # запроса нет — обычный отказ
        await db.close()
    run(go())


def test_ordinary_join_request_flow_is_unchanged(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.set_setting(-100, "captcha_on", 1)
        bot = FakeBot()
        await captcha.on_join_request(req(query_id=None), bot, db, "https://x.example")
        assert bot.names() == ["send_message"]                                         # как раньше: письмо в личку
        await db.close()
    run(go())


# ---------- гостевые боты ----------
def gmsg(text="привет", bot_id=500, caller=77, mid=1, chat_id=-100, bot_username="spambot"):
    return SimpleNamespace(
        chat=SimpleNamespace(id=chat_id, type="supergroup"), message_id=mid, text=text, caption=None,
        entities=None, caption_entities=None, forward_origin=None, media_group_id=None, sender_chat=None,
        from_user=SimpleNamespace(id=bot_id, is_bot=True, username=bot_username),
        guest_bot_caller_user=SimpleNamespace(id=caller, is_bot=False), guest_bot_caller_chat=None)


def guard(db):
    return GuardMiddleware(db)


def test_is_guest_message():
    assert guestbots.is_guest_message(gmsg())
    assert not guestbots.is_guest_message(SimpleNamespace(guest_bot_caller_user=None, guest_bot_caller_chat=None))


def test_guest_modes(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot({77: SimpleNamespace(status="member"), 88: SimpleNamespace(status="creator")})
        g = guard(db)
        data = {"bot": bot}
        # check (по умолчанию): обычное сообщение проходит
        assert await g._guest(gmsg(), data) is False
        await db.set_setting(-100, "guest_mode", "block")
        assert await g._guest(gmsg(mid=2), data) is True and bot.calls and bot.calls[0][0] == "delete_message"
        # админ как вызывающий не ограничивается
        bot.calls.clear()
        assert await g._guest(gmsg(mid=3, caller=88), data) is False and not bot.calls
        # белый список: незнакомый бот — удалить, разрешённый — пропустить
        await db.set_setting(-100, "guest_mode", "allowlist")
        assert await g._guest(gmsg(mid=4, bot_id=501), data) is True
        await db.guest_set_status(-100, 502, "goodbot", guestbots.STATUS_ALLOWED, 1)
        assert await g._guest(gmsg(mid=5, bot_id=502), data) is False
        # запрещённый бот удаляется даже в режиме check
        await db.set_setting(-100, "guest_mode", "check")
        await db.guest_set_status(-100, 503, "evilbot", guestbots.STATUS_BLOCKED, 1)
        assert await g._guest(gmsg(mid=6, bot_id=503), data) is True
        # выключено — не вмешиваемся
        await db.set_setting(-100, "guest_mode", "off")
        assert await g._guest(gmsg(mid=7, bot_id=503), data) is False
        await db.close()
    run(go())


def test_guest_flood_filters_and_strikes(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot({77: SimpleNamespace(status="member")})
        g = guard(db)
        data = {"bot": bot}
        res = [await g._guest(gmsg(mid=i), data) for i in range(1, 10)]
        assert res[:guestbots.FLOOD_N] == [False] * guestbots.FLOOD_N and True in res        # флуд ловится после порога
        # три удаления подряд → мут вызвавшего
        bot.calls.clear()
        await db.set_setting(-100, "guest_mode", "block")
        for i in range(20, 24):
            await g._guest(gmsg(mid=i), data)
        assert "restrict_chat_member" in bot.names()
        await db.close()
    run(go())


def test_guest_commands_allow_block_list(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        bot = FakeBot({1: SimpleNamespace(status="creator")})
        await db.guest_seen(-100, 500, "newsbot", 1)
        replies = []

        async def reply(text, **kw):
            replies.append(text)

        def msg(text, uid=1):
            return SimpleNamespace(chat=SimpleNamespace(id=-100, type="supergroup"), from_user=SimpleNamespace(id=uid),
                                   text=text, reply=reply, message_thread_id=None, is_topic_message=False, bot=bot)
        await guestbots.guest_cmd(msg("+гостевой @newsbot"), bot, db)
        assert (await db.guest_list(-100))[0]["status"] == guestbots.STATUS_ALLOWED
        await guestbots.guest_cmd(msg("-гостевой @newsbot"), bot, db)
        assert (await db.guest_list(-100))[0]["status"] == guestbots.STATUS_BLOCKED
        await guestbots.guest_cmd(msg("гостевые боты"), bot, db)
        assert "newsbot" in replies[-1] and "запрещён" in replies[-1]
        n = len(replies)
        ms._members[(-100, 5)] = (time.monotonic(), SimpleNamespace(status="member"))
        await guestbots.guest_cmd(msg("+гостевой @newsbot", uid=5), bot, db)             # обычный участник — игнор
        assert len(replies) == n and (await db.guest_list(-100))[0]["status"] == guestbots.STATUS_BLOCKED
        await db.close()
    run(go())


def test_guest_message_content_checks_stop_words_and_phishing(tmp_path):
    async def go():
        db = await Database.connect(str(tmp_path / "t.db"))
        await db.add_filter(-100, "word", "казино", 1, int(time.time()))
        await db.set_setting(-100, "phish_on", 1)
        bot = FakeBot({77: SimpleNamespace(status="member")})
        g = guard(db)
        data = {"bot": bot}
        assert await g._guest(gmsg("лучшее казино тут", mid=1), data) is True            # стоп-слово
        assert await g._guest(gmsg("заходи telegram-premium.xyz", mid=2), data) is True  # фишинг-ссылка (в тексте, без entities)
        assert await g._guest(gmsg("обычный ответ бота", mid=3), data) is False
        names = [c[0] for c in bot.calls]
        assert names.count("delete_message") == 2
        await db.close()
    run(go())

(() => {
  const tg = window.Telegram && window.Telegram.WebApp;
  if (tg) {
    tg.ready(); tg.expand();
    try { tg.setBackgroundColor("#000000"); tg.setHeaderColor("#000000"); } catch (e) {}
  }
  const token = new URLSearchParams(location.search).get("token") || "";
  const initData = tg ? tg.initData : "";
  const $ = (id) => document.getElementById(id);
  const slot = $("slot"), input = $("answer"), submit = $("submit"), status = $("status"), hint = $("hint");

  let need = 5;   // длину кода сообщает сервер (X-Code-Length): при повышенной сложности код длиннее
  const update = () => { submit.disabled = input.value.trim().length < need; };
  input.addEventListener("input", () => {
    input.value = input.value.toUpperCase().replace(/[^A-Z0-9]/g, "");
    update();
  });
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !submit.disabled) submit.click(); });

  async function load() {
    if (!initData) { hint.textContent = "Откройте проверку из Telegram."; input.hidden = submit.hidden = true; return; }
    const r = await fetch("/captcha/image?token=" + encodeURIComponent(token),
      { headers: { "X-Init-Data": initData } });
    if (!r.ok) { hint.textContent = "Проверка недоступна или уже пройдена."; input.hidden = submit.hidden = true; return; }
    need = parseInt(r.headers.get("X-Code-Length") || "5", 10) || 5;
    input.maxLength = need;
    const img = new Image(260, 100);  // тег создаём сразу с адресом картинки
    img.id = "code"; img.alt = "Код проверки";
    img.src = URL.createObjectURL(await r.blob());
    slot.replaceChildren(img);
    input.focus();
  }

  submit.onclick = async () => {
    submit.disabled = true; status.textContent = "Проверяем…";
    let j = { ok: false };
    try {
      const r = await fetch("/captcha/verify", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, answer: input.value.trim(), initData }),
      });
      j = await r.json();
    } catch (e) { /* сеть */ }
    if (j.ok) {
      status.textContent = "Готово, можно писать в чат ✓";
      setTimeout(() => tg && tg.close(), 600);
    } else {
      status.textContent = j.error === "attempts" ? "Слишком много попыток." : "Неверный код, попробуйте ещё раз.";
      document.querySelector("main").classList.add("shake");
      setTimeout(() => document.querySelector("main").classList.remove("shake"), 400);
      input.value = ""; update(); input.focus();
    }
  };

  load().catch(() => { hint.textContent = "Ошибка сети, откройте проверку заново."; });
})();

(() => {
  const tg = window.Telegram && window.Telegram.WebApp;
  if (tg) {
    tg.ready(); tg.expand();
    try { tg.setBackgroundColor("#000000"); tg.setHeaderColor("#000000"); } catch (e) {}
  }
  const token = new URLSearchParams(location.search).get("token") || "";
  const initData = tg ? tg.initData : "";
  const $ = (id) => document.getElementById(id);
  const slot = $("slot"), input = $("answer"), submit = $("submit"), status = $("status"), hint = $("hint"), ts = $("ts");

  const fail = (text) => { hint.textContent = text; input.hidden = submit.hidden = ts.hidden = true; };
  const shake = () => {
    const m = document.querySelector("main"); m.classList.add("shake"); setTimeout(() => m.classList.remove("shake"), 400);
  };
  async function send(payload) {
    const r = await fetch("/captcha/verify", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(Object.assign({ token, initData }, payload)),
    });
    return r.json();
  }
  const done = () => { status.textContent = "Готово, можно писать в чат ✓"; setTimeout(() => tg && tg.close(), 600); };

  // ---------- Cloudflare Turnstile ----------
  function loadTurnstile() {
    return new Promise((resolve, reject) => {
      if (window.turnstile) return resolve(window.turnstile);
      const s = document.createElement("script");
      s.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
      s.async = true; s.onload = () => resolve(window.turnstile); s.onerror = reject;
      document.head.appendChild(s);
    });
  }
  async function startTurnstile(info) {
    hint.textContent = "Подтвердите, что вы не бот";
    const t = await loadTurnstile();
    ts.hidden = false;
    let widget = null;
    const onToken = async (value) => {
      status.textContent = "Проверяем…";
      let j = { ok: false };
      try { j = await send({ turnstile: value }); } catch (e) { /* сеть */ }
      if (j.ok) return done();
      status.textContent = j.error === "attempts" ? "Слишком много попыток." : j.error === "network" ? "Сервис проверки недоступен, попробуйте ещё раз." : "Проверка не пройдена, попробуйте ещё раз.";
      shake();
      if (j.error !== "attempts" && widget !== null) t.reset(widget);
    };
    widget = t.render("#ts", {
      sitekey: info.sitekey, cdata: info.cdata, theme: (tg && tg.colorScheme) || "auto", language: "auto",
      callback: onToken,
      "error-callback": () => { status.textContent = "Не удалось загрузить проверку, откройте её заново."; },
      "expired-callback": () => { if (widget !== null) t.reset(widget); },
    });
  }

  // ---------- запасная капча: код с картинки (если Turnstile не настроен) ----------
  let need = 5;   // длину кода сообщает сервер (X-Code-Length): при повышенной сложности код длиннее
  const update = () => { submit.disabled = input.value.trim().length < need; };
  input.addEventListener("input", () => { input.value = input.value.toUpperCase().replace(/[^A-Z0-9]/g, ""); update(); });
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !submit.disabled) submit.click(); });
  async function startImage() {
    const r = await fetch("/captcha/image?token=" + encodeURIComponent(token), { headers: { "X-Init-Data": initData } });
    if (!r.ok) return fail("Проверка недоступна или уже пройдена.");
    need = parseInt(r.headers.get("X-Code-Length") || "5", 10) || 5;
    input.maxLength = need; input.hidden = submit.hidden = false;
    hint.textContent = "Введите код с картинки";
    const img = new Image(260, 100);  // тег создаём сразу с адресом картинки
    img.id = "code"; img.alt = "Код проверки";
    img.src = URL.createObjectURL(await r.blob());
    slot.replaceChildren(img);
    input.focus();
  }
  submit.onclick = async () => {
    submit.disabled = true; status.textContent = "Проверяем…";
    let j = { ok: false };
    try { j = await send({ answer: input.value.trim() }); } catch (e) { /* сеть */ }
    if (j.ok) return done();
    status.textContent = j.error === "attempts" ? "Слишком много попыток." : "Неверный код, попробуйте ещё раз.";
    shake(); input.value = ""; update(); input.focus();
  };

  async function load() {
    if (!initData) return fail("Откройте проверку из Telegram.");
    const r = await fetch("/captcha/info?token=" + encodeURIComponent(token), { headers: { "X-Init-Data": initData } });
    if (!r.ok) return fail("Проверка недоступна или уже пройдена.");
    const info = await r.json();
    if (info.mode === "turnstile") return startTurnstile(info);
    return startImage();
  }
  load().catch(() => fail("Ошибка сети, откройте проверку заново."));
})();

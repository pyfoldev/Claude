import asyncio
import logging
import os
import sys
import time

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import BotCommand
from aiohttp import web

import aiohttp

from bot.ai import AiClient
from bot.alerts import Alerter, clear_marker, make_error_handler, set_marker_and_check_crash, supervise
from bot.audit import Auditor
from bot.backup import backup_loop
from bot import members
from bot.webhook import register_webhook, webhook_target, webhook_watch
from bot.captcha_server import build_app
from bot.panel_server import PanelContext, add_panel_routes
from bot.config import load_config
from bot.emoji_inject import EmojiSession
from bot.db import Database
from bot.handlers import ai as ai_handlers
from bot.handlers import owner as owner_handlers
from bot.handlers import captcha, duels, fun, games, menu, moderation, settings, stats
from bot.handlers import chatinfo as chatinfo_handlers
from bot.handlers import economy as economy_handlers
from bot.handlers import entertainment as fun_handlers
from bot.handlers import inline as inline_handlers, memory as memory_handlers, polls as polls_handlers
from bot import dupes as dupes_module
from bot import guestbots as guestbots_module
from bot import cas as cas_module
from bot.handlers import pair as pair_handlers
from bot.pair.service import PairService
from bot.handlers import votes as vote_handlers
from bot.handlers import cleanup as cleanup_handlers
from bot.handlers import purge as purge_handlers
from bot.handlers import family as family_handlers
from bot.handlers import ranks as rank_handlers
from bot.handlers import rp as rp_handlers
from bot.handlers import scan as scan_handlers
from bot.handlers import social as social_handlers
from bot.handlers import garden as garden_handlers
from bot.handlers import setup as setup_handlers
from bot.handlers import history as history_handlers
from bot.handlers import logchat as logchat_handlers
from bot.handlers import reports as reports_handlers
from bot.handlers import chatfilters as chatfilters_handlers
from bot.handlers import aimod as aimod_handlers
from bot.handlers import webpanel as webpanel_handlers
from bot.handlers import giveaway as giveaway_handlers
from bot.handlers import suggest as suggest_handlers
from bot.handlers import images as images_handlers
from bot.handlers import download as download_handlers
from bot.handlers import premium as premium_handlers
from bot.imagegen import ImageGen
from bot.handlers import quotes as quotes_handlers
from bot.handlers import mog as mog_handlers
from bot.giveaway_server import add_giveaway_routes
from bot.metrics import Metrics, MetricsMiddleware
from bot.updatequeue import UpdateQueue
from bot.middlewares.blocklist import BlockMiddleware
from bot.middlewares.counter import CounterMiddleware
from bot.middlewares.guard import GuardMiddleware
from bot.middlewares.memory import ChatMemoryMiddleware
from bot.middlewares.prefix import NoriPrefixMiddleware
from bot.ttl import prune_stale
from bot.nsfw import NsfwDetector
from bot.runtime import Runtime
from bot.middlewares.tracker import UserTrackerMiddleware
from bot import i18n
from bot.middlewares.quiet import QuietTopicMiddleware
from bot.handlers import topics as topics_handlers


async def rollup_loop(db: Database) -> None:
    while True:
        try:
            await db.rollup_old(int(time.time()))
            await db.prune_old(int(time.time()))
            await db.optimize()                       # статистика для планировщика запросов — раз в сутки
            for d, age in ((fun._last, 3600), (chatinfo_handlers._last, 3600), (ai_handlers._last_ask, 3600),
                           (economy_handlers._cool, 86400), (rp_handlers._last, 3600),
                           (fun_handlers._last, 3600), (captcha._passed, 3600)):
                prune_stale(d, age, time.time())
        except Exception:
            logging.exception("rollup failed")
        await asyncio.sleep(86400)


async def flush_loop(db: Database, guard=None, every: float = 5.0) -> None:
    """Раз в несколько секунд пишет накопленный счётчик сообщений одной транзакцией; раз в час чистит кэши защиты."""
    ticks = 0
    while True:
        await asyncio.sleep(every)
        await db.flush_messages()                    # заодно пишет очередь пользователей и участников
        ticks += 1
        if guard is not None and ticks % int(3600 / every) == 0:
            guard.prune()


async def main() -> bool:
    """Работает до остановки. Возвращает True, если владелец попросил перезагрузку."""
    logging.basicConfig(level=logging.INFO)
    cfg = load_config()
    db = await Database.connect(cfg.database_url or cfg.db_path)  # DATABASE_URL=postgresql://… или файл SQLite
    bot = Bot(cfg.bot_token, session=EmojiSession(), default=DefaultBotProperties(parse_mode=ParseMode.HTML,
                                                                                  link_preview_is_disabled=True))   # ссылки-имена (t.me/ник) не должны разворачиваться в превью
    bot.session.middleware(i18n.TranslateMiddleware(db))           # английский интерфейс для чатов с языком en
    migrated = await PairService(db).migrate_legacy()                # старые браки и отношения → пары (одноразово)
    if migrated["marriage"] or migrated["relation"]:
        logging.info("пары: перенесено браков %s, отношений %s", migrated["marriage"], migrated["relation"])
    db.bot = bot                                                  # запасной поиск @ника через Telegram (db.find_user)

    http = aiohttp.ClientSession()
    ai = AiClient(http, river_key=cfg.river_api_key, river_base=cfg.river_base_url, river_model=cfg.river_model,
                  mistral_key=cfg.mistral_api_key, mistral_base=cfg.mistral_base_url,
                  stt_model=cfg.mistral_stt_model, vision_model=cfg.river_vision_model)
    if not ai.has_river:
        logging.info("RIVER_API_KEY не задан: команда «ии» и ИИ-проверка спама выключены")
    if not ai.has_stt:
        logging.info("GIGAAM_URL не задан: расшифровка выключена")

    dp = Dispatcher()
    data_dir = os.path.dirname(cfg.db_path) or "."
    marker = os.path.join(data_dir, "running.marker")
    alerter = Alerter(bot, cfg.owner_ids)
    auditor = Auditor(bot, db)
    db.auditor = auditor
    auditor.start()
    dp.errors.register(make_error_handler(alerter))
    if set_marker_and_check_crash(marker):
        await alerter.alert("⚠️ Бот запущен после сбоя: прошлый запуск завершился не штатно. Проверьте логи.")
    dp["db"] = db
    dp["ai"] = ai
    dp["http"] = http
    dp["owner_ids"] = cfg.owner_ids
    rt = Runtime()
    await rt.load(db)
    dp["rt"] = rt
    if not cfg.owner_ids:
        logging.warning("OWNER_ID не задан: панель владельца недоступна")
    dp["webapp_url"] = cfg.webapp_url
    dp["premium_price"] = cfg.premium_price
    dp["ytdlp_cookies"] = os.environ.get("YTDLP_COOKIES") or None   # cookies.txt для Instagram/YouTube (по желанию)
    dp["imagegen"] = ImageGen(http, cfg.cf_account_id, cfg.cf_api_token, cfg.cf_image_model)
    if not dp["imagegen"].configured:
        logging.info("CF_ACCOUNT_ID/CF_API_TOKEN не заданы: «нарисуй» выключено")
    detector = NsfwDetector()
    dp["detector"] = detector
    guard = GuardMiddleware(db, detector=detector, ai=ai if ai.has_river else None, rt=rt)
    metrics = Metrics()
    dp["metrics"] = metrics
    dp["db_path"] = cfg.db_path
    dp.update.outer_middleware(MetricsMiddleware(metrics))   # самый внешний: видит полное время, включая блок-лист
    dp.update.outer_middleware(BlockMiddleware(rt, cfg.owner_ids, guard))  # блок-лист и обслуживание — первыми
    dp.update.outer_middleware(UserTrackerMiddleware(db))
    dp.message.outer_middleware(CounterMiddleware(db))
    dp.message.outer_middleware(guard)
    dp.message.outer_middleware(QuietTopicMiddleware(db))
    dp.message.outer_middleware(ChatMemoryMiddleware(db))    # после защиты: удалённый спам в память не попадает
    dp.message.outer_middleware(NoriPrefixMiddleware())
    dp.message.outer_middleware(i18n.CommandAliasMiddleware(db))   # после префикса: «nori, ban @x» тоже понятно  # последним: счётчик и защита видят исходный текст
    dp.edited_message.outer_middleware(guard)  # правкой нельзя обойти проверку
    # captcha первым: «/start cap_…» не должен попасть в общее меню
    for r in (owner_handlers.router, captcha.router, webpanel_handlers.router, giveaway_handlers.router, suggest_handlers.router, premium_handlers.router, images_handlers.router, download_handlers.router, menu.router, inline_handlers.router, memory_handlers.router, polls_handlers.router, topics_handlers.router, dupes_module.router, guestbots_module.router, cas_module.router, pair_handlers.router, settings.router, setup_handlers.router, rank_handlers.router, cleanup_handlers.router, purge_handlers.router, chatinfo_handlers.router, scan_handlers.router,
              social_handlers.router, moderation.router, history_handlers.router, logchat_handlers.router, reports_handlers.router, chatfilters_handlers.router, aimod_handlers.router,
              stats.router, quotes_handlers.router, mog_handlers.router, games.router, duels.router, economy_handlers.router, vote_handlers.router, rp_handlers.router, family_handlers.router, garden_handlers.router, fun_handlers.router, fun.router, ai_handlers.router):
        dp.include_router(r)

    app = build_app(db, cfg.bot_token, captcha.make_on_pass(bot, db, cfg.webapp_url))
    add_giveaway_routes(app, db, bot, cfg.bot_token)
    add_panel_routes(app, PanelContext(bot=bot, db=db, bot_token=cfg.bot_token, owner_ids=cfg.owner_ids, rt=rt, ai=ai,
                                       webapp_url=cfg.webapp_url))
    # my_chat_member (бота убрали из чата) и edited_message (защита от правок) нужны middleware, а не хендлерам
    allowed = sorted(set(dp.resolve_used_update_types()) | {"my_chat_member", "edited_message", "chat_member", "chat_join_request"})
    await bot.set_my_commands([BotCommand(command="menu", description="Меню бота"),
                               BotCommand(command="help", description="Список команд")])

    backup_dir = os.environ.get("BACKUP_DIR") or os.path.join(data_dir, "backups")
    backup_keep = int(os.environ.get("BACKUP_KEEP", "14") or 14)
    jobs = {"капча": lambda: captcha.captcha_watchdog(bot, db),
            "дуэли": lambda: duels.duel_watchdog(bot, db),
            "семья": lambda: family_handlers.family_watchdog(bot, db),
            "пары": lambda: pair_handlers.pair_watchdog(bot, db),
            "таймеры": lambda: social_handlers.timer_watchdog(bot, db),
            "статистика": lambda: rollup_loop(db),
            "сброс счётчиков": lambda: flush_loop(db, guard),
            "участники": lambda: members.sweep_loop(bot, db),
            "конкурсы": lambda: giveaway_handlers.giveaway_watchdog(bot, db),
            "бэкап": lambda: backup_loop(db, backup_dir, backup_keep, alerter.alert)}
    tasks = [asyncio.create_task(supervise(name, f, alerter)) for name, f in jobs.items()]

    if cfg.mode == "webhook":
        if len(cfg.webhook_secret) < 16 or cfg.webhook_secret == "change-me-long-random":
            raise SystemExit("В режиме webhook задайте WEBHOOK_SECRET (случайная строка от 16 символов)")
        target = webhook_target(cfg.webhook_url, cfg.webapp_url)
        if not target.startswith("https://"):
            raise SystemExit("В режиме webhook задайте WEBHOOK_URL=https://домен:88 (Telegram принимает порты 443, 80, 88, 8443)")
        uq = UpdateQueue(db, dp, bot, workers=cfg.update_workers)
        dp["uq"] = uq
        await uq.start()                                  # сначала довыполняем то, что не успели до сбоя
        register_webhook(app, dp, bot, cfg.webhook_secret, queue=uq)
        runner = web.AppRunner(app)
        await runner.setup()
        await web.TCPSite(runner, "0.0.0.0", cfg.port).start()    # сначала слушаем, потом сообщаем Telegram адрес
        await bot.set_webhook(target, secret_token=cfg.webhook_secret, allowed_updates=allowed)
        tasks.append(asyncio.create_task(webhook_watch(bot, alerter, target)))
        logging.info("webhook mode on :%s -> %s", cfg.port, target.split("/webhook")[0])
        try:
            await rt.wait_stop()
        finally:
            await runner.cleanup()          # новых обновлений больше не принимаем
            await uq.stop()                 # и дорабатываем принятые
    else:
        await bot.delete_webhook()
        runner = web.AppRunner(app)
        await runner.setup()
        await web.TCPSite(runner, "0.0.0.0", cfg.port).start()
        logging.info("polling mode, captcha web on :%s", cfg.port)
        stop_task = asyncio.create_task(rt.wait_stop())
        poll_task = asyncio.create_task(dp.start_polling(bot, allowed_updates=allowed))
        try:
            done, _ = await asyncio.wait({stop_task, poll_task}, return_when=asyncio.FIRST_COMPLETED)
            if stop_task in done:
                await dp.stop_polling()
            await asyncio.gather(poll_task, return_exceptions=True)
        finally:
            stop_task.cancel()
            await runner.cleanup()
    auditor.stop()
    for t in tasks:
        t.cancel()
    await db.close()
    await http.close()
    await bot.session.close()
    clear_marker(marker)  # штатная остановка
    return rt.restart


def _run(coro):
    """uvloop — быстрый цикл событий (сеть, aiohttp, aiosqlite); нет uvloop (Windows, локальная разработка) — обычный."""
    try:
        import uvloop
    except ImportError:
        return asyncio.run(coro)
    return uvloop.run(coro)


if __name__ == "__main__":
    if _run(main()):
        os.execv(sys.executable, [sys.executable, "-m", "bot.main"])  # перезагрузка по команде владельца

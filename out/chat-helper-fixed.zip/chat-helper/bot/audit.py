"""Журнал действий в отдельный чат/канал: очередь с ограничением скорости, повтор при flood control.
Сбой журнала никогда не ломает модерацию: ошибки только пишутся в лог."""
from __future__ import annotations

import asyncio
import html
import logging
import time
from collections import deque
from typing import Awaitable, Callable

from aiogram.exceptions import TelegramRetryAfter

ICONS = {"бан": "🔨", "разбан": "✅", "мут": "🔇", "размут": "🔊", "кик": "👢", "варн": "⚠️",
         "снять варн": "↩️", "удаление": "🗑", "ранг": "🎖", "массовый кик": "🧹", "жалоба": "📣",
         "настройка": "⚙️", "антирейд": "🚨"}
MAX_TEXT = 3500


def _dur(sec: int | None) -> str:
    if not sec:
        return ""
    if sec % 86400 == 0:
        return f" на {sec // 86400} дн."
    if sec % 3600 == 0:
        return f" на {sec // 3600} ч."
    return f" на {max(sec // 60, 1)} мин."


def format_event(chat_title: str, actor: str, target: str | None, action: str, duration: int | None,
                 reason: str, ts: int) -> str:
    e = html.escape
    lines = [f"{ICONS.get(action, '📝')} <b>{e(action)}</b>{_dur(duration)}", f"Чат: {e(chat_title)}", f"Кто: {e(actor)}"]
    if target:
        lines.append(f"Кого: {e(target)}")
    if reason:
        lines.append(f"Причина: {e(reason)}")
    lines.append("🕒 " + time.strftime("%d.%m.%Y %H:%M:%S", time.gmtime(ts)) + " UTC")
    return "\n".join(lines)[:MAX_TEXT]


class Auditor:
    def __init__(self, bot, db, interval: float = 1.1, max_queue: int = 500,
                 sleep: Callable[[float], Awaitable[None]] = asyncio.sleep):
        self.bot, self.db, self.interval, self.max_queue, self._sleep = bot, db, interval, max_queue, sleep
        self._q: deque[tuple[int, str]] = deque()
        self._wake = asyncio.Event()
        self._task: asyncio.Task | None = None
        self._pending: set[asyncio.Task] = set()

    # ---- приём событий ----
    def action_fire_and_forget(self, *args) -> None:
        """Вызывается из Database.log_action: ничего не ждём и ничего не бросаем."""
        try:
            t = asyncio.get_running_loop().create_task(self.record_action(*args))
        except RuntimeError:
            return
        self._pending.add(t)
        t.add_done_callback(self._pending.discard)

    async def _name(self, uid: int | None) -> str:
        if not uid:
            return "—"
        name = await self.db.user_name(uid)
        return f"{name} ({uid})" if name else f"id{uid}"

    async def record_action(self, chat_id: int, actor_id: int, target_id: int | None, action: str,
                            reason: str, ts: int, duration: int | None) -> None:
        try:
            dest = (await self.db.get_settings(chat_id)).get("log_chat_id", 0)
            if not dest:
                return
            chat = await self.db.get_chat(chat_id)
            text = format_event((chat or {}).get("title") or str(chat_id), await self._name(actor_id),
                                await self._name(target_id) if target_id else None, action, duration, reason or "", ts)
            await self.push(dest, text)
        except Exception:
            logging.exception("audit: не смог подготовить запись")

    async def push(self, dest: int, text: str) -> None:
        if len(self._q) >= self.max_queue:
            self._q.popleft()   # переполнение: теряем самое старое
        self._q.append((dest, text))
        self._wake.set()

    # ---- отправка ----
    async def _send_one(self, dest: int, text: str) -> None:
        for _ in range(3):
            try:
                await self.bot.send_message(dest, text, disable_web_page_preview=True)
                return
            except TelegramRetryAfter as e:
                await self._sleep(min(e.retry_after, 60))
            except Exception as e:
                logging.warning("audit: отправка в %s не удалась: %s", dest, type(e).__name__)
                return

    async def drain(self) -> None:
        """Отправить всё из очереди (используется воркером и тестами)."""
        if self._pending:
            await asyncio.gather(*list(self._pending), return_exceptions=True)
        first = True
        while self._q:
            dest, text = self._q.popleft()
            if not first:
                await self._sleep(self.interval)
            first = False
            await self._send_one(dest, text)

    async def _worker(self) -> None:
        while True:
            await self._wake.wait()
            self._wake.clear()
            try:
                await self.drain()
            except Exception:
                logging.exception("audit worker")
            await self._sleep(self.interval)

    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._worker())

    def stop(self) -> None:
        if self._task:
            self._task.cancel()
            self._task = None

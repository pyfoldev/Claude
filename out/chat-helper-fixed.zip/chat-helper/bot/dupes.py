"""Двойники забаненных: при входе сравниваем имя и @ник новичка с теми, кого в этом чате уже банили (последние 180 дней).
Совпадение — не приговор, а повод для модератора: бот пишет уведомление с кнопками «Забанить» и «Это не он»."""
from __future__ import annotations

import difflib
import logging
import re
import time

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton as B, InlineKeyboardMarkup

from bot import mod_service as ms
from bot import style
from bot.db import Database
from bot.ranks import need_rank
from bot.targets import mention

router = Router(name="dupes")
THRESHOLD = 0.85
MIN_LEN = 4
WINDOW = 180 * 86400
_LOOK = str.maketrans({"а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "х": "x", "у": "y", "і": "i", "ё": "e",
                       "0": "o", "1": "l", "3": "e", "5": "s", "@": "a", "$": "s"})


def norm(s: str | None) -> str:
    """Имя без регистра, пробелов, знаков и с заменой букв-двойников: «Аdmin_01» и «admin01» совпадут."""
    s = (s or "").casefold().translate(_LOOK)
    return re.sub(r"[\W_]+", "", s)


def similarity(a: str | None, b: str | None) -> float:
    x, y = norm(a), norm(b)
    if len(x) < MIN_LEN or len(y) < MIN_LEN:
        return 0.0
    return difflib.SequenceMatcher(None, x, y).ratio()


async def find_match(db: Database, chat_id: int, user, now: int | None = None):
    """(id, имя, сходство) самого похожего из забаненных в чате или None."""
    now = int(time.time()) if now is None else now
    best = None
    for uid in await db.banned_ids(chat_id, now - WINDOW):
        if uid == user.id:
            continue
        old_name = await db.user_name(uid)
        old_nick = await db.get_username(uid)
        score = max(similarity(user.full_name, old_name),
                    similarity(user.username, old_nick),
                    similarity(user.full_name, old_nick), similarity(user.username, old_name))
        if score >= THRESHOLD and (best is None or score > best[2]):
            best = (uid, old_name or f"id{uid}", score)
    return best


async def check_join(bot, db: Database, chat_id: int, user) -> None:
    """Вызывается при входе. Ошибки не должны ломать капчу."""
    try:
        m = await find_match(db, chat_id, user)
        if m is None:
            return
        uid, old_name, score = m
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            B(text="🔨 Забанить", callback_data=f"dup:ban:{user.id}", style="danger"),
            B(text="✅ Это не он", callback_data=f"dup:ok:{user.id}")]])
        await bot.send_message(
            chat_id, style.warn(f"{mention(user.id, user.full_name)} похож на забаненного "
                                f"<b>{old_name}</b> (сходство {int(score * 100)}%).") + "\n<i>Решает модератор.</i>",
            reply_markup=kb)
    except Exception:
        logging.exception("dupes: проверка входа не удалась")


@router.callback_query(F.data.startswith("dup:"))
async def on_button(cb: CallbackQuery, bot, db: Database) -> None:
    parts = cb.data.split(":")
    if len(parts) != 3 or not parts[2].isdigit() or cb.message is None:
        await cb.answer()
        return
    chat, uid = cb.message.chat.id, int(parts[2])
    rank = await ms.effective_rank(bot, db, chat, cb.from_user.id)
    if rank < need_rank(await db.get_access(chat), "бан"):
        await cb.answer("Нужен ранг модератора", show_alert=True)
        return
    if parts[1] == "ban":
        try:
            await bot.ban_chat_member(chat, uid)
            await db.log_action(chat, cb.from_user.id, uid, "бан", "двойник забаненного", int(time.time()))
            text = style.ok("Забанен.")
        except Exception as e:
            text = style.fail(f"Не получилось: {e}")
    else:
        text = style.ok("Оставлен: модератор решил, что это не двойник.")
    try:
        await cb.message.edit_text(text, reply_markup=None)
    except Exception:
        pass
    await cb.answer()

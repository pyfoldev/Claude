"""Проверка новичков по внешней базе спамеров CAS (Combot Anti-Spam, https://cas.chat).

Включается в настройках («База спамеров»): off — выключено; warn — уведомить модераторов; ban — сразу забанить.
Наружу уходит только числовой id входящего пользователя (адрес api.cas.chat), текст и имя не передаются. Ошибки и таймауты
сети НЕ блокируют вход: нет ответа — считаем, что в базе его нет. Результаты кэшируются (6 часов — найден, 1 час — нет)."""
from __future__ import annotations

import logging
import time

import aiohttp
from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton as B, InlineKeyboardMarkup

from bot import mod_service as ms
from bot import style
from bot.db import Database
from bot.ranks import need_rank
from bot.targets import mention

router = Router(name="cas")
URL = "https://api.cas.chat/check"
TIMEOUT = aiohttp.ClientTimeout(total=3)
TTL_FOUND, TTL_CLEAN = 6 * 3600, 3600
_cache: dict[int, tuple[float, bool]] = {}


async def _fetch(user_id: int) -> bool | None:
    """True — в базе, False — нет, None — не удалось узнать."""
    try:
        async with aiohttp.ClientSession(timeout=TIMEOUT) as s, s.get(URL, params={"user_id": user_id}) as r:
            if r.status != 200:
                return None
            data = await r.json(content_type=None)
    except Exception as e:
        logging.info("cas: %s", e)
        return None
    if data.get("ok") is True:
        return True
    return False if "not found" in str(data.get("description", "")).lower() else None


async def is_spammer(user_id: int, now: float | None = None) -> bool:
    now = time.time() if now is None else now
    hit = _cache.get(user_id)
    if hit is not None and now < hit[0]:
        return hit[1]
    res = await _fetch(user_id)
    if res is None:
        return False                                            # не знаем — не мешаем входу
    if len(_cache) > 20000:
        _cache.clear()
    _cache[user_id] = (now + (TTL_FOUND if res else TTL_CLEAN), res)
    return res


async def handle(bot, db: Database, chat_id: int, user, mode: str | None = None) -> str | None:
    """Проверка при входе (в заявке или после вступления). Возвращает сработавший режим ('warn' | 'ban') или None.
    Бан/уведомление выполняется здесь; вызывающий код при 'ban' дальше капчу не выдаёт."""
    mode = mode or (await db.get_settings(chat_id)).get("cas_mode", "off")
    if mode == "off" or user.is_bot:
        return None
    if await db.cas_allowed(chat_id, user.id) or not await is_spammer(user.id):
        return None
    try:
        if mode == "ban":
            await bot.ban_chat_member(chat_id, user.id)
            await db.log_action(chat_id, (await bot.me()).id, user.id, "бан", "в базе спамеров CAS", int(time.time()))
            kb = InlineKeyboardMarkup(inline_keyboard=[[B(text="↩️ Это ошибка", callback_data=f"cas:ok:{user.id}")]])
            await bot.send_message(chat_id, style.warn(f"{mention(user.id, user.full_name)} в базе спамеров CAS — забанен."),
                                   reply_markup=kb)
        else:
            kb = InlineKeyboardMarkup(inline_keyboard=[[
                B(text="🔨 Забанить", callback_data=f"cas:ban:{user.id}", style="danger"),
                B(text="✅ Это не спамер", callback_data=f"cas:ok:{user.id}")]])
            await bot.send_message(chat_id, style.warn(f"{mention(user.id, user.full_name)} есть в базе спамеров CAS.")
                                   + "\n<i>Решает модератор.</i>", reply_markup=kb)
    except Exception:
        logging.exception("cas: действие не выполнилось")
    return mode


@router.callback_query(F.data.startswith("cas:"))
async def on_button(cb: CallbackQuery, bot, db: Database) -> None:
    parts = cb.data.split(":")
    if len(parts) != 3 or not parts[2].isdigit() or cb.message is None:
        await cb.answer()
        return
    chat, uid = cb.message.chat.id, int(parts[2])
    if await ms.effective_rank(bot, db, chat, cb.from_user.id) < need_rank(await db.get_access(chat), "бан"):
        await cb.answer("Нужен ранг модератора", show_alert=True)
        return
    if parts[1] == "ban":
        try:
            await bot.ban_chat_member(chat, uid)
            await db.log_action(chat, cb.from_user.id, uid, "бан", "в базе спамеров CAS", int(time.time()))
            text = style.ok("Забанен.")
        except Exception as e:
            text = style.fail(f"Не получилось: {e}")
    else:                                                       # «это не спамер»: исключение для этого чата, бан снимается
        await db.cas_allow(chat, uid)
        try:
            await bot.unban_chat_member(chat, uid, only_if_banned=True)
        except Exception:
            pass
        text = style.ok("Оставлен: модератор решил, что это не спамер.")
    try:
        await cb.message.edit_text(text, reply_markup=None)
    except Exception:
        pass
    await cb.answer()

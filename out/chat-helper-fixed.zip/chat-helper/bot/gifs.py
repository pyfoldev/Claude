"""Гифки для РП, семьи и пары через Gifukai (https://api.gifukai.com/v1, бесплатно, без ключа). Пол актёра и цели учитывается:
параметр pairing = первая буква — кто делает, вторая — кому (f — девушка, m — парень). Любой сбой — просто текст без гифки."""
from __future__ import annotations

import asyncio
import logging
import os
import random
import time

import aiohttp

BASE = os.environ.get("GIFUKAI_URL", "https://api.gifukai.com/v1").rstrip("/")
TIMEOUT = aiohttp.ClientTimeout(total=3.5)
_off_until = 0.0                  # сервис не отвечает — не мучаем запросами и не тормозим РП
OFF_FOR = 120

# фраза РП → (действие Gifukai, тип | None)
RP_MAP: dict[str, tuple[str, str | None]] = {
    "обнять": ("hug", None), "обнять крепко": ("hug", None), "прижать к себе": ("cuddle", None), "укрыть пледом": ("cuddle", None),
    "погладить": ("pat", None), "погладить по голове": ("pat", None), "пожалеть": ("pat", None),
    "поцеловать в щёку": ("kiss", "cheek"), "поцеловать в лоб": ("kiss", "forehead"),
    "взять за руку": ("handhold", None), "накормить": ("feed", None), "подарить цветы": ("blush", None),
    "подарить сердечко": ("blowkiss", None), "пожать руку": ("handshake", None), "дать пять": ("highfive", None),
    "поприветствовать": ("hi", None), "поблагодарить": ("happy", None), "похвалить": ("clap", None), "поздравить": ("yay", None),
    "поддержать": ("thumbsup", None), "подбодрить": ("thumbsup", None), "угостить чаем": ("sip", None),
    "угостить кофе": ("sip", None), "подмигнуть": ("wink", None), "помахать": ("wave", None), "поклониться": ("salute", None),
    "пощекотать": ("tickle", None), "ущипнуть": ("poke", None), "подразнить": ("taunt", None), "толкнуть": ("poke", None),
    "показать язык": ("bleh", None), "дать щелбан": ("poke", None), "кинуть подушкой": ("bonk", None),
    "осыпать конфетти": ("yay", None), "догнать": ("run", None), "ударить": ("punch", None), "пнуть": ("kick", None),
    "дать подзатыльник": ("bonk", None), "кинуть тапком": ("yeet", None), "укусить": ("bite", None), "выгнать": ("yeet", None),
}
# РП пары (handlers/pair.py → data.PairRp.key)
PAIR_MAP: dict[str, tuple[str, str | None]] = {
    "обнять": ("hug", None), "поцеловать": ("kiss", None), "кусь": ("bite", None), "шлёп": ("slap", None),
    "погладить": ("pat", None), "щелбан": ("poke", None), "потанцевать": ("dance", None), "укрыть": ("cuddle", None),
    "накормить": ("feed", None), "комплимент": ("blush", None), "массаж": ("pat", None), "щекотать": ("tickle", None),
    "подмигнуть": ("wink", None), "серенада": ("sing", None), "за руку": ("handhold", None), "носить на руках": ("carry", None),
}
# семейные события
FAMILY_MAP: dict[str, tuple[str, str | None]] = {
    "marry": ("kiss", None), "relation": ("handhold", None), "adopt": ("pat", None), "breakup": ("cry", None),
    "divorce": ("cry", None), "disown": ("bye", None),
}


def pairing(actor: str | None, target: str | None, rnd: random.Random | None = None) -> str | None:
    """Параметр pairing по полам. Неизвестна цель — подбираем случайно; неизвестен актёр — не указываем (любая гифка)."""
    if actor not in ("m", "f"):
        return None
    t = target if target in ("m", "f") else (rnd or random).choice("mf")
    return actor + t


async def fetch(http, action: str, typ: str | None = None, pair: str | None = None) -> str | None:
    """Ссылка на случайную гифку или None. Нет гифки для пары полов — пробуем без пары."""
    global _off_until
    if time.time() < _off_until or http is None:
        return None
    for pr in ((pair, None) if pair else (None,)):
        params = {k: v for k, v in (("pairing", pr), ("type", typ)) if v}
        try:
            async with http.get(f"{BASE}/{action}", params=params, timeout=TIMEOUT, headers={"User-Agent": "ChatHelperBot/1.0"}) as r:
                if r.status == 200:
                    url = (await r.json()).get("url")
                    if url and url.startswith("https://"):
                        return url
                elif r.status >= 500:
                    _off_until = time.time() + OFF_FOR
                    return None
        except (aiohttp.ClientError, asyncio.TimeoutError, ValueError):
            _off_until = time.time() + OFF_FOR
            return None
    return None


async def reply_gif(bot, http, message, text: str, mapped: tuple[str, str | None] | None, actor_g: str | None,
                    target_g: str | None, *, reply_to: int | None = None, enabled: bool = True) -> bool:
    """РП-ответ гифкой с текстом в подписи. False — гифки нет (отключено, сбой): тогда вызывающий шлёт обычный текст."""
    if not enabled or mapped is None:
        return False
    url = await fetch(http, mapped[0], mapped[1], pairing(actor_g, target_g))
    if url is None:
        return False
    try:
        await bot.send_animation(message.chat.id, url, caption=text, reply_to_message_id=reply_to,
                                 message_thread_id=message.message_thread_id if getattr(message, "is_topic_message", False) else None)
        return True
    except Exception as e:
        logging.info("gifukai: гифка не отправилась (%s)", e)
        return False


async def extra_gif(bot, http, chat_id: int, mapped: tuple[str, str | None] | None, actor_g: str | None, target_g: str | None) -> None:
    """Гифка отдельным сообщением после текста (семейные события)."""
    if mapped is None:
        return
    url = await fetch(http, mapped[0], mapped[1], pairing(actor_g, target_g))
    if url:
        try:
            await bot.send_animation(chat_id, url)
        except Exception as e:
            logging.info("gifukai: гифка не отправилась (%s)", e)

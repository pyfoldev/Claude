"""Капча для новичков.

Telegram не разрешает web_app-кнопки в группах, поэтому в группе показывается URL-кнопка
на личный чат с ботом (/start cap_<token>), а там уже кнопка Mini App.
"""
import asyncio
import html
import logging
import secrets
import time
from collections import defaultdict, deque

from aiogram import F, Router
from aiogram.filters import JOIN_TRANSITION, ChatMemberUpdatedFilter
from aiogram.types import (CallbackQuery, ChatJoinRequest, ChatMemberUpdated, ChatPermissions, InlineKeyboardButton as B,
                           InlineKeyboardMarkup, Message, WebAppInfo)

from bot import ux
from bot.captcha_server import level_params, new_code
from bot.db import Database
from bot.emoji import emoji
from bot.mod_service import _FULL
from bot.handlers.chatinfo import send_welcome
from bot.raid import raid_guard
from bot.targets import ping

router = Router(name="captcha")
_passed: dict[tuple[int, int], float] = {}   # кто только что прошёл капчу по заявке: повторной капчи после одобрения не нужно
PASSED_TTL = 600
FAIL_WINDOW = 900                       # окно, в котором считаем «непрошедших» в чате
WAVE_FAILS, HEAVY_FAILS = 3, 6          # столько провалов за окно — повышенная / усиленная капча
_fails: dict[int, deque] = defaultdict(deque)   # чат -> когда участники не прошли капчу вовремя


def record_failure(chat_id: int, now: float | None = None) -> None:
    now = time.time() if now is None else now
    q = _fails[chat_id]
    q.append(now)
    while q and now - q[0] > FAIL_WINDOW:
        q.popleft()


def recent_failures(chat_id: int, now: float | None = None) -> int:
    now = time.time() if now is None else now
    q = _fails.get(chat_id)
    if not q:
        return 0
    while q and now - q[0] > FAIL_WINDOW:
        q.popleft()
    return len(q)


def pick_level(chat_id: int, raid_active: bool, user, now: float | None = None) -> int:
    """Сложность капчи по обстановке. Рейд — максимум; волна непрошедших в чате — выше; без ника — на ступень выше, если в чате уже были непрошедшие;
    Premium-аккаунт (платный, боты-спамеры почти не бывают Premium) — обычная, если нет рейда."""
    if raid_active:
        return 2
    fails = recent_failures(chat_id, now)
    score = (2 if fails >= HEAVY_FAILS else 1 if fails >= WAVE_FAILS else 0)
    if fails and not getattr(user, "username", None):
        score += 1          # без ника — подозрительнее, но только когда в чате уже были непрошедшие (многие живые люди без ника)
    if getattr(user, "is_premium", False):
        score = min(score, 1) if fails >= HEAVY_FAILS else 0
    return min(score, 2)
_no_rights_warned: dict[int, float] = {}   # чат -> когда последний раз предупреждали, что у бота нет права ограничивать


_GROUPS = {"group", "supergroup"}   # капча, антирейд и приветствие — только для групп. В каналах (например, канал
                                    # обязательной подписки, где бот — админ) Telegram тоже присылает «вступил», но там
                                    # ограничивать некого и писать в канал нельзя.


_handled: dict[tuple[int, int], tuple[float, str]] = {}   # (чат, человек) -> (когда, каким путём) обработали вход
HANDLED_TTL = 20
BTN_EMOJI = ["🐱", "🐶", "🦊", "🐼", "🐸", "🐵", "🦁", "🐯", "🐰", "🐻"]
BTN_TRIES = 3


def _recent(chat_id: int, user_id: int, source: str) -> bool:
    """True, если этот же вход уже обработал ДРУГОЙ путь (chat_member и служебное сообщение приходят оба).
    Повторный вход тем же путём — это новый вход, его обрабатываем."""
    now = time.time()
    for k in [k for k, (t, _s) in _handled.items() if now - t > HANDLED_TTL]:
        _handled.pop(k, None)
    prev = _handled.get((chat_id, user_id))
    if prev and prev[1] != source:
        _handled.pop((chat_id, user_id), None)
        return True
    _handled[(chat_id, user_id)] = (now, source)
    return False


@router.chat_member(F.chat.type.in_(_GROUPS), ChatMemberUpdatedFilter(JOIN_TRANSITION))
async def on_join(event: ChatMemberUpdated, bot, db: Database, webapp_url: str = "") -> None:
    user = event.new_chat_member.user
    old = event.old_chat_member
    await handle_join(bot, db, event.chat.id, user, webapp_url,
                      old_muted=old.status == "restricted" and not getattr(old, "can_send_messages", False), source="member")


@router.message(F.chat.type.in_(_GROUPS), F.new_chat_members)
async def on_join_service(message: Message, bot, db: Database, webapp_url: str = "") -> None:
    """Запасной путь: если Telegram не прислал chat_member (бот не админ или нет права), вход виден по служебному сообщению."""
    for user in message.new_chat_members or []:
        await handle_join(bot, db, message.chat.id, user, webapp_url, old_muted=False, source="service")


_rechecked: dict[tuple[int, int], float] = {}   # (чат, человек) -> когда выдали повторную капчу
RECHECK_TTL = 900


async def handle_join(bot, db: Database, chat_id: int, user, webapp_url: str = "", old_muted: bool = False,
                      source: str = "member", min_level: int = 0) -> None:
    if user.is_bot or _recent(chat_id, user.id, source):
        return
    old_cap = await db.get_captcha_for_user(chat_id, user.id)
    if old_muted and not old_cap:
        return  # человек в муте у модератора: капча не должна его снять.
        # (restricted с правом писать — просто остаток после «размут»: такому капча нужна, как и всем)
    if old_muted and await db.get_state(chat_id, user.id, "mute", int(time.time())):
        return
    settings = await db.get_settings(chat_id)
    if settings.get("dupe_on") and source != "recheck":
        from bot import dupes
        await dupes.check_join(bot, db, chat_id, user)       # «похож на забаненного» — уведомление модераторам
    raid_active = False
    if time.time() - _passed.get((chat_id, user.id), 0) < PASSED_TTL:
        await send_welcome(bot, db, chat_id, user.id, user.full_name)  # заявка одобрена после капчи в личке
        return
    if settings["raid_on"]:
        raid_active, fresh = raid_guard.register(chat_id, time.time(), settings)
        if fresh:
            await _raid_announce(bot, chat_id, settings)
            await db.log_action(chat_id, 0, None, "антирейд", f"{settings['raid_n']} входов за {settings['raid_sec']} с", int(time.time()))
        if raid_active and settings["raid_action"] == "kick":
            try:
                await bot.ban_chat_member(chat_id, user.id)
                await bot.unban_chat_member(chat_id, user.id)
            except Exception:
                pass
            return
    # во время рейда капча обязательна, даже если в чате она выключена
    if not (settings["captcha_on"] or raid_active):
        if not old_cap:
            await send_welcome(bot, db, chat_id, user.id, user.full_name)
        return
    if old_cap:
        # человек вышел и вернулся, пока капча ещё висела: старое сообщение/код больше не нужны — выдаём новую капчу,
        # а не оставляем его молча в муте
        if await db.consume_captcha(old_cap["token"]) and old_cap.get("kind") != "join_request":
            try:
                await bot.delete_message(chat_id, old_cap["message_id"])
            except Exception:
                pass
    try:
        await bot.restrict_chat_member(chat_id, user.id, permissions=ChatPermissions(can_send_messages=False))
    except Exception:
        # нет прав — защитить не можем; раз в час говорим об этом чату, а не молчим
        if time.time() - _no_rights_warned.get(chat_id, 0) > 3600:
            _no_rights_warned[chat_id] = time.time()
            try:
                await bot.send_message(chat_id, "⚠️ Капча не работает: у бота нет права «ограничивать участников». "
                                                "Сделайте его админом с этим правом (проверка — <code>диагностика</code>).")
            except Exception:
                pass
        return
    token = secrets.token_urlsafe(12)
    level = max(pick_level(chat_id, raid_active, user), min_level)
    minutes = max(settings["captcha_timeout"] // 60, 1)
    expires = int(time.time()) + settings["captcha_timeout"]
    if not webapp_url:
        # без домена Mini App не открыть (нужен https) — вместо «капчи нет» даём простую проверку кнопкой прямо в чате
        right = secrets.randbelow(len(BTN_EMOJI))
        pool = [i for i in range(len(BTN_EMOJI)) if i != right]
        secrets.SystemRandom().shuffle(pool)
        opts = pool[:5] + [right]
        secrets.SystemRandom().shuffle(opts)
        kb = InlineKeyboardMarkup(inline_keyboard=[[B(text=BTN_EMOJI[i], callback_data=f"capb:{token}:{i}") for i in opts[:3]],
                                                   [B(text=BTN_EMOJI[i], callback_data=f"capb:{token}:{i}") for i in opts[3:]]])
        text = (f'{emoji("shield")} {ping(user.id, user.full_name)}, это проверка на человека: нажмите {BTN_EMOJI[right]}, '
                f"чтобы писать в чат. Время — {minutes} мин., иначе вас исключат.")
        answer = {"btn": right}
    else:
        username = (await bot.me()).username
        kb = InlineKeyboardMarkup(inline_keyboard=[[B(
            text="✅ Пройти проверку", url=f"https://t.me/{username}?start=cap_{token}")]])
        text = (f'{emoji("shield")} {ping(user.id, user.full_name)}, пройдите капчу, '
                f"чтобы писать в чат: нажмите кнопку ниже, в чате с ботом нажмите «Запустить» и введите код с картинки. "
                f"Время — {minutes} мин., иначе вас исключат.")
        answer = new_code(level_params(level)[0])
    try:
        m = await bot.send_message(chat_id, text, reply_markup=kb)
    except Exception:
        await make_on_pass(bot)(chat_id, user.id, 0)  # сообщение не ушло — не оставляем человека в муте
        return
    await db.create_captcha(token, chat_id, user.id, answer, expires, m.message_id, level=level)


@router.callback_query(F.data.startswith("capb:"))
async def button_captcha(cb: CallbackQuery, bot, db: Database) -> None:
    try:
        _, token, idx = cb.data.split(":")
        idx = int(idx)
    except ValueError:
        await cb.answer()
        return
    cap = await db.get_captcha(token)
    if not cap or cap["expires_at"] <= time.time():
        await cb.answer("Проверка уже закончилась.", show_alert=True)
        return
    if cap["user_id"] != cb.from_user.id:
        await cb.answer("Эта проверка не для вас.", show_alert=True)
        return
    if not isinstance(cap["answer"], dict) or idx != cap["answer"].get("btn"):
        if await db.take_captcha_attempt(token, BTN_TRIES - 1):
            await cb.answer("Не тот. Попробуйте ещё раз.", show_alert=True)
        else:
            if await db.consume_captcha(token):
                await cb.answer("Попытки закончились.", show_alert=True)
                await expire_captcha(bot, cap, db)
        return
    if await db.consume_captcha(token):
        await cb.answer("Готово, добро пожаловать!")
        await make_on_pass(bot, db)(cap["chat_id"], cap["user_id"], cap["message_id"])
    else:
        await cb.answer()


async def _raid_announce(bot, chat_id: int, settings: dict) -> None:
    what = "исключаются" if settings["raid_action"] == "kick" else "проходят усиленную капчу"
    try:
        await bot.send_message(
            chat_id, f"{emoji('shield')} <b>Антирейд!</b> Слишком много входов "
                     f"({settings['raid_n']} за {settings['raid_sec']} сек.). "
                     f"Новые участники {what} ещё {settings['raid_minutes']} мин.")
    except Exception:
        pass


async def _guard_request(event: ChatJoinRequest, bot, db: Database, webapp_url: str) -> None:
    """Бот назначен стражем заявок чата (Bot API 10.2): заявка приходит с query_id, и за 10 секунд нужно либо показать
    человеку Mini App (sendChatJoinRequestWebApp), либо решить сразу (answerChatJoinRequestQuery). Капча открывается
    прямо в заявке, без писем в личку и без сообщений-ловушек в чате; результат капчи решает судьбу заявки."""
    user, chat_id, qid = event.from_user, event.chat.id, event.query_id
    now = int(time.time())

    async def answer(result: str) -> None:
        try:
            await bot.answer_chat_join_request_query(qid, result)
        except Exception as e:
            logging.warning("answerChatJoinRequestQuery(%s) не удался: %s", result, e)

    settings = await db.get_settings(chat_id)
    if user.is_bot or await db.get_state(chat_id, user.id, "ban", now):
        await answer("decline")
        return
    if settings.get("dupe_on"):                                  # похож на забаненного — решают модераторы
        from bot import dupes
        if await dupes.find_match(db, chat_id, user, bot=bot) is not None:
            await dupes.check_join(bot, db, chat_id, user)
            await answer("queue")
            return
    if settings["captcha_on"] and webapp_url:
        token = secrets.token_urlsafe(12)
        level = pick_level(chat_id, False, user)
        expires = now + settings["captcha_timeout"]
        await db.create_captcha(token, chat_id, user.id, new_code(level_params(level)[0]), expires, 0,
                                kind="guard", level=level)
        await db.guard_query_set(chat_id, user.id, qid, now)
        try:
            await bot.send_chat_join_request_web_app(qid, f"{webapp_url}/captcha?token={token}")
            return
        except Exception as e:
            logging.warning("sendChatJoinRequestWebApp не удался: %s", e)
            await db.consume_captcha(token)
            await db.guard_query_pop(chat_id, user.id)
            await answer("queue")                                # не смогли показать капчу — решат админы
            return
    await answer("approve" if settings.get("guard_default") == "approve" else "queue")


@router.chat_join_request(F.chat.type.in_(_GROUPS))
async def on_join_request(event: ChatJoinRequest, bot, db: Database, webapp_url: str = "") -> None:
    """Заявка на вступление: бот пишет человеку в личку с кнопкой капчи и одобряет заявку, когда проверка пройдена.
    Если бот — страж заявок (в заявке есть query_id), капча открывается прямо в ней."""
    if event.query_id:
        await _guard_request(event, bot, db, webapp_url)
        return
    user, chat_id = event.from_user, event.chat.id
    settings = await db.get_settings(chat_id)
    if user.is_bot or not webapp_url or not settings["captcha_on"]:
        return  # капча выключена — заявку решают админы
    if await db.get_captcha_for_user(chat_id, user.id):
        return
    token = secrets.token_urlsafe(12)
    timeout = min(settings["captcha_timeout"], 280)  # Telegram разрешает писать по заявке только 5 минут
    kb = InlineKeyboardMarkup(inline_keyboard=[[B(
        text="✅ Открыть проверку", web_app=WebAppInfo(url=f"{webapp_url}/captcha?token={token}"))]])
    try:
        m = await bot.send_message(
            event.user_chat_id,
            f"{emoji('shield')} Вы подали заявку в «{html.escape(event.chat.title or 'чат')}».\n"
            f"Чтобы её одобрили, пройдите проверку: нажмите кнопку и введите код с картинки. "
            f"Время — {max(timeout // 60, 1)} мин.", reply_markup=kb)
    except Exception:
        return  # написать человеку нельзя — заявка остаётся на ручное решение админов
    level = pick_level(chat_id, False, user)
    await db.create_captcha(token, chat_id, user.id, new_code(level_params(level)[0]), int(time.time()) + timeout,
                            m.message_id, kind="join_request", level=level)


@router.message(F.chat.type == "private", F.text.startswith("/start cap_"))
async def start_captcha(message: Message, db: Database, webapp_url: str) -> None:
    token = message.text.split("cap_", 1)[1].strip()
    cap = await db.get_captcha(token)
    if not cap or cap["user_id"] != message.from_user.id or cap["expires_at"] <= time.time():
        await ux.tell(message, "⚠️ Проверка не найдена, уже пройдена или время вышло.")
        return
    if not webapp_url:
        await ux.tell(message, "⚠️ WEBAPP_URL не настроен — обратитесь к администратору бота.")
        return
    kb = InlineKeyboardMarkup(inline_keyboard=[[B(
        text="✅ Открыть проверку", web_app=WebAppInfo(url=f"{webapp_url}/captcha?token={token}"))]])
    await message.answer("Нажмите кнопку и введите код с картинки:", reply_markup=kb)


async def _recheck(bot, db: Database, chat_id: int, user_id: int, webapp_url: str) -> bool:
    """Повторная капча (настройка «Повторная проверка»): после первой — вторая, повышенной сложности, для подозрительных
    аккаунтов (без @ника) или для всех. Один раз за вход. True — повторная капча выдана."""
    mode = (await db.get_settings(chat_id)).get("captcha_recheck", "off")
    now = time.time()
    if mode == "off" or now - _rechecked.get((chat_id, user_id), 0) < RECHECK_TTL:
        return False
    try:
        user = (await bot.get_chat_member(chat_id, user_id)).user
    except Exception:
        return False
    if mode == "susp" and user.username:
        return False
    if len(_rechecked) > 5000:
        _rechecked.clear()
    _rechecked[(chat_id, user_id)] = now
    _handled.pop((chat_id, user_id), None)                # иначе защита от «двойной обработки входа» проглотит вызов
    await handle_join(bot, db, chat_id, user, webapp_url, source="recheck", min_level=1)
    return True


def make_on_pass(bot, db=None, webapp_url: str = ""):
    async def on_pass(chat_id: int, user_id: int, message_id: int, kind: str = "member") -> None:
        if kind == "guard":                              # капча пройдена в заявке, где бот — страж: одобряем запрос
            _passed[(chat_id, user_id)] = time.time()
            qid = await db.guard_query_pop(chat_id, user_id) if db is not None else None
            try:
                if qid:
                    await bot.answer_chat_join_request_query(qid, "approve")
                else:
                    await bot.approve_chat_join_request(chat_id, user_id)
            except Exception:
                try:
                    await bot.approve_chat_join_request(chat_id, user_id)
                except Exception:
                    logging.warning("не удалось одобрить заявку после капчи (guard)")
            return
        if kind == "join_request":
            _passed[(chat_id, user_id)] = time.time()
            try:
                await bot.approve_chat_join_request(chat_id, user_id)
                text = "✅ Проверка пройдена, заявка одобрена. Добро пожаловать!"
            except Exception:
                text = "✅ Проверка пройдена. Не удалось одобрить заявку автоматически — её одобрит админ."
            try:
                await bot.edit_message_text(text, chat_id=user_id, message_id=message_id, reply_markup=None)
            except Exception:
                pass
            return
        if db is not None:
            muted = await db.get_state(chat_id, user_id, "mute", int(time.time()))
            if muted:   # модератор успел замутить, пока шла капча: мут сохраняем вместо снятия
                try:
                    await bot.restrict_chat_member(chat_id, user_id, permissions=ChatPermissions(can_send_messages=False),
                                                   until_date=muted["until"])
                except Exception:
                    pass
                try:
                    await bot.delete_message(chat_id, message_id)
                except Exception:
                    pass
                return
        if db is not None and message_id and kind == "member" and await _recheck(bot, db, chat_id, user_id, webapp_url):
            return                                       # выдана повторная капча — человек остаётся ограниченным
        perms = _FULL
        try:
            chat = await bot.get_chat(chat_id)
            if chat.permissions and chat.permissions.can_send_messages:
                perms = chat.permissions
        except Exception:
            pass
        try:
            await bot.restrict_chat_member(chat_id, user_id, permissions=perms)
        except Exception:
            pass
        try:
            await bot.delete_message(chat_id, message_id)
        except Exception:
            pass
        if db is not None and message_id:
            await send_welcome(bot, db, chat_id, user_id)
    return on_pass


async def expire_captcha(bot, cap: dict, db: Database | None = None) -> None:
    """Время вышло: участника исключаем (вернуться можно), заявку отклоняем."""
    record_failure(cap["chat_id"])   # волна непройденных капч поднимает сложность для следующих новичков
    if cap.get("kind") == "guard":
        qid = await db.guard_query_pop(cap["chat_id"], cap["user_id"]) if db is not None else None
        try:
            if qid:
                await bot.answer_chat_join_request_query(qid, "decline")
            else:
                await bot.decline_chat_join_request(cap["chat_id"], cap["user_id"])
        except Exception:
            try:
                await bot.decline_chat_join_request(cap["chat_id"], cap["user_id"])
            except Exception:
                pass
        return
    if cap.get("kind") == "join_request":
        try:
            await bot.decline_chat_join_request(cap["chat_id"], cap["user_id"])
        except Exception:
            pass
        try:
            await bot.edit_message_text("⌛ Время на проверку вышло, заявка отклонена. Подайте её снова.",
                                        chat_id=cap["user_id"], message_id=cap["message_id"], reply_markup=None)
        except Exception:
            pass
        return
    try:
        await bot.ban_chat_member(cap["chat_id"], cap["user_id"])
        await bot.unban_chat_member(cap["chat_id"], cap["user_id"])
    except Exception:
        pass
    try:
        await bot.delete_message(cap["chat_id"], cap["message_id"])
    except Exception:
        pass


async def captcha_watchdog(bot, db: Database) -> None:
    """Раз в 15 секунд закрывает просроченные капчи."""
    while True:
        await asyncio.sleep(15)
        try:
            for cap in await db.expired_captchas(int(time.time())):
                if await db.consume_captcha(cap["token"]):
                    await expire_captcha(bot, cap, db)
        except Exception:
            logging.exception("captcha watchdog")

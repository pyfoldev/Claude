"""Мастер первой настройки: при добавлении бота в группу — проверка прав/приватности и кнопки основных функций."""
import time

from aiogram import F, Router
from aiogram.types import CallbackQuery, ChatMemberUpdated, InlineKeyboardButton as B, InlineKeyboardMarkup

from bot.db import Database
from bot.diagnostics import diagnose_chat
from bot.mod_service import is_admin

router = Router(name="setup")

# (ключ настройки, подпись) — только эти ключи можно менять из мастера
WIZARD = [("captcha_on", "Капча"), ("spam_on", "Антиспам"), ("phish_on", "Фишинг-ссылки"), ("raid_on", "Антирейд"), ("nsfw_on", "Фильтр 18+"),
          ("transcribe_on", "Расшифровка голосовых"), ("ai_on", "ИИ"), ("spam_ai", "ИИ-проверка новичков")]
_KEYS = {k for k, _ in WIZARD}
RESEND_AFTER = 3600
_sent: dict[int, float] = {}   # чат -> когда последний раз присылали мастер


def render(cfg: dict, report: str, webapp_url: str = "", panel_url: str | None = None) -> tuple[str, InlineKeyboardMarkup]:
    text = "👋 <b>Первая настройка</b>\n\n" + report
    if cfg.get("captcha_on") and not webapp_url:
        text += "\n\n⚠️ Капча включена, но у бота не задан WEBAPP_URL — она работать не будет."
    text += "\n\nВключите нужное (только админы). Остальное — в разделе «Все настройки»."
    rows = [[B(text=f"{'✅' if cfg[key] else '❌'} {label}", callback_data=f"wiz:{key}:{0 if cfg[key] else 1}",
               style="success" if cfg[key] else None)] for key, label in WIZARD]
    rows.append([B(text="⚙️ Все настройки", callback_data="cfg:home"), B(text="📖 Меню", callback_data="menu:home")])
    if panel_url:
        rows.append([B(text="🌐 Открыть как приложение", url=panel_url, style="primary")])
    return text, InlineKeyboardMarkup(inline_keyboard=rows)


@router.my_chat_member(F.chat.type.in_({"group", "supergroup"}))
async def on_bot_added(ev: ChatMemberUpdated, bot, db: Database, webapp_url: str = "") -> None:
    was_in = ev.old_chat_member.status in ("member", "administrator", "restricted", "creator")
    now_in = ev.new_chat_member.status in ("member", "administrator", "creator")
    if was_in or not now_in:
        return
    now = time.time()
    if now - _sent.get(ev.chat.id, 0) < RESEND_AFTER:
        return
    _sent[ev.chat.id] = now
    report = await diagnose_chat(bot, db, ev.chat.id)
    from bot.handlers.settings import panel_url
    text, kb = render(await db.get_settings(ev.chat.id), report, webapp_url, await panel_url(bot, ev.chat.id, webapp_url))
    try:
        await bot.send_message(ev.chat.id, text, reply_markup=kb)
    except Exception:
        _sent.pop(ev.chat.id, None)


@router.callback_query(F.data.startswith("wiz:"))
async def wizard_toggle(cb: CallbackQuery, bot, db: Database, webapp_url: str = "") -> None:
    parts = cb.data.split(":")
    if len(parts) != 3 or parts[1] not in _KEYS or parts[2] not in ("0", "1") or cb.message is None:
        await cb.answer()
        return
    if not await is_admin(bot, cb.message.chat.id, cb.from_user.id):
        await cb.answer("Только для админов", show_alert=True)
        return
    await db.set_setting(cb.message.chat.id, parts[1], parts[2], actor=cb.from_user.id)
    cfg = await db.get_settings(cb.message.chat.id)
    report = await diagnose_chat(bot, db, cb.message.chat.id)
    from bot.handlers.settings import panel_url
    text, kb = render(cfg, report, webapp_url, await panel_url(bot, cb.message.chat.id, webapp_url))
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except Exception:
        pass
    await cb.answer("Сохранено")

"""Nori Premium (подписка за звёзды Telegram), выбор модели ИИ и промокоды.

«премиум» / «/premium» — что даёт и статус, кнопка оплаты (счёт-подписка на 30 дней, продлевается автоматически);
оплата → successful_payment → Premium до даты окончания подписки. «модель» — выбор модели ИИ (Premium).
«промокод КОД» — Premium по промокоду; владелец: «+промокод [КОД] [дней] [активаций]», «-промокод КОД», «промокоды».
Владелец бота (в личке): «выдать премиум <id> <дней>», «возврат <id>» (возврат звёзд за последний платёж), «подписчики»."""
from __future__ import annotations

import html
import logging
import re
import time
from datetime import datetime, timezone

from aiogram import F, Router
from aiogram.types import (CallbackQuery, InlineKeyboardButton as B, InlineKeyboardMarkup,
                           LabeledPrice, Message, PreCheckoutQuery)

from bot import plans
from bot.db import Database

router = Router(name="premium")
PAYLOAD = "nori_premium_30d"
MODELS_TTL = 3600
MODELS_MAX = 12
_NOT_CHAT = ("embed", "whisper", "tts", "rerank", "guard", "clip", "bge", "e5-", "diffusion", "flux", "sdxl", "ocr")
_models: tuple[float, list[str]] = (0.0, [])

_PREMIUM = re.compile(r"^(?:премиум|premium|/premium(?:@\w+)?|/start premium|подписка ии)$", re.IGNORECASE)
_MODEL = re.compile(r"^(?:модель|модели|/model(?:@\w+)?)$", re.IGNORECASE)
_GRANT = re.compile(r"^выдать премиум\s+(\d{1,15})(?:\s+(\d{1,4}))?$", re.IGNORECASE)
_REFUND = re.compile(r"^возврат\s+(\d{1,15})$", re.IGNORECASE)
_PROMO_USE = re.compile(r"^(?:промокод|/promo(?:@\w+)?)\s+[\"«»']?([A-Za-z0-9_-]{3,32})[\"«»']?$", re.IGNORECASE)
_PROMO_NEW = re.compile(r"^\+промокод(?:\s+([A-Za-z0-9_-]{3,32}))?(?:\s+(\d{1,4}))?(?:\s+(\d{1,6}))?$", re.IGNORECASE)
_PROMO_DEL = re.compile(r"^-промокод\s+([A-Za-z0-9_-]{3,32})$", re.IGNORECASE)
PROMO_TRIES = 5                    # попыток ввести промокод в час на человека (защита от перебора)
_promo_tries: dict[int, list[float]] = {}


def _date(ts: int) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%d.%m.%Y")


async def invoice_link(bot, price: int) -> str:
    return await bot.create_invoice_link(
        title="Nori Premium", description="ИИ без кулдауна, выбор модели, больше вопросов и картинок. 30 дней.",
        payload=PAYLOAD, currency="XTR", prices=[LabeledPrice(label="Premium на 30 дней", amount=price)],
        subscription_period=plans.PREMIUM_PERIOD)


async def _premium_card(bot, db: Database, uid: int, owner_ids: frozenset, price: int) -> tuple[str, InlineKeyboardMarkup | None]:
    until = await db.premium_until(uid)
    now = int(time.time())
    if uid in owner_ids:
        status = "\n\n✅ Вы владелец бота — Premium всегда включён."
    elif until and until > now:
        status = f"\n\n✅ У вас Premium до <b>{_date(until)}</b> (продлевается автоматически)."
    else:
        status = "\n\nСейчас у вас бесплатный тариф: " + (
            f"{plans.FREE.ai_daily} вопросов к ИИ в сутки, раз в {plans.FREE.ai_cooldown} с, {plans.FREE.img_daily} картинки.")
    kb = None
    if not (until and until > now) and uid not in owner_ids:
        try:
            kb = InlineKeyboardMarkup(inline_keyboard=[[B(text=f"⭐ Оформить за {price} звёзд", url=await invoice_link(bot, price))]])
        except Exception as e:
            logging.warning("premium: invoice link failed: %s", e)
    return plans.benefits_text(price) + status, kb


@router.message(F.text.func(lambda t: bool(t) and _PREMIUM.match(t.strip()) is not None))
async def premium_cmd(message: Message, bot, db: Database, owner_ids: frozenset = frozenset(),
                      premium_price: int = plans.PREMIUM_PRICE) -> None:
    text, kb = await _premium_card(bot, db, message.from_user.id, owner_ids, premium_price)
    await message.reply(text, reply_markup=kb)


@router.callback_query(F.data == "prem:info")
async def premium_info_cb(cb: CallbackQuery, bot, db: Database, owner_ids: frozenset = frozenset(),
                          premium_price: int = plans.PREMIUM_PRICE) -> None:
    text, kb = await _premium_card(bot, db, cb.from_user.id, owner_ids, premium_price)
    await cb.answer()
    try:
        await bot.send_message(cb.from_user.id, text, reply_markup=kb)      # подробности и оплата — в личке
    except Exception:
        if cb.message is not None:
            await cb.message.answer(text, reply_markup=kb)


@router.pre_checkout_query()
async def pre_checkout(q: PreCheckoutQuery, premium_price: int = plans.PREMIUM_PRICE) -> None:
    ok = q.invoice_payload == PAYLOAD and q.currency == "XTR" and q.total_amount == premium_price
    await q.answer(ok=ok, error_message=None if ok else "Счёт устарел — откройте «премиум» ещё раз.")


@router.message(F.successful_payment)
async def paid(message: Message, db: Database, owner_ids: frozenset = frozenset()) -> None:
    sp = message.successful_payment
    if sp.invoice_payload != PAYLOAD:
        return
    uid, now = message.from_user.id, int(time.time())
    if not await db.payment_add(uid, sp.telegram_payment_charge_id, sp.total_amount, now, bool(sp.is_recurring)):
        return                                        # дубль того же платежа
    until = sp.subscription_expiration_date or now + plans.PREMIUM_PERIOD
    await db.premium_grant(uid, int(until), now)
    await db.log_owner(uid, "premium", f"оплата {sp.total_amount}⭐ до {_date(int(until))}"
                       + (" (продление)" if sp.is_recurring else ""), now)
    await message.answer(f"⭐ Спасибо! Nori Premium активен до <b>{_date(int(until))}</b>.\n"
                         "Теперь: ИИ без кулдауна, больше вопросов и картинок, выбор модели — <code>модель</code>.")


# ---------- выбор модели ----------

async def _model_list(ai) -> list[str]:
    global _models
    if time.time() - _models[0] < MODELS_TTL and _models[1]:
        return _models[1]
    import os
    env = [m.strip() for m in os.environ.get("AI_MODELS", "").split(",") if m.strip()]
    found = env or [m for m in await ai.list_models() if not any(x in m.lower() for x in _NOT_CHAT)]
    default = getattr(ai, "river_model", None)
    out = ([default] if default else []) + [m for m in found if m != default]
    _models = (time.time(), out[:MODELS_MAX])
    return _models[1]


def _short(model: str) -> str:
    return model.rsplit("/", 1)[-1][:40]


@router.message(F.text.func(lambda t: bool(t) and _MODEL.match(t.strip()) is not None))
async def model_cmd(message: Message, db: Database, ai=None, owner_ids: frozenset = frozenset()) -> None:
    uid = message.from_user.id
    if (await plans.plan_for(db, uid, owner_ids)) is not plans.PREMIUM:
        await message.reply("🧠 Выбор модели ИИ — в Nori Premium.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            B(text="⭐ Nori Premium", callback_data="prem:info")]]))
        return
    if ai is None or not getattr(ai, "has_river", False):
        await message.reply("ИИ не настроен.")
        return
    models = await _model_list(ai)
    current = (await db.get_ai_model(uid)) or (models[0] if models else "")
    rows = [[B(text=("✅ " if m == current else "") + _short(m), callback_data=f"mdl:{i}")] for i, m in enumerate(models)]
    await message.reply("🧠 <b>Модель ИИ</b> — для ваших вопросов «ии, …» (первая — по умолчанию):",
                        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("mdl:"))
async def model_cb(cb: CallbackQuery, db: Database, ai=None, owner_ids: frozenset = frozenset()) -> None:
    uid = cb.from_user.id
    idx = cb.data.split(":", 1)[1]
    if (await plans.plan_for(db, uid, owner_ids)) is not plans.PREMIUM:
        await cb.answer("Выбор модели — в Premium.", show_alert=True)
        return
    models = await _model_list(ai) if ai is not None else []
    if not idx.isdigit() or int(idx) >= len(models):
        await cb.answer("Список моделей обновился — откройте «модель» ещё раз.", show_alert=True)
        return
    model = models[int(idx)]
    await db.set_ai_model(uid, None if int(idx) == 0 else model)
    await cb.answer(f"Модель: {_short(model)}")
    rows = [[B(text=("✅ " if m == model else "") + _short(m), callback_data=f"mdl:{i}")] for i, m in enumerate(models)]
    try:
        await cb.message.edit_reply_markup(reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    except Exception:
        pass


def _prem_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[B(text="⭐ Nori Premium", callback_data="prem:info")]])


# ---------- владелец бота ----------

def _owner_cmd(t: str | None) -> bool:
    t = (t or "").strip()
    return bool(_GRANT.match(t) or _REFUND.match(t) or t.lower() == "подписчики")


@router.message(F.chat.type == "private", F.text.func(_owner_cmd))
async def owner_cmd(message: Message, bot, db: Database, owner_ids: frozenset = frozenset()) -> None:
    if message.from_user.id not in owner_ids:
        return
    t, now, oid = message.text.strip(), int(time.time()), message.from_user.id
    if t.lower() == "подписчики":
        active, stars = await db.premium_stats(now)
        await message.answer(f"⭐ Premium: активных {active}, получено {stars} звёзд (без возвратов).")
        return
    m = _GRANT.match(t)
    if m:
        uid, days = int(m.group(1)), int(m.group(2) or plans.PREMIUM_DAYS)
        base = max(await db.premium_until(uid) or 0, now)
        await db.premium_grant(uid, base + days * 86400, now)
        await db.log_owner(oid, "premium выдан", f"user {uid} на {days} дн.", now)
        await message.answer(f"✅ Пользователю {uid} выдан Premium до {_date(base + days * 86400)}.")
        return
    uid = int(_REFUND.match(t).group(1))
    pay = await db.payment_last(uid)
    if pay is None:
        await message.answer("Платежей этого пользователя не найдено.")
        return
    try:
        await bot.refund_star_payment(user_id=uid, telegram_payment_charge_id=pay["charge_id"])
    except Exception as e:
        await message.answer(f"Возврат не прошёл: {html.escape(str(e))[:200]}")
        return
    try:                                              # и отменяем автопродление
        await bot.edit_user_star_subscription(user_id=uid, telegram_payment_charge_id=pay["charge_id"], is_canceled=True)
    except Exception:
        pass
    await db.payment_refunded(pay["id"])
    await db.premium_revoke(uid)
    await db.log_owner(oid, "premium возврат", f"user {uid}: {pay['amount']}⭐", now)
    await message.answer(f"↩️ Возвращено {pay['amount']} звёзд пользователю {uid}, Premium снят.")



# ---------- промокоды ----------

def _promo_rate_ok(uid: int) -> bool:
    now = time.time()
    tries = [t for t in _promo_tries.get(uid, []) if now - t < 3600]
    if len(tries) >= PROMO_TRIES:
        _promo_tries[uid] = tries
        return False
    tries.append(now)
    _promo_tries[uid] = tries
    if len(_promo_tries) > 20000:
        _promo_tries.clear()
    return True


@router.message(F.text.func(lambda t: bool(t) and _PROMO_USE.match(t.strip()) is not None))
async def promo_use(message: Message, bot, db: Database, owner_ids: frozenset = frozenset()) -> None:
    """«промокод КОД» — активировать Premium по промокоду. В группе сообщение с кодом удаляем, чтобы его не увидели другие."""
    uid, now = message.from_user.id, int(time.time())
    code = _PROMO_USE.match(message.text.strip()).group(1).upper()
    if message.chat.type in ("group", "supergroup"):
        try:
            await bot.delete_message(message.chat.id, message.message_id)
        except Exception:
            pass
    if not _promo_rate_ok(uid):
        await message.answer("Слишком много попыток ввести промокод. Попробуйте через час.")
        return
    status, days = await db.promo_redeem(code, uid, now)
    if status == "used":
        await message.answer("Вы уже активировали этот промокод.")
        return
    if status != "ok":
        await message.answer("Такого промокода нет или он закончился.")
        return
    base = max(await db.premium_until(uid) or 0, now)
    until = base + days * 86400
    await db.premium_grant(uid, until, now)
    await db.log_owner(uid, "premium промокод", f"{code}: {days} дн. до {_date(until)}", now)
    who = message.from_user.full_name
    await message.answer(f"🎁 {html.escape(who)}, промокод активирован! Nori Premium на {days} дн. — до <b>{_date(until)}</b>.\n"
                         "ИИ без кулдауна, больше вопросов и картинок, выбор модели — <code>модель</code>.")


def _promo_admin_cmd(t: str | None) -> bool:
    t = (t or "").strip()
    return bool(_PROMO_NEW.match(t) or _PROMO_DEL.match(t) or t.lower() == "промокоды")


@router.message(F.chat.type == "private", F.text.func(_promo_admin_cmd))
async def promo_admin(message: Message, db: Database, owner_ids: frozenset = frozenset()) -> None:
    """Владелец: «+промокод [КОД] [дней] [активаций]» (по умолчанию — случайный код, 30 дней, 1 активация),
    «-промокод КОД», «промокоды»."""
    if message.from_user.id not in owner_ids:
        return
    t, now = message.text.strip(), int(time.time())
    if t.lower() == "промокоды":
        rows = await db.promo_list()
        if not rows:
            await message.answer("Промокодов нет. Создать: <code>+промокод</code> или <code>+промокод NORI2026 30 1</code>")
            return
        lines = [f"<code>{r['code']}</code> — {r['days']} дн., осталось активаций: {r['uses_left']}, активировали: {r['used']}"
                 for r in rows]
        await message.answer("🎁 <b>Промокоды</b>\n" + "\n".join(lines))
        return
    m = _PROMO_DEL.match(t)
    if m:
        ok = await db.promo_delete(m.group(1).upper())
        await message.answer("🗑 Промокод удалён." if ok else "Такого промокода нет.")
        return
    m = _PROMO_NEW.match(t)
    import secrets
    code = (m.group(1) or "NORI-" + "".join(secrets.choice("ABCDEFGHJKMNPQRSTUVWXYZ23456789") for _ in range(8))).upper()
    days, uses = int(m.group(2) or plans.PREMIUM_DAYS), int(m.group(3) or 1)
    if not 1 <= days <= 3650 or uses < 1:
        await message.answer("Дней — от 1 до 3650, активаций — от 1.")
        return
    if not await db.promo_create(code, days, uses, message.from_user.id, now):
        await message.answer("Такой промокод уже есть.")
        return
    await message.answer(f"🎁 Промокод создан: <code>{code}</code>\nPremium на {days} дн., активаций: {uses}.\n"
                         f"Активировать: <code>промокод {code}</code> (лучше в личке с ботом).")

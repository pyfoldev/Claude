"""Панель настроек чата (`настройки`): разделы с переключателями и порогами. Только для админов."""
from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton as B, InlineKeyboardMarkup, Message

from bot import mod_service as ms
from bot.db import Database
from bot.ranks import need_rank
from bot.toggles import GROUPS

router = Router(name="settings")

NOTES = {"aimod": "Текст уходит во внешний ИИ.", "ai": "В живом общении последние сообщения уходят во внешний ИИ."}
ACTIONS = [("Удалить", "delete"), ("Варн", "warn"), ("Мут", "mute")]

SHORT = {"mod_on": "Модерация", "stats_on": "Статистика", "rally_on": "Общий сбор", "quotes_on": "Цитатник",
         "mog_on": "Мог-баттлы", "giveaway_on": "Конкурсы", "suggest_on": "Предложка", "img_on": "Картинки «нарисуй»",
         "dl_on": "Скачивание «скачай»", "dl_auto": "Скачивание по ссылке"}

# page -> (заголовок, строки). Строка: ("toggle", key, подпись) | ("choice", key, подпись, [(текст, значение)])
PAGES: dict[str, tuple[str, list[tuple]]] = {
    "captcha": ("🛡 Капча", [
        ("toggle", "captcha_on", "Капча для новичков"),
        ("choice", "captcha_timeout", "Время", [("1 мин", 60), ("3 мин", 180), ("5 мин", 300)]),
    ]),
    "spam": ("🚫 Антиспам", [
        ("toggle", "spam_on", "Антиспам"),
        ("choice", "spam_flood_n", "Флуд, сообщ.", [("3", 3), ("5", 5), ("8", 8)]),
        ("choice", "spam_flood_sec", "за, сек", [("5", 5), ("10", 10), ("20", 20)]),
        ("toggle", "spam_dup", "Одинаковые сообщения"),
        ("choice", "links_mode", "Ссылки", [("Всем можно", "off"), ("Новичкам нет", "newbies"), ("Всем нет", "all")]),
        ("choice", "spam_mentions", "Упоминаний макс.", [("3", 3), ("5", 5), ("10", 10)]),
        ("toggle", "spam_forward", "Пересылки от новичков"),
        ("toggle", "spam_ai", "ИИ-проверка новичков"),
        ("choice", "spam_action", "Действие", ACTIONS),
    ]),
    "filters": ("📝 Стоп-слова", [
        ("choice", "filter_action", "Действие", ACTIONS),
    ]),
    "raid": ("🚨 Антирейд", [
        ("toggle", "raid_on", "Антирейд"),
        ("choice", "raid_n", "Входов", [("3", 3), ("5", 5), ("10", 10)]),
        ("choice", "raid_sec", "за, сек", [("30", 30), ("60", 60), ("120", 120)]),
        ("choice", "raid_action", "Новичкам", [("Капча", "captcha"), ("Кик", "kick")]),
        ("choice", "raid_minutes", "Режим, мин", [("5", 5), ("10", 10), ("30", 30)]),
    ]),
    "nsfw": ("🔞 Фильтр 18+", [
        ("toggle", "nsfw_on", "Фильтр 18+"),
        ("choice", "nsfw_threshold", "Строгость", [("Строго", 35), ("Средне", 55), ("Мягко", 75)]),
        ("choice", "nsfw_action", "Действие", ACTIONS),
        ("toggle", "nsfw_ai", "ИИ-проверка (картинка уходит во внешний ИИ)"),
    ]),
    "voice": ("🎙 Расшифровка", [
        ("toggle", "transcribe_on", "Расшифровка голосовых"),
        ("choice", "transcribe_max", "Макс. длина", [("1 мин", 60), ("3 мин", 180), ("10 мин", 600)]),
    ]),
    "aimod": ("🤖 ИИ-модерация", [
        ("choice", "ai_mod", "Проверять", [("Выкл", "off"), ("Новичков", "newbies"), ("Подозрительное", "all")]),
        ("choice", "ai_mod_action", "Действие", ACTIONS + [("Жалоба", "report")]),
        ("choice", "ai_mod_conf", "Уверенность", [("60%", 60), ("75%", 75), ("90%", 90)]),
    ]),
    "ai": ("🤖 ИИ", [
        ("toggle", "ai_on", "Команда «ии …»"),
        ("choice", "ai_chat", "Живое общение", [("Выкл", "off"), ("Отвечает", "reply"), ("Болтает", "live")]),
        ("choice", "ai_chat_style", "Стиль", [("По-свойски (с матом)", "casual"), ("Вежливо", "polite")]),
    ]),
    "welcome": ("👋 Приветствие", [("toggle", "welcome_on", "Приветствие")]),
    "report": ("📣 Жалобы", [("toggle", "report_on", "Команда «жалоба»")]),
    "commands": ("🧩 Команды", [("toggle", key, SHORT.get(key, label)) for key, label in GROUPS.items()]),
    "games": ("🎮 Игры и фан", [
        ("toggle", "games_on", "Игры"),
        ("toggle", "fun_on", "«кто …»"),
        ("toggle", "rp_on", "РП и семья"),
        ("toggle", "rep_on", "Репутация"),
    ]),
    "warns": ("⚠️ Варны", [
        ("choice", "warn_limit", "Лимит до автомута", [("2", 2), ("3", 3), ("5", 5)]),
        ("choice", "warn_ttl_days", "Срок жизни варна", [("7 д", 7), ("30 д", 30), ("90 д", 90), ("Бессрочно", 0)]),
    ]),
}


def allowed_values(key: str) -> set[str]:
    out: set[str] = set()
    for _, rows in PAGES.values():
        for row in rows:
            if row[1] != key:
                continue
            out |= {"0", "1"} if row[0] == "toggle" else {str(v) for _, v in row[3]}
    return out


def render_page(page: str, s: dict) -> tuple[str, InlineKeyboardMarkup]:
    if page == "home" or page not in PAGES:
        btns = [B(text=title, callback_data=f"cfg:{p}") for p, (title, _) in PAGES.items()]
        rows = [btns[i:i + 2] for i in range(0, len(btns), 2)]          # сетка по 2 кнопки, как главное меню
        rows.append([B(text="⬅️ В меню", callback_data="menu:home")])
        return "⚙️ <b>Настройки чата</b>", InlineKeyboardMarkup(inline_keyboard=rows)
    title, spec = PAGES[page]
    kb: list[list[B]] = []
    for row in spec:
        if row[0] == "toggle":
            _, key, label = row
            on = bool(s[key])
            kb.append([B(text=f"{'✅' if on else '❌'} {label}", callback_data=f"set:{page}:{key}:{0 if on else 1}",
                         style="success" if on else None)])            # включённое подсвечено зелёным (Bot API 9.4)
        else:
            _, key, label, values = row
            kb.append([B(text=label, callback_data="noop")] + [
                B(text=("• " if str(s[key]) == str(v) else "") + t, callback_data=f"set:{page}:{key}:{v}",
                  style="primary" if str(s[key]) == str(v) else None)
                for t, v in values])
    kb.append([B(text="⬅️ К разделам", callback_data="cfg:home")])
    note = NOTES.get(page)
    return f"<b>{title}</b>" + (f"\n<i>{note}</i>" if note else ""), InlineKeyboardMarkup(inline_keyboard=kb)


async def can_configure(bot, db: Database, chat_id: int, user_id: int) -> bool:
    """Админ Telegram или модератор бота с рангом из ДК «настройки чата» — то же правило, что и в веб-панели."""
    try:
        m = await ms.get_member(bot, chat_id, user_id)
    except Exception:
        return False
    if m.status in ("administrator", "creator"):
        return True
    return await db.get_rank(chat_id, user_id) >= need_rank(await db.get_access(chat_id), "настройки чата")


async def _denied(cb: CallbackQuery) -> None:
    await cb.answer("Только для админов и модераторов с нужным рангом", show_alert=True)


async def open_settings(cb: CallbackQuery, bot, db: Database) -> None:
    if cb.message.chat.type == "private":
        await cb.answer("Настройки доступны в группе.", show_alert=True)
        return
    if not await can_configure(bot, db, cb.message.chat.id, cb.from_user.id):
        await _denied(cb)
        return
    text, kb = render_page("home", await db.get_settings(cb.message.chat.id))
    await cb.message.edit_text(text, reply_markup=kb)
    await cb.answer()


@router.message(F.text.func(lambda t: bool(t) and t.strip().lower() in ("настройки", "настройка")))
async def settings_cmd(message: Message, bot, db: Database) -> None:
    if message.chat.type == "private":
        await message.answer("Настройки доступны в группе.")
        return
    if not await can_configure(bot, db, message.chat.id, message.from_user.id):
        await message.answer("Настройки только для админов и модераторов с нужным рангом.")
        return
    text, kb = render_page("home", await db.get_settings(message.chat.id))
    await message.answer(text, reply_markup=kb)


async def _show(cb: CallbackQuery, db: Database, page: str) -> None:
    text, kb = render_page(page, await db.get_settings(cb.message.chat.id))
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except Exception:  # «message is not modified»
        pass


@router.callback_query(F.data == "noop")
async def noop_cb(cb: CallbackQuery) -> None:
    await cb.answer()


@router.callback_query(F.data.startswith("cfg:"))
async def cfg_cb(cb: CallbackQuery, bot, db: Database) -> None:
    if not await can_configure(bot, db, cb.message.chat.id, cb.from_user.id):
        await _denied(cb)
        return
    await _show(cb, db, cb.data.split(":", 1)[1])
    await cb.answer()


@router.callback_query(F.data.startswith("set:"))
async def set_cb(cb: CallbackQuery, bot, db: Database) -> None:
    parts = cb.data.split(":")
    if len(parts) != 4:
        await cb.answer()
        return
    _, page, key, value = parts
    if page not in PAGES or value not in allowed_values(key):
        await cb.answer()
        return
    if not await can_configure(bot, db, cb.message.chat.id, cb.from_user.id):
        await _denied(cb)
        return
    await db.set_setting(cb.message.chat.id, key, value, actor=cb.from_user.id)
    await _show(cb, db, page)
    await cb.answer("Сохранено")

"""Пара: меню, действия, РП пары, история искр, расходы, список и топ, ссора, обида, расставание.
Команды без слэша: «пара …» или «отн …» (например «пара действия», «пара завтрак», «пара обнять»). Запрос и брак — прежние
команды «отношения @ник» / «брак @ник» (handlers/family.py): теперь они создают пару с общим кошельком."""
import asyncio
import html
import logging
import re
import time

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message

from bot import ux
from bot.db import Database
from bot.family import Family
from bot.mod_service import real_reply
from bot.pair import data, economy as eco, gifts as gf, quests as qs
from bot.pair.service import PairService, effective_streak, is_sleeping, partner_of, side_of
from bot.rich_ui import Btn, Screen
from bot import rich_ui
from bot.targets import mention, resolve_user

router = Router(name="pair")
_RE = re.compile(r"^(?:пара|отн)(?:\s+(.+))?$", re.IGNORECASE | re.DOTALL)
SUBS = {"меню": "menu", "я": "menu", "профиль": "menu", "действия": "actions", "действие": "actions", "история": "history",
        "лог": "history", "расходы": "costs", "расход": "costs", "содержание": "costs", "список": "list", "топ": "top",
        "расстаться": "end", "расторгнуть": "end", "обида": "offense", "обидеться": "offense", "простить": "offense",
        "помириться": "peace", "мир": "peace", "пополнить": "topup", "справка": "help", "помощь": "help",
        "запрос": "request", "задания": "quests", "задание": "quests", "квесты": "quests", "сезон": "season", "подарки": "gifts", "подарок": "gifts", "магазин": "gifts", "подарить": "give", "витрина": "showcase", "награда": "claim", "да": "yes", "нет": "no"}
TOP_KINDS = {"тепло": "тепло", "искры": "искры", "длительность": "длительность", "активность": "активность"}


def parse(text: str | None):
    """(команда, остаток) или None, если это не команда пары («пара минут» в обычной речи не трогаем)."""
    m = _RE.match((text or "").strip())
    if not m:
        return None
    rest = (m.group(1) or "").strip()
    if not rest:
        return "menu", ""
    word, _, arg = rest.partition(" ")
    key = data.norm(word)
    if key in SUBS:
        return SUBS[key], arg.strip()
    if data.find_action(rest):
        return "act", rest
    if data.find_rp(rest):
        return "rp", rest
    return None


def n(x: int) -> str:
    return f"{int(x):,}".replace(",", " ")


async def name(db: Database, uid: int) -> str:
    return (await db.user_name(uid)) or f"id{uid}"


async def m(db: Database, uid: int) -> str:
    return str(mention(uid, await name(db, uid)))


def duration_since(ts: int, now: int) -> str:
    return eco.fmt_duration(max(now - ts, 0))


# ---------- события (сообщения про ссору, распад, уровень) ----------
async def event_text(db: Database, p: dict, ev: tuple) -> str | None:
    kind, d = ev
    a, b = await m(db, p["u1"]), await m(db, p["u2"])
    if kind == "levelup":
        return f"💠 {a} и {b}: новый уровень — <b>{data.level_name(d['level'])}</b> ({d['level']})! 🎁 +{n(d['gift'])} 🔥"
    if kind == "quarrel":
        return (f"💢 {a} и {b}, ваши искры погасли: вы в ссоре, действия закрыты. Помирят любые искры — "
                f"<code>пара пополнить 100</code>. На это {eco.QUARREL_HOURS} часа, иначе пара распадётся.")
    if kind == "dissolved":
        return (f"💔 Отношения {a} и {b}, длившиеся {duration_since(d['since'], int(time.time()))}, закончились: "
                "вы так и не помирились.")
    if kind == "warn":
        return (f"🚨 {a} и {b}, искр не хватит на завтрашнее содержание: осталось {n(d['sparks'])}, нужно {n(d['need'])}. "
                "Загляните в <code>пара действия</code>.")
    if kind == "quest":
        return f"✅ {a} и {b} выполнили задание: {d['text']} · +{n(d['sparks'])} 🔥 · +{d['warmth']} ☀️"
    if kind == "peace":
        return f"🕊 {a} и {b} помирились! Искры вернулись, действия снова открыты."
    return None


async def event_lines(db: Database, p: dict, events: list, skip: tuple = ()) -> list[str]:
    out = []
    for ev in events:
        if ev[0] in skip:
            continue
        t = await event_text(db, p, ev)
        if t:
            out.append(t)
    return out


# ---------- экраны ----------
def menu_screen(p: dict, partner_name: str, now: int, kids: int, notes: list[str]) -> Screen:
    lvl = p["level"]
    base = eco.threshold(lvl)
    step = eco.level_step(lvl)
    upkeep = eco.upkeep_amount(lvl, kids, p["sparks"])
    side = side_of(p, p["u1"])
    lines = [f"💞 <b>Половинка:</b> {partner_name}",
             f"💠 Уровень {lvl} · <b>{data.level_name(lvl)}</b>",
             f"☀️ Тепло {n(p['warmth'] - base)} из {n(step)}",
             f"🔥 Искры {n(p['sparks'])}",
             f"📉 Расход {n(upkeep)} в сутки"
             + (f" · спишется через {eco.fmt_duration(p['upkeep_at'] - now)}" if p["state"] == "ok" else ""),
             f"📅 Серия {effective_streak(p, now)} дн. · +{int(eco.streak_bonus(effective_streak(p, now)) * 100)}% к теплу",
             f"🕙 Вместе {duration_since(p['created'], now)}"
             + (" · 💍 в браке" if p["stage"] == "marriage" else "")]
    lines += notes
    lines.append(f"🆔 Пара № {p['id']}")
    pid = p["id"]
    rows = [[Btn("✨ Действия", cb=f"pr:a:{pid}"), Btn("📋 История", cb=f"pr:h:{pid}:all:0")],
            [Btn("📉 Расходы", cb=f"pr:e:{pid}"), Btn("👥 Пары беседы", cb=f"pr:l:{pid}")],
            [Btn("📋 Задания", cb=f"pr:q:{pid}"), Btn("🏆 Топ", cb=f"pr:t:{pid}:тепло")],
            [Btn("🎁 Подарки", cb=f"pr:gs:{pid}:0"), Btn("🏛 Витрина", cb=f"pr:sc:{pid}")],
            [Btn("⚙️ Ещё", cb=f"pr:more:{pid}")]]
    return Screen("💞 Ваша пара", lines, rows)


def more_screen(p: dict, user: int) -> Screen:
    pid = p["id"]
    offended = p["offended_by"] == user
    return Screen("⚙️ Ещё", [
        "😢 Обида закрывает половинке действия и РП, пока ты не простишь.",
        "🕊 Помирить пару в ссоре может любое пополнение искр.",
        "💰 Пополнить кошелёк монетами: <code>пара пополнить 100</code> (1 монета = 1 искра)."],
        [[Btn("😊 Простить" if offended else "😢 Обидеться", cb=f"pr:ob:{pid}"), Btn("🕊 Помириться", cb=f"pr:peace:{pid}")],
         [Btn("💔 Расстаться", cb=f"pr:end:{pid}", style="danger")], [Btn("◀️ Меню", cb=f"pr:m:{pid}", style="link")]])


def actions_screen(p: dict, now: int, user: int, result_lines: list[str] | None = None) -> Screen:
    pid, lvl = p["id"], p["level"]
    side = side_of(p, user)
    wait = max(p[f"next{side}"] - now, 0)
    best = data.best_action(lvl)
    nxt = data.next_action(lvl)
    lines = list(result_lines or [])
    lines.append(f"✨ Лучшее: <b>{best.key}</b> · +{n(best.sparks)} 🔥 · откат {best.cd} мин.")
    if nxt:
        lines.append(f"🔒 Дальше: {nxt.key} — с {nxt.level} уровня")
    lines.append("✅ Действие доступно" if wait == 0 else f"⏳ Следующее действие через {eco.fmt_duration(wait)}")
    lines.append("<i>Нажми на название или напиши «пара название».</i>")
    avail = data.unlocked(lvl)[-8:][::-1]
    btns = [Btn(f"{a.emoji} {a.key}", cb=f"pr:do:{pid}:{a.level}", style="primary" if a is best and wait == 0 else None) for a in avail]
    rows = [btns[i:i + 2] for i in range(0, len(btns), 2)]
    rows.append([Btn("◀️ Меню", cb=f"pr:m:{pid}", style="link")])
    return Screen("✨ Действия", lines, rows)


async def history_screen(svc: PairService, db: Database, p: dict, kind: str, page: int, now: int) -> Screen:
    pid = p["id"]
    rows_, total = await svc.history(pid, page, 10, kind, now)
    pages = max((total + 9) // 10, 1)
    page = min(max(page, 0), pages - 1)
    icons = {"action": "✨", "upkeep": "📉", "topup": "💰", "create": "💞", "quarrel": "💢", "level": "💠"}
    lines = [f"🔥 Сейчас: {n(p['sparks'])}"]
    for r in rows_:
        t = time.strftime("%d.%m %H:%M", time.localtime(r["ts"] + 3 * 3600 - time.timezone))
        who = f" · {html.escape(await name(db, r['actor']))}" if r["actor"] else ""
        warm = f" · тепло +{r['warmth']}" if r["warmth"] else ""
        lines.append(f"{icons.get(r['kind'], '•')} {html.escape(r['detail'] or r['kind'])} · {t}{who} · стало {n(r['balance'])}{warm} · "
                     f"<b>{'+' if r['amount'] > 0 else ''}{n(r['amount'])}</b>")
    if not rows_:
        lines.append("Записей пока нет. История хранится 30 дней.")
    tabs = [Btn(("• " if kind == k else "") + label, cb=f"pr:h:{pid}:{k}:0") for label, k in (("Все", "all"), ("Приход", "in"), ("Траты", "out"))]
    nav = []
    if page > 0:
        nav.append(Btn("◀️", cb=f"pr:h:{pid}:{kind}:{page - 1}"))
    nav.append(Btn(f"{page + 1}/{pages}", cb="noop"))
    if page < pages - 1:
        nav.append(Btn("▶️", cb=f"pr:h:{pid}:{kind}:{page + 1}"))
    return Screen("📜 История искр", lines, [tabs, nav, [Btn("◀️ Меню", cb=f"pr:m:{pid}", style="link")]])


async def costs_screen(svc: PairService, p: dict, now: int) -> Screen:
    kids = await svc.kids(p)
    base = eco.upkeep_base(p["level"])
    total = int(round(base * (1 + eco.KID_UPKEEP * kids)))
    final = eco.upkeep_amount(p["level"], kids, p["sparks"])
    lines = [f"💠 Уровень {p['level']}: {n(base)}"]
    if kids:
        lines.append(f"👶 Дети: {kids}: +{n(total - base)} · +{int(kids * eco.KID_UPKEEP * 100)}%")
    if final < total:
        lines.append(f"🧢 Потолок 3% кошелька: {n(final)}")
    lines.append(f"📉 Итого: <b>{n(final)}</b> в сутки")
    if p["state"] == "ok":
        lines.append(f"🕙 Спишется через {eco.fmt_duration(p['upkeep_at'] - now)}")
        days = p["sparks"] // final if final else 0
        lines.append(f"🧮 Кошелька хватит примерно на {days} сут.")
    lines.append("<i>Каждый ребёнок прибавляет 10%, больше 3% кошелька за сутки не берём (но не меньше 15). В ссоре содержание не списывается.</i>")
    return Screen("📉 Расходы пары", lines, [[Btn("📜 Все траты", cb=f"pr:h:{p['id']}:out:0")],
                                              [Btn("◀️ Меню", cb=f"pr:m:{p['id']}", style="link")]])


async def list_screen(svc: PairService, db: Database, p: dict | None, chat: int, now: int) -> Screen:
    rows, sleeping = await svc.list_chat(chat, now)
    lines = []
    for i, r in enumerate(rows[:20], 1):
        mark = " 💍" if r["stage"] == "marriage" else ""
        lines.append(f"{i}. {html.escape(await name(db, r['u1']))} + {html.escape(await name(db, r['u2']))}{mark} · "
                     f"{duration_since(r['created'], now)} · ур. {r['level']}")
    if not lines:
        lines.append("В этой беседе пока нет пар.")
    lines.append(f"Всего: {len(rows)}" + (f" · спящих: {sleeping}" if sleeping else ""))
    back = [[Btn("◀️ Меню", cb=f"pr:m:{p['id']}", style="link")]] if p else []
    return Screen("👥 Пары беседы", lines, back)


async def top_screen(svc: PairService, db: Database, p: dict | None, chat: int, by: str, now: int) -> Screen:
    rows = await svc.top(chat, by, now)
    lines = []
    for i, r in enumerate(rows, 1):
        who = f"{html.escape(await name(db, r['u1']))} + {html.escape(await name(db, r['u2']))}"
        val = {"тепло": f"ур. {r['level']} · ☀️ {n(r['warmth'])}", "искры": f"🔥 {n(r['sparks'])}",
               "длительность": duration_since(r["created"], now), "активность": f"🫂 {n(r.get('activity', 0))}"}[by]
        lines.append(f"{i}. {who} · {val}")
    if not lines:
        lines.append("Пока нет пар.")
    pid = p["id"] if p else 0
    tabs = [Btn(("• " if k == by else "") + label, cb=f"pr:t:{pid}:{k}")
            for label, k in (("☀️ Тепло", "тепло"), ("🔥 Искры", "искры"), ("🕙 Время", "длительность"), ("🫂 Активность", "активность"))]
    rows_ = [tabs[:2], tabs[2:]]
    if p:
        rows_.append([Btn("◀️ Меню", cb=f"pr:m:{pid}", style="link")])
    return Screen("🏆 Топ пар беседы", lines, rows_)


def bar(done: int, total: int, width: int = 8) -> str:
    k = round(width * min(done, total) / total) if total else width
    return "▰" * k + "▱" * (width - k)


async def quests_screen(svc: PairService, p: dict, now: int) -> Screen:
    pid = p["id"]
    rows = await svc.quests(p, now)
    lines = []
    for title, scope in (("Сегодня", "d"), ("На неделе", "w")):
        lines.append(f"<b>{title}</b>")
        for q in (r for r in rows if r["scope"] == scope):
            mark = "✅" if q["done"] else "▫️"
            lines.append(f"{mark} {qs.text(q['kind'], q['goal'])}\n    {bar(q['progress'], q['goal'])} {q['progress']}/{q['goal']}"
                         f" · +{n(q['reward'])} 🔥 · +{q['warmth']} ☀️")
    s = await svc.season(p, now)
    lines.append(f"🌟 Сезон: ступень {s['step']}/{s['max']} · очки {s['points']} (по {s['per']} на ступень)")
    btns = []
    if s["step"] > s["claimed"]:
        btns.append([Btn(f"🎁 Забрать награды сезона ({s['step'] - s['claimed']})", cb=f"pr:cl:{pid}", style="success")])
    btns.append([Btn("◀️ Меню", cb=f"pr:m:{pid}", style="link")])
    return Screen("📋 Задания пары", lines, btns)


def gifts_screen(p: dict, section: str) -> Screen:
    pid = p["id"]
    sec = section if section in gf.SECTIONS else gf.SECTIONS[0]
    items = [g for g in gf.GIFTS if g.section == sec]
    lines = ["Подарок покупается за твои монеты и ложится в витрину пары. Подарить: <code>пара подарить роза</code> или кнопкой.",
             "Тепло получают первые 3 подарка в сутки."]
    lines += [f"{g.emoji} {g.key} · {n(g.price)} 🪙 · +{gf.warmth(g.price)} ☀️" for g in items]
    tabs = [Btn(("• " if s == sec else "") + s, cb=f"pr:gs:{pid}:{i}") for i, s in enumerate(gf.SECTIONS)]
    rows = [tabs[i:i + 3] for i in range(0, len(tabs), 3)]
    gi = gf.SECTIONS.index(sec)
    buy = [Btn(f"{g.emoji} {g.key}", cb=f"pr:gb:{pid}:{gf.GIFTS.index(g)}") for g in items]
    rows += [buy[i:i + 2] for i in range(0, len(buy), 2)]
    rows.append([Btn("🏛 Витрина", cb=f"pr:sc:{pid}"), Btn("◀️ Меню", cb=f"pr:m:{pid}", style="link")])
    return Screen("🎁 Подарки · " + sec, lines, rows)


async def showcase_screen(svc: PairService, p: dict) -> Screen:
    pid = p["id"]
    items = await svc.showcase(pid)
    lines = []
    for sec in gf.SECTIONS:
        row = [f"{g.emoji} {g.key} ×{items[g.key]}" for g in gf.GIFTS if g.section == sec and g.key in items]
        if row:
            lines.append(f"<b>{sec}:</b> " + " · ".join(row))
    if not lines:
        lines.append("Витрина пуста. Подарите что-нибудь половинке!")
    lines.append(f"✨ Престиж витрины: <b>{n(gf.prestige(items))}</b>")
    return Screen("🏛 Витрина пары", lines, [[Btn("🎁 Подарки", cb=f"pr:gs:{pid}:0"), Btn("◀️ Меню", cb=f"pr:m:{pid}", style="link")]])


def help_text() -> str:
    return ("💞 <b>Пара</b>\nПара живёт в беседе и держится на искрах 🔥: их приносят действия, а раз в сутки часть уходит на "
            "содержание. Кончились искры — ссора, и на примирение сутки.\n☀️ Всё, что вы делаете вместе, даёт тепло, из тепла "
            "растёт уровень.\n\n<code>отношения @ник</code> · завести пару\n<code>пара</code> · меню пары\n"
            "<code>пара действия</code> · что можно сейчас\n<code>пара завтрак</code> · любое открытое действие\n"
            "<code>пара обнять</code> · РП пары (обнять, поцеловать, кусь, шлёп, погладить, щелбан)\n"
            "<code>пара подарки</code> · <code>пара подарить роза</code> · <code>пара витрина</code>\n<code>пара задания</code> · задания и сезон (<code>пара награда</code>)\n<code>пара история</code> · <code>пара расходы</code> · <code>пара список</code> · <code>пара топ</code>\n"
            "<code>пара пополнить 100</code> · монеты → искры\n<code>пара обида</code> · <code>пара помириться</code> · "
            "<code>пара расстаться</code>\n<code>брак @ник</code> · свадьба (с 3 уровня)")


# ---------- команды ----------
async def _my_pair(message: Message, svc: PairService, now: int):
    """(пара, события) или (None, []) с подсказкой, если пары нет."""
    p = await svc.get(message.chat.id, message.from_user.id)
    if p is None:
        await ux.tell(message, "💞 У вас нет пары в этой беседе. Завести: <code>отношения @ник</code> (или ответом на сообщение).")
        return None, []
    p, events = await svc.settle(p["id"], now)
    return p, events


async def _send_events(message: Message, db: Database, p: dict | None, events: list, pair_row: dict, skip: tuple = ()) -> None:
    for t in await event_lines(db, pair_row, events, skip):
        await message.answer(t)


@router.message(F.text.func(lambda t: parse(t) is not None))
async def pair_cmd(message: Message, bot, db: Database) -> None:
    if message.chat.type not in ("group", "supergroup") or message.from_user is None:
        return
    if not (await db.get_settings(message.chat.id))["rp_on"]:
        return
    sub, arg = parse(message.text)
    svc, fam, now = PairService(db), Family(db), int(time.time())
    chat, me = message.chat.id, message.from_user.id

    if sub == "help":
        await message.reply(help_text())
        return
    if sub == "request":                                           # «пара запрос @ник» = «отношения @ник»
        from bot.handlers.family import _propose
        target = await resolve_user(db, arg or None, real_reply(message))
        if target is None:
            await ux.tell(message, "⚠️ Ответьте командой на сообщение человека или укажите @ник.")
            return
        if target[0] == (await bot.me()).id:
            await message.reply("🤖 Я всего лишь бот, у меня нет пары.")
            return
        await _propose(message, bot, db, fam, "relation", target[0], now)
        return
    if sub in ("yes", "no"):
        from bot.handlers.family import _apply
        req = await fam.pending_to(chat, me, now)
        if req is None:
            await ux.tell(message, "ℹ️ Вам никто не предлагал: ответить можно на запрос «отношения @ник» или «брак @ник».")
            return
        if not await fam.delete_request(req["id"]):
            return
        text = await _apply(db, fam, req["kind"], chat, req["from_user"], req["to_user"], now) if sub == "yes" else "💔 Отказ."
        if req.get("message_id"):
            try:
                await bot.edit_message_text(text, chat_id=chat, message_id=req["message_id"])
                return
            except Exception:
                pass
        await message.answer(text)
        return
    if sub in ("list", "top") and await svc.get(chat, me) is None:   # списки доступны и без своей пары
        if sub == "list":
            await message.answer(**_msg(await list_screen(svc, db, None, chat, now)))
        else:
            by = TOP_KINDS.get(data.norm(arg), "тепло")
            await message.answer(**_msg(await top_screen(svc, db, None, chat, by, now)))
        return

    p, events = await _my_pair(message, svc, now)
    if p is None:
        for r in events:
            pass
        return
    partner = partner_of(p, me)
    if sub == "menu":
        await _send_menu(message, db, svc, p, partner, now)
    elif sub == "actions":
        await rich_ui.send(bot, chat, actions_screen(p, now, me), thread_id=_thread(message))
    elif sub in ("act", "rp"):
        res = await (svc.act(p["id"], me, arg, now) if sub == "act" else svc.rp(p["id"], me, arg, now))
        if not res.ok:
            await ux.tell(message, res.error or "⚠️ Не получилось.")
        else:
            await message.reply(await _result_text(db, p, me, partner, res, sub))
        for t in await event_lines(db, p, res.events, skip=("levelup",) if sub == "act" and res.ok else ()):
            await message.answer(t)
    elif sub in ("quests", "season"):
        await rich_ui.send(bot, chat, await quests_screen(svc, p, now), thread_id=_thread(message))
    elif sub == "gifts":
        sec = next((s for s in gf.SECTIONS if data.norm(s) == data.norm(arg)), gf.SECTIONS[0])
        await rich_ui.send(bot, chat, gifts_screen(p, sec), thread_id=_thread(message))
    elif sub == "showcase":
        await rich_ui.send(bot, chat, await showcase_screen(svc, p), thread_id=_thread(message))
    elif sub == "give":
        res = await svc.give(p["id"], me, arg, now)
        if not res.ok:
            await ux.tell(message, f"⚠️ {res.error}")
        else:
            g = res.info["gift"]
            extra = f" · +{res.info['warmth']} ☀️" if res.info["warmth"] else ""
            await message.reply(f"{g.emoji} {await m(db, me)} дарит {await m(db, partner)}: <b>{g.key}</b>{extra}")
        for t in await event_lines(db, p, res.events):
            await message.answer(t)
    elif sub == "claim":
        res = await svc.claim_season(p["id"], me, now)
        await (message.reply(f"🎁 Награда сезона: +{n(res.info['sparks'])} 🔥 (ступень {res.info['step']})") if res.ok
               else ux.tell(message, f"⚠️ {res.error}"))
    elif sub == "history":
        kind = {"приход": "in", "траты": "out", "доход": "in"}.get(data.norm(arg.split()[0]) if arg else "", "all")
        page = int(arg.split()[-1]) - 1 if arg and arg.split()[-1].isdigit() else 0
        await rich_ui.send(bot, chat, await history_screen(svc, db, p, kind, page, now), thread_id=_thread(message))
    elif sub == "costs":
        await rich_ui.send(bot, chat, await costs_screen(svc, p, now), thread_id=_thread(message))
    elif sub == "list":
        await rich_ui.send(bot, chat, await list_screen(svc, db, p, chat, now), thread_id=_thread(message))
    elif sub == "top":
        by = TOP_KINDS.get(data.norm(arg), "тепло")
        await rich_ui.send(bot, chat, await top_screen(svc, db, p, chat, by, now), thread_id=_thread(message))
    elif sub == "offense":
        res = await svc.toggle_offense(p["id"], me, now)
        if not res.ok:
            await ux.tell(message, f"⚠️ {res.error}")
        elif res.info["offended"]:
            await message.answer(f"😢 {await m(db, partner)}, твоя половинка в обиде. Действия и РП для тебя закрыты, пока "
                                 f"{await m(db, me)} не простит: <code>пара обида</code>.")
        else:
            await message.answer(f"😊 {await m(db, partner)}, твоя половинка больше не обижается. Всё снова доступно!")
    elif sub == "peace":
        await message.reply(_peace_hint(p, now))
    elif sub == "topup":
        if not arg.isdigit():
            await ux.tell(message, "⚠️ Сколько монет? Например: <code>пара пополнить 100</code>.")
            return
        res = await svc.topup(p["id"], me, int(arg), now)
        if not res.ok:
            await ux.tell(message, f"⚠️ {res.error}")
            return
        await message.reply(f"💰 В кошелёк пары добавлено <b>{n(res.info['sparks'])}</b> 🔥.")
        for t in await event_lines(db, p, res.events):
            await message.answer(t)
    elif sub == "end":
        await rich_ui.send(bot, chat, await _end_screen(db, p, partner), thread_id=_thread(message))


def _thread(message: Message) -> int | None:
    return message.message_thread_id if getattr(message, "is_topic_message", False) else None


def _msg(screen: Screen) -> dict:
    text, kb = rich_ui.to_classic(screen)
    return {"text": text, "reply_markup": kb}


def _peace_hint(p: dict, now: int) -> str:
    if p["state"] != "quarrel":
        return "🕊 Вы не в ссоре. Всё хорошо!"
    return (f"💢 Вы в ссоре: искры кончились, действия закрыты. Помирят любые искры — пополните кошелёк: "
            f"<code>пара пополнить 100</code>. Осталось {eco.fmt_duration(p['quarrel_until'] - now)}.")


async def _send_menu(message: Message, db: Database, svc: PairService, p: dict, partner: int, now: int) -> None:
    await rich_ui.send(message.bot, message.chat.id, await _menu(db, svc, p, message.from_user.id, now),
                       thread_id=_thread(message))


async def _menu(db: Database, svc: PairService, p: dict, user: int, now: int) -> Screen:
    partner = partner_of(p, user)
    kids = await svc.kids(p)
    notes = []
    if p["state"] == "quarrel":
        notes.append(f"💢 <b>Ссора</b>: помирят любые искры, осталось {eco.fmt_duration(p['quarrel_until'] - now)}")
    elif p["sparks"] < eco.upkeep_amount(p["level"], kids, p["sparks"]) * 2:
        notes.append("🚨 Искр мало: скоро не хватит на содержание")
    if p["offended_by"]:
        notes.append("😢 Обида: " + ("ты обижаешься на половинку" if p["offended_by"] == user else "половинка обижена на тебя"))
    side = side_of(p, user)
    wait = p[f"next{side}"] - now
    notes.append("✨ Действие доступно" if wait <= 0 else f"⏳ Действие через {eco.fmt_duration(wait)}")
    if is_sleeping(p, now):
        notes.append("💤 Пара спит: давно ничего не делали")
    return menu_screen(p, await m(db, partner), now, kids, notes)


async def _end_screen(db: Database, p: dict, partner: int) -> Screen:
    pid = p["id"]
    word = "Развестись" if p["stage"] == "marriage" else "Расстаться"
    return Screen(f"💔 {word} с {html.escape(await name(db, partner))}?", [
        f"Пропадёт всё, что есть у пары: {n(p['sparks'])} 🔥, уровень {p['level']}. Согласие половинки не нужно."],
        [[Btn(f"💔 Да, {word.lower()}", cb=f"pr:endy:{pid}", style="danger"), Btn("✖️ Отмена", cb=f"pr:m:{pid}")]])


async def _result_text(db: Database, p: dict, me: int, partner: int, res, sub: str) -> str:
    a, b = await m(db, me), await m(db, partner)
    i = res.info
    if sub == "rp":
        rp = i["rp"]
        extra = f"\n☀️ +{i['warmth']} тепла" if i["warmth"] else ""
        return f"{rp.emoji} {rp.text.format(a=a, b=b)}{extra}"
    act = i["action"]
    lines = [f"{act.emoji} {act.text.format(a=a, b=b)}",
             f"🔥 +{n(i['sparks'])} · ☀️ +{i['warmth']} тепла · снова через {eco.fmt_duration(i['cd'])}"]
    extras = []
    if i["tired"]:
        extras.append("😮‍💨 усталость: награда вдвое меньше")
    if i["unison"]:
        extras.append("в унисон +20%")
    if i["streak"] and not i["together"]:
        extras.append(f"серия {i['streak']} дн. +{int(eco.streak_bonus(i['streak']) * 100)}%")
    if extras:
        lines.append("🔗 " + " · ".join(extras))
    if i["together"]:
        lines.append(f"💞 День вместе засчитан: серия {i['streak']} дн., +{eco.DAY_TOGETHER_WARMTH} тепла")
    for ev in res.events:
        if ev[0] == "levelup":
            lines.append(f"💠 Новый уровень: <b>{data.level_name(ev[1]['level'])}</b> ({ev[1]['level']})! 🎁 +{n(ev[1]['gift'])} 🔥")
    return "\n".join(lines)


# ---------- кнопки ----------
@router.callback_query(F.data.startswith("pr:"))
async def pair_cb(cb: CallbackQuery, bot, db: Database) -> None:
    parts = cb.data.split(":")
    if len(parts) < 3 or not parts[2].isdigit() or cb.message is None:
        await cb.answer()
        return
    op, pid, args = parts[1], int(parts[2]), parts[3:]
    svc, now, user = PairService(db), int(time.time()), cb.from_user.id
    p0 = await svc.get_by_id(pid)
    if p0 is None or p0["ended_at"] is not None or p0["chat_id"] != cb.message.chat.id:
        await cb.answer("Эта пара уже не существует.", show_alert=True)
        return
    if user not in (p0["u1"], p0["u2"]):
        await cb.answer("Не твоя кнопка", show_alert=True)
        return
    p, events = await svc.settle(pid, now)
    if p is None:
        await cb.answer("💔 Пара распалась.", show_alert=True)
        for t in await event_lines(db, p0, events):
            await cb.message.answer(t)
        return
    partner = partner_of(p, user)
    popup = None
    if op == "m":
        screen = await _menu(db, svc, p, user, now)
    elif op == "more":
        screen = more_screen(p, user)
    elif op == "a":
        screen = actions_screen(p, now, user)
    elif op == "do":
        level = int(args[0]) if args and args[0].isdigit() else 0
        action = next((x for x in data.ACTIONS if x.level == level), None)
        res = await svc.act(pid, user, action.key, now) if action else None
        p = await svc.get_by_id(pid)
        if res is None or not res.ok:
            popup = res.error if res else "Нет такого действия."
            screen = actions_screen(p, now, user)
        else:
            text = await _result_text(db, p, user, partner, res, "act")
            popup = f"+{n(res.info['sparks'])} 🔥 · +{res.info['warmth']} ☀️"
            screen = actions_screen(p, now, user, text.split("\n"))
    elif op == "h":
        kind = args[0] if args else "all"
        page = int(args[1]) if len(args) > 1 and args[1].lstrip("-").isdigit() else 0
        screen = await history_screen(svc, db, p, kind if kind in ("all", "in", "out") else "all", page, now)
    elif op == "q":
        screen = await quests_screen(svc, p, now)
    elif op == "cl":
        res = await svc.claim_season(pid, user, now)
        popup = f"🎁 +{n(res.info['sparks'])} 🔥" if res.ok else res.error
        p = await svc.get_by_id(pid)
        screen = await quests_screen(svc, p, now)
    elif op == "gs":
        i = int(args[0]) if args and args[0].isdigit() else 0
        screen = gifts_screen(p, gf.SECTIONS[i] if i < len(gf.SECTIONS) else gf.SECTIONS[0])
    elif op == "gb":
        i = int(args[0]) if args and args[0].isdigit() else -1
        g = gf.GIFTS[i] if 0 <= i < len(gf.GIFTS) else None
        res = await svc.give(pid, user, g.key, now) if g else None
        p = await svc.get_by_id(pid)
        if res is None or not res.ok:
            popup = res.error if res else "Нет такого подарка."
        else:
            popup = f"{g.emoji} Подарено: {g.key}"
            await cb.message.answer(f"{g.emoji} {await m(db, user)} дарит {await m(db, partner)}: <b>{g.key}</b>"
                                    + (f" · +{res.info['warmth']} ☀️" if res.info["warmth"] else ""))
            events = events + res.events
        screen = gifts_screen(p, g.section if g else gf.SECTIONS[0])
    elif op == "sc":
        screen = await showcase_screen(svc, p)
    elif op == "e":
        screen = await costs_screen(svc, p, now)
    elif op == "l":
        screen = await list_screen(svc, db, p, p["chat_id"], now)
    elif op == "t":
        screen = await top_screen(svc, db, p, p["chat_id"], TOP_KINDS.get(args[0] if args else "", "тепло"), now)
    elif op == "ob":
        res = await svc.toggle_offense(pid, user, now)
        popup = ("😢 Ты обиделась(ся): действия половинки закрыты" if res.ok and res.info["offended"] else
                 "😊 Обида снята" if res.ok else res.error)
        p = await svc.get_by_id(pid)
        screen = more_screen(p, user)
    elif op == "peace":
        popup = _peace_hint(p, now).replace("<code>", "").replace("</code>", "")
        screen = more_screen(p, user)
    elif op == "end":
        screen = await _end_screen(db, p, partner)
    elif op == "endy":
        ended = await svc.end(pid, "breakup", now, user)
        await cb.answer("💔 Отношения завершены")
        if ended:
            try:
                await cb.message.edit_text(f"💔 {await m(db, user)} и {await m(db, partner)} больше не пара. "
                                           f"Вы были вместе {duration_since(p['created'], now)}.")
            except Exception:
                pass
        return
    else:
        await cb.answer()
        return
    await cb.answer(popup[:190] if popup else None, show_alert=bool(popup and len(popup) > 60))
    await rich_ui.show(cb, screen)
    for t in await event_lines(db, p, events):
        await cb.message.answer(t)


# ---------- фон: содержание, ссора, распад ----------
async def pair_watchdog(bot, db: Database) -> None:
    """Раз в 5 минут досчитывает пары, у которых что-то подошло к сроку, и объявляет ссору, распад и предупреждения."""
    svc = PairService(db)
    while True:
        await asyncio.sleep(300)
        try:
            now = int(time.time())
            for p in await svc.due(now):
                p2, events = await svc.settle(p["id"], now)
                for ev in events:
                    if ev[0] in ("quarrel", "dissolved", "warn"):
                        t = await event_text(db, p, ev)
                        if t:
                            try:
                                await bot.send_message(p["chat_id"], t)
                            except Exception:
                                logging.info("pair: не отправилось в чат %s", p["chat_id"])
        except Exception:
            logging.exception("pair watchdog")

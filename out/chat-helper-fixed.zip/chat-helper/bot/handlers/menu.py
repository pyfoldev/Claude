from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, Message

from bot.emoji import emoji
from bot.fmt import quote
from bot.keyboards import main_menu, section_keyboard

router = Router(name="menu")

TITLE = lambda: f"{emoji('menu')} <b>Меню Chat Helper</b>\n<i>Выберите раздел</i>"  # noqa: E731


def c(*cmds: str) -> str:
    """Команды в <code> через « · » — нажатие копирует команду."""
    return " · ".join(f"<code>{x}</code>" for x in cmds)


def block(title: str, *lines: str) -> str:
    """Заголовок и цитата со строками; длинные блоки сворачиваются."""
    return f"<b>{title}</b>\n" + quote("\n".join(lines), expandable=len(lines) > 6)


SECTIONS = {
    "mod": lambda: (
        f"{emoji('shield')} <b>Модерация</b>\n"
        + c("бан", "разбан", "кик", "мут 30м", "размут", "варн", "снять варн", "варны", "история @ник") + "\n"
        + c("удалить", "закреп", "открепить", "чистка 20", "жалоба") + "\n"
        "<i>Ответом на сообщение или с @ником.</i>"
    ),
    "stats": lambda: (
        f"{emoji('stats')} <b>Статистика</b>\n"
        + c("стата", "стата 2 часа", "стата неделя", "стата месяц", "стата вся")
    ),
    "games": lambda: (
        f"{emoji('game')} <b>Игры и фан</b>\n"
        + c("баланс", "бонус", "топ", "слоты 50", "ферма", "передать 100 @ник", "рулетка", "кубы 50 @ник", "дуэль") + "\n"
        + c("огород", "посадить морковь", "полить", "собрать") + "\n"
        + c("кто лох", "инфа текст", "выбери чай или кофе", "данет вопрос", "монетка", "шипперим", "гб @ник") + "\n"
        + c("ии, вопрос")
    ),
    "rp": lambda: (
        "🎭 <b>РП и семья</b>\n"
        + c("обнять", "дать пять", "рп") + " — РП\n"
        + c("брак @ник", "развод", "браки", "отношения @ник", "усыновить", "моя семья")
    ),
    "ranks": lambda: (
        "🎖 <b>Ранги и профиль</b>\n"
        + c("+модер 2 @ник", "снять @ник", "кто админ", "дк") + "\n"
        + c("+фильтр слово", "фильтры", "+ссылка домен", "ссылки", "правила", "приветствие") + "\n"
        + c("кто неактив", "кик неактив 30д", "олды", "новички", "кто онлайн", "общий сбор") + "\n"
        + c("кто я", "моя анкета", "+ник", "+девиз", "репутация", "награды", "таймер через 2 часа текст")
    ),
    "protect": lambda: (
        f"{emoji('shield')} <b>Защита</b>\n"
        "Включается в <code>настройки</code>:\n"
        "антиспам · антирейд · фильтр 18+ · стоп-слова · капча · ИИ-модерация · расшифровка голосовых"
    ),
    "settings": lambda: f"{emoji('settings')} <b>Настройки</b>\n<code>настройки</code> или <code>веб-панель</code>",
    "help": lambda: (
        "❓ <b>Помощь</b>\n"
        "Дайте боту права админа: удаление, ограничение участников, приглашения, закрепление.\n"
        "<code>меню</code> · <code>веб-панель</code> · <code>диагностика</code> (владельцу)"
    ),
}


@router.message(CommandStart())
@router.message(Command("menu", "help"))
@router.message(F.text.lower().in_({"меню", "команды", "помощь"}))
async def show_menu(message: Message) -> None:
    await message.answer(TITLE(), reply_markup=main_menu())


@router.callback_query(F.data.startswith("menu:"))
async def menu_cb(cb: CallbackQuery, bot, db) -> None:
    key = cb.data.split(":", 1)[1]
    if key == "settings":
        from bot.handlers.settings import open_settings
        await open_settings(cb, bot, db)
        return
    if key == "home":
        await cb.message.edit_text(TITLE(), reply_markup=main_menu())
    elif key in SECTIONS:
        await cb.message.edit_text(SECTIONS[key](), reply_markup=section_keyboard())
    await cb.answer()

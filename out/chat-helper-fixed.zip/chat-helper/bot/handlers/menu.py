"""Главное меню и разделы — rich-экраны: заголовок, таблица «команда — описание» и кнопки-таблетки по центру внутри
сообщения (bot/rich_ui.py). Если Telegram не принимает rich — те же экраны обычным сообщением с inline-кнопками."""
from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, Message

from bot import rich_ui
from bot.rich_ui import Btn, Screen

router = Router(name="menu")

BACK = [Btn("⬅️ Меню", cb="menu:home", style="link")]

MAIN_ROWS = [
    [Btn("🛡 Модерация", cb="menu:mod"), Btn("📊 Статистика", cb="menu:stats")],
    [Btn("🎮 Игры и фан", cb="menu:games"), Btn("🚫 Защита", cb="menu:protect")],
    [Btn("🎭 РП и семья", cb="menu:rp"), Btn("⚙️ Настройки", cb="menu:settings")],
    [Btn("🎖 Ранги и профиль", cb="menu:ranks"), Btn("❓ Помощь", cb="menu:help")],
]


def main_screen() -> Screen:
    return Screen("📋 Меню Chat Helper", ["<i>Выберите раздел</i>"], MAIN_ROWS)


# раздел -> (заголовок, [(команда, описание)], подсказка | None)
SECTION_DATA = {
    "mod": ("🛡 Модерация", [
        ("бан", "забанить (бан 1д, бан навсегда)"), ("разбан", "снять бан"), ("кик", "исключить с возвратом"),
        ("мут 30м", "заглушить на срок"), ("размут", "снять мут"), ("варн", "предупреждение, 3 — автомут"),
        ("снять варн", "убрать предупреждение"), ("варны", "сколько предупреждений"),
        ("история @ник", "все наказания участника"), ("репутация @ник", "репутация и досье"),
        ("удалить", "удалить сообщение (ответом)"), ("закреп", "закрепить (ответом)"), ("открепить", "открепить"),
        ("чистка 20", "удалить последние сообщения"), ("жалоба", "пожаловаться (ответом)"),
        ("опрос Вопрос | да | нет", "создать опрос"),
    ], "Ответом на сообщение или с @ником."),
    "stats": ("📊 Статистика", [
        ("стата", "за сутки"), ("стата 2 часа", "за N часов (1–168)"), ("стата неделя", "за неделю"),
        ("стата месяц", "за месяц"), ("стата вся", "за всё время"), ("стата темы", "по темам форума"),
    ], None),
    "games": ("🎮 Игры и фан", [
        ("баланс", "ваши монеты"), ("бонус", "ежедневный бонус"), ("топ", "богатейшие"), ("слоты 50", "автоматы"),
        ("ферма", "раз в 4 часа"), ("передать 100 @ник", "перевести монеты"), ("рулетка", "русская рулетка"),
        ("кубы 50 @ник", "кости на ставку"), ("дуэль", "вызов (ответом)"), ("огород", "ваш огород"),
        ("кто лох", "случайный участник"), ("данет вопрос", "шар предсказаний"), ("ии, вопрос", "спросить нейросеть"),
        ("запомни я люблю чай", "бот запомнит о вас"), ("что ты помнишь", "что бот помнит"),
    ], None),
    "rp": ("🎭 РП и семья", [
        ("обнять", "РП-действие (рп — весь список)"), ("брак @ник", "предложить брак"), ("развод", "развестись"),
        ("браки", "пары чата"), ("отношения @ник", "завести отношения"), ("усыновить", "взять ребёнка"),
        ("моя семья", "семья и дети"),
    ], None),
    "ranks": ("🎖 Ранги и профиль", [
        ("+модер 2 @ник", "выдать ранг"), ("снять @ник", "снять ранг"), ("кто админ", "список модераторов"),
        ("дк", "доступ команд"), ("+фильтр слово", "стоп-слово"), ("фильтры", "список фильтров"),
        ("+ссылка домен", "разрешить домен"), ("правила", "правила чата"), ("приветствие", "приветствие"),
        ("кто неактив", "неактивные участники"), ("кик неактив 30д", "кик неактивных"), ("общий сбор", "позвать всех"),
        ("кто я", "ваша анкета"), ("+ник", "ваш ник в чате"), ("репутация", "ваша репутация"),
        ("таймер через 2 часа текст", "напоминание"),
    ], None),
    "protect": ("🚫 Защита", [
        ("антиспам", "флуд, повторы, ссылки, пересылки"), ("антирейд", "массовый вход"),
        ("фильтр 18+", "картинки, стикеры, видео"), ("фишинг", "поддельные ссылки"), ("стоп-слова", "слова и выражения"),
        ("капча", "проверка новичков"), ("ИИ-модерация", "по желанию"), ("расшифровка", "голосовых"),
    ], "Включается в «настройки»."),
    "help": ("❓ Помощь", [
        ("меню", "это меню"), ("настройки", "настройки чата"), ("веб-панель", "панель управления"),
        ("диагностика", "проверка бота (владельцу)"),
    ], "Дайте боту права админа: удаление, ограничение участников, приглашения, закрепление."),
}


def section_screen(key: str, webapp_url: str = "") -> Screen:
    title, rows, hint = SECTION_DATA[key]
    body = ([f"<i>{hint}</i>"] if hint else []) + [("table", rows)]
    btns = [BACK]
    if key == "help" and webapp_url:
        btns.insert(0, [Btn("🌐 Веб-панель", web_app=f"{webapp_url}/panel")])
    return Screen(title, body, btns)


def onboarding_screen(bot_username: str, webapp_url: str = "") -> Screen:
    rows = [[Btn("➕ Добавить в чат", style="success",
                 url=f"https://t.me/{bot_username}?startgroup=true&admin=delete_messages+restrict_members+invite_users+pin_messages+manage_chat")]]
    if webapp_url:
        rows.append([Btn("🌐 Веб-панель", web_app=f"{webapp_url}/panel")])
    rows.append([Btn("📖 Меню команд", cb="menu:home")])
    return Screen("👋 Привет! Я Chat Helper — помощник для чатов", [
        "<i>Модерация, защита от спама, статистика, игры и ИИ.</i>",
        "<b>Как начать</b>",
        "1️⃣ Добавьте меня в чат — кнопка ниже сама выдаст нужные права.",
        "2️⃣ В чате появится мастер первой настройки: включите капчу, антиспам и приветствие.",
        "3️⃣ Все команды — <code>меню</code>, настройки — <code>настройки</code>.",
    ], rows, footer="Подсказки по командам в любом чате: напишите @имя_бота и слово — например, «бан».")


@router.message(CommandStart(deep_link=False), F.chat.type == "private")
async def onboarding(message: Message, bot, webapp_url: str = "") -> None:
    """/start в личке без параметров: короткое знакомство и три кнопки."""
    await rich_ui.send(bot, message.chat.id, onboarding_screen((await bot.me()).username, webapp_url))


@router.message(CommandStart())
@router.message(Command("menu", "help"))
@router.message(F.text.lower().in_({"меню", "команды", "помощь"}))
async def show_menu(message: Message, bot) -> None:
    await rich_ui.send(bot, message.chat.id, main_screen(),
                       thread_id=message.message_thread_id if message.is_topic_message else None)


@router.callback_query(F.data.startswith("menu:"))
async def menu_cb(cb: CallbackQuery, bot, db, webapp_url: str = "") -> None:
    key = cb.data.split(":", 1)[1]
    if key == "settings":
        from bot.handlers.settings import open_settings
        await open_settings(cb, bot, db, webapp_url)
        return
    if key == "home":
        await rich_ui.show(cb, main_screen())
    elif key in SECTION_DATA:
        await rich_ui.show(cb, section_screen(key, webapp_url if cb.message.chat.type == "private" else ""))
    await cb.answer()

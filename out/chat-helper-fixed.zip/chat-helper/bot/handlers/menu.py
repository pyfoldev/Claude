from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, Message

from bot.emoji import emoji
from bot.fmt import quote
from bot.keyboards import main_menu, section_keyboard

router = Router(name="menu")

TITLE = lambda: f"{emoji('menu')} <b>Меню Chat Helper</b>\n<i>Выберите раздел</i>"  # noqa: E731


def c(*cmds: str) -> str:
    """Команды в <code> через « · » — нажатие копирует команду."""
    return " · ".join(f"<code>{x}</code>" for x in cmds)


def block(title: str, *lines: str) -> str:
    """Заголовок и цитата со строками; длинные блоки сворачиваются."""
    return f"<b>{title}</b>\n" + quote("\n".join(lines), expandable=len(lines) > 6)


SECTIONS = {
    "mod": lambda: (
        f"{emoji('shield')} <b>Модерация</b>\n"
        + c("бан", "разбан", "кик", "мут 30м", "размут", "варн", "снять варн", "варны", "история @ник") + "\n"
        + c("удалить", "закреп", "открепить", "чистка 20", "жалоба", "опрос Вопрос | да | нет", "репутация @ник") + "\n"
        "<i>Ответом на сообщение или с @ником.</i>"
    ),
    "stats": lambda: (
        f"{emoji('stats')} <b>Статистика</b>\n"
        + c("стата", "стата 2 часа", "стата неделя", "стата месяц", "стата вся")
    ),
    "games": lambda: (
        f"{emoji('game')} <b>Игры и фан</b>\n"
        + c("баланс", "бонус", "топ", "слоты 50", "ферма", "передать 100 @ник", "рулетка", "кубы 50 @ник", "дуэль") + "\n"
        + c("огород", "посадить морковь", "полить", "собрать") + "\n"
        + c("кто лох", "инфа текст", "выбери чай или кофе", "данет вопрос", "монетка", "шипперим", "гб @ник") + "\n"
        + c("ии, вопрос", "запомни я люблю чай", "что ты помнишь", "забудь всё")
    ),
    "rp": lambda: (
        "🎭 <b>РП и семья</b>\n"
        + c("обнять", "дать пять", "рп") + " — РП\n"
        + c("брак @ник", "развод", "браки", "отношения @ник", "усыновить", "моя семья")
    ),
    "ranks": lambda: (
        "🎖 <b>Ранги и профиль</b>\n"
        + c("+модер 2 @ник", "снять @ник", "кто админ", "дк") + "\n"
        + c("+фильтр слово", "фильтры", "+ссылка домен", "ссылки", "правила", "приветствие") + "\n"
        + c("кто неактив", "кик неактив 30д", "олды", "новички", "кто онлайн", "общий сбор") + "\n"
        + c("кто я", "моя анкета", "+ник", "+девиз", "репутация", "награды", "таймер через 2 часа текст")
    ),
    "protect": lambda: (
        f"{emoji('shield')} <b>Защита</b>\n"
        "Включается в <code>настройки</code>:\n"
        "антиспам · антирейд · фильтр 18+ · стоп-слова · капча · ИИ-модерация · расшифровка голосовых"
    ),
    "settings": lambda: f"{emoji('settings')} <b>Настройки</b>\n<code>настройки</code> или <code>веб-панель</code>",
    "help": lambda: (
        "❓ <b>Помощь</b>\n"
        "Дайте боту права админа: удаление, ограничение участников, приглашения, закрепление.\n"
        "<code>меню</code> · <code>веб-панель</code> · <code>диагностика</code> (владельцу)"
    ),
}


ONBOARDING = (
    "👋 <b>Привет! Я Chat Helper — помощник для чатов.</b>\n"
    "<i>Модерация, защита от спама, статистика, игры и ИИ.</i>\n\n"
    "<b>Как начать</b>\n"
    "1️⃣ Добавьте меня в чат — кнопка ниже сама выдаст нужные права.\n"
    "2️⃣ В чате появится мастер первой настройки: включите капчу, антиспам и приветствие.\n"
    "3️⃣ Все команды — <code>меню</code>, настройки — <code>настройки</code>.\n\n"
    "<i>Подсказки по командам в любом чате: напишите @имя_бота и слово — например, «бан».</i>")


@router.message(CommandStart(deep_link=False), F.chat.type == "private")
async def onboarding(message: Message, bot, webapp_url: str = "") -> None:
    """/start в личке без параметров: короткое знакомство и три кнопки."""
    from aiogram.types import InlineKeyboardButton as B, InlineKeyboardMarkup, WebAppInfo
    me = await bot.me()
    rows = [[B(text="➕ Добавить в чат", style="success",
               url=f"https://t.me/{me.username}?startgroup=true&admin=delete_messages+restrict_members+invite_users+pin_messages+manage_chat")]]
    if webapp_url:
        rows.append([B(text="🌐 Веб-панель", web_app=WebAppInfo(url=f"{webapp_url}/panel"))])
    rows.append([B(text="📖 Меню команд", callback_data="menu:home")])
    await message.answer(ONBOARDING, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.message(CommandStart())
@router.message(Command("menu", "help"))
@router.message(F.text.lower().in_({"меню", "команды", "помощь"}))
async def show_menu(message: Message) -> None:
    await message.answer(TITLE(), reply_markup=main_menu())


@router.callback_query(F.data.startswith("menu:"))
async def menu_cb(cb: CallbackQuery, bot, db, webapp_url: str = "") -> None:
    key = cb.data.split(":", 1)[1]
    if key == "settings":
        from bot.handlers.settings import open_settings
        await open_settings(cb, bot, db, webapp_url)
        return
    if key == "home":
        await cb.message.edit_text(TITLE(), reply_markup=main_menu())
    elif key in SECTIONS:
        await cb.message.edit_text(SECTIONS[key](), reply_markup=section_keyboard())
    await cb.answer()

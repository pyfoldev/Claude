"""Гифки к бану, муту, варну, разбану и размуту: файл грузится один раз, дальше отправляем по file_id."""
from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path

from aiogram.types import FSInputFile

ASSETS = Path(__file__).with_name("assets") / "punish"
FILES = {"бан": "ban.mp4", "разбан": "unban.mp4", "мут": "mute.mp4", "размут": "unmute.mp4", "варн": "warn.mp4"}
MIN_GAP = 20                     # не чаще раза в 20 секунд на чат и вид (рейд, массовые баны — без потока гифок)
_ids: dict[str, str] = {}
_last: dict[tuple[int, str], float] = {}
_bg: set = set()


async def send(bot, chat_id: int, action: str, thread_id: int | None = None, delay: float = 0.6) -> None:
    name = FILES.get(action)
    if name is None:
        return
    now = time.time()
    if now - _last.get((chat_id, action), 0) < MIN_GAP:
        return
    _last[(chat_id, action)] = now
    await asyncio.sleep(delay)                       # сначала приходит текст, потом гифка
    path = ASSETS / name
    try:
        src = _ids.get(name) or FSInputFile(path)
        msg = await bot.send_animation(chat_id, src, message_thread_id=thread_id)
        if name not in _ids and getattr(msg, "animation", None):
            _ids[name] = msg.animation.file_id
    except Exception as e:
        _ids.pop(name, None)                         # id мог устареть — в следующий раз загрузим файл заново
        logging.info("гифка %s не отправилась: %s", action, e)


def spawn(bot, chat_id: int, action: str, thread_id: int | None = None) -> None:
    """В фоне: ответ на команду не ждёт загрузку гифки."""
    if action not in FILES:
        return
    try:
        t = asyncio.get_running_loop().create_task(send(bot, chat_id, action, thread_id))
    except RuntimeError:
        return
    _bg.add(t)
    t.add_done_callback(_bg.discard)

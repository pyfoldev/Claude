"""Пакет бота. Файл .env читается СРАЗУ при импорте: часть модулей (rich_ui, ux, …) читает переключатели вроде RICH_UI или
EPHEMERAL при загрузке, а load_config() вызывается позже. В Docker (env_file) переменные и так уже в окружении."""
import os


def _load_dotenv(path: str = ".env") -> None:
    if not os.path.exists(path):
        return
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                v = v.strip()
                if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
                    v = v[1:-1]
                os.environ.setdefault(k.strip(), v)
    except OSError:
        pass


_load_dotenv()

from bot import perf  # noqa: F401, E402 — ускорение фильтров aiogram (см. bot/perf.py), действует при любом импорте бота

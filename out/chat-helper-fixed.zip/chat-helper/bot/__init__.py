from bot import perf  # noqa: F401 — ускорение фильтров aiogram (см. bot/perf.py), действует при любом импорте бота

"""Веб-часть капчи: проверка initData Mini App, картинка с кодом и приём ответа."""
from __future__ import annotations

import hashlib
import hmac
import io
import json
import random
import secrets
import time
from pathlib import Path
from urllib.parse import parse_qsl

from aiohttp import web
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from bot.db import Database

WEBAPP_DIR = Path(__file__).resolve().parent.parent / "webapp"
ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"  # без 0/O, 1/I/L — их путают
CODE_LEN = 5
MAX_ATTEMPTS = 5
# сложность: (длина кода, макс. попыток). 0 — обычная, 1 — повышенная (волна неудач в чате), 2 — усиленная (рейд)
LEVELS = {0: (5, 5), 1: (6, 4), 2: (6, 3)}


# как у веб-панели: только свои скрипты и скрипт Telegram, картинка капчи приходит как blob:
CAPTCHA_CSP = ("default-src 'self'; script-src 'self' https://telegram.org; style-src 'self'; img-src 'self' blob: data:; "
               "connect-src 'self'; base-uri 'none'; form-action 'none'; "
               "frame-ancestors https://web.telegram.org https://webk.telegram.org https://webz.telegram.org")
PAGE_HEADERS = {"Content-Security-Policy": CAPTCHA_CSP, "X-Content-Type-Options": "nosniff",
                "Referrer-Policy": "no-referrer", "Cache-Control": "no-store"}


def level_params(level: int) -> tuple[int, int]:
    return LEVELS.get(level, LEVELS[0])


def validate_init_data(init_data: str, bot_token: str, max_age: int = 300,
                       now: int | None = None) -> dict | None:
    """Проверка подписи Telegram WebApp initData. None — если подпись/свежесть неверны."""
    if not init_data:
        return None
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True, strict_parsing=True))
    except ValueError:
        return None
    got = pairs.pop("hash", None)
    if not got:
        return None
    dcs = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, got):
        return None
    try:
        auth_date = int(pairs["auth_date"])
        user = json.loads(pairs["user"])
    except (KeyError, ValueError):
        return None
    if (now if now is not None else int(time.time())) - auth_date > max_age:
        return None
    pairs["user"] = user
    return pairs


def new_code(length: int = CODE_LEN) -> str:
    """Случайный код для новой капчи. Не выводится из токена: токен лежит в ссылке-кнопке в чате,
    и бот-спамер иначе мог бы вычислить ответ без распознавания картинки."""
    return "".join(secrets.choice(ALPHABET) for _ in range(length))


def make_code(seed: str) -> str:
    """Код капчи; для одного seed (токена) всегда один и тот же."""
    rng = random.Random("code:" + seed)
    return "".join(rng.choice(ALPHABET) for _ in range(CODE_LEN))


def _wave(img: Image.Image, rng: random.Random, amp: float) -> Image.Image:
    """Волнообразный сдвиг столбцов по вертикали: ломает распознавание «буква за буквой»."""
    import math
    w, h = img.size
    phase, period = rng.uniform(0, 6.28), rng.uniform(28, 46)
    out = Image.new("RGB", (w, h), (12, 12, 12))
    for x in range(w):
        dy = int(amp * math.sin(x / period * 6.28 + phase))
        out.paste(img.crop((x, 0, x + 1, h)), (x, dy))
    return out


def render_image(code: str, seed: str, level: int = 0) -> bytes:
    """PNG с искажённым кодом: у каждой буквы свой поворот и сдвиг, плюс помехи. Чем выше level, тем сильнее искажение."""
    rng = random.Random("img:" + seed)
    w, h = 260, 100
    img = Image.new("RGB", (w, h), (12, 12, 12))
    d = ImageDraw.Draw(img)
    for _ in range(900 + 350 * level):  # шум
        x, y = rng.randrange(w), rng.randrange(h)
        g = rng.randrange(40, 120)
        d.point((x, y), fill=(g, g, g))
    font = ImageFont.load_default(size=54)
    step = w // (len(code) + 1)
    for i, ch in enumerate(code):
        tile = Image.new("RGBA", (80, 80), (0, 0, 0, 0))
        shade = rng.randrange(200, 256)
        ImageDraw.Draw(tile).text((40, 40), ch, font=font, anchor="mm", fill=(shade, shade, shade, 255))
        spin = 28 + 5 * level
        tile = tile.rotate(rng.uniform(-spin, spin), resample=Image.BICUBIC)
        img.paste(tile, (step * (i + 1) - 40 + rng.randint(-5, 5), 10 + rng.randint(-8, 8)), tile)
    d = ImageDraw.Draw(img)
    for _ in range(5 + 2 * level):  # линии поверх букв
        g = rng.randrange(90, 190)
        d.line([(rng.randrange(w), rng.randrange(h)), (rng.randrange(w), rng.randrange(h))],
               fill=(g, g, g), width=rng.randint(1, 2))
    if level >= 2:
        img = _wave(img, rng, 2.5)
    img = img.filter(ImageFilter.GaussianBlur(0.6))
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue()


def build_app(db: Database, bot_token: str, on_pass) -> web.Application:
    app = web.Application()

    async def page(request: web.Request) -> web.StreamResponse:
        resp = web.FileResponse(WEBAPP_DIR / "index.html")
        resp.headers.update(PAGE_HEADERS)
        return resp

    async def load(token: str, init_data: str) -> tuple[dict | None, int]:
        """Возвращает (captcha, http-статус). Проверяет подпись, владельца и срок."""
        data = validate_init_data(init_data, bot_token)
        if data is None:
            return None, 403
        cap = await db.get_captcha(token)
        if cap is None or cap["expires_at"] <= time.time():
            return None, 404
        if data["user"].get("id") != cap["user_id"]:
            return None, 403
        return cap, 200

    async def image(request: web.Request) -> web.Response:
        token = request.query.get("token", "")
        cap, status = await load(token, request.headers.get("X-Init-Data", ""))
        if cap is None:
            return web.json_response({"error": "forbidden"}, status=status)
        level = int(cap.get("level") or 0)
        return web.Response(body=render_image(cap["answer"], token, level), content_type="image/png",
                            headers={"Cache-Control": "no-store", "X-Code-Length": str(len(cap["answer"]))})

    async def verify(request: web.Request) -> web.Response:
        try:
            body = await request.json()
            token, answer, init_data = str(body["token"]), body["answer"], str(body["initData"])
            if not isinstance(answer, str):
                raise TypeError
        except (KeyError, ValueError, TypeError):
            return web.json_response({"ok": False})
        cap, _ = await load(token, init_data)
        if cap is None:
            return web.json_response({"ok": False})
        # попытку занимаем ДО сравнения и в БД: ни перезапуск бота, ни пачка параллельных запросов не дают лишних попыток
        if not await db.take_captcha_attempt(token, level_params(int(cap.get("level") or 0))[1]):
            return web.json_response({"ok": False, "error": "attempts"})
        if not hmac.compare_digest(answer.strip().upper().encode(), str(cap["answer"]).encode()):
            return web.json_response({"ok": False})
        if not await db.consume_captcha(token):  # одноразовость
            return web.json_response({"ok": False})
        await on_pass(cap["chat_id"], cap["user_id"], cap["message_id"], kind=cap.get("kind") or "member")
        return web.json_response({"ok": True})

    app.router.add_get("/captcha", page)
    app.router.add_get("/captcha/image", image)
    app.router.add_post("/captcha/verify", verify)
    app.router.add_static("/webapp/", WEBAPP_DIR)
    return app

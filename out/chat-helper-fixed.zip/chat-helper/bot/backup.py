"""Автобэкап БД: копия через sqlite backup API, проверка целостности, ротация, оповещение при ошибке."""
import asyncio
import logging
import os
import sqlite3
import time
from typing import Awaitable, Callable

PREFIX = "bot-backup-"


class BackupError(Exception):
    pass


def _check_pg_dump(path: str) -> None:
    import subprocess
    try:
        r = subprocess.run(["pg_restore", "--list", path], capture_output=True, timeout=60)
    except (OSError, subprocess.SubprocessError) as e:
        raise BackupError(f"не удалось проверить дамп: {e}") from e
    if r.returncode != 0:
        raise BackupError("дамп PostgreSQL не читается: " + r.stderr.decode(errors="replace")[:150])


def _check_integrity(path: str) -> None:
    try:
        conn = sqlite3.connect(path)
        try:
            res = conn.execute("PRAGMA integrity_check").fetchone()
        finally:
            conn.close()
    except sqlite3.Error as e:
        raise BackupError(f"копия не открывается: {e}") from e
    if not res or res[0] != "ok":
        raise BackupError(f"проверка целостности: {res[0] if res else 'нет ответа'}")


async def make_backup(db, directory: str, now: int | None = None) -> str:
    os.makedirs(directory, exist_ok=True)
    ts = time.strftime("%Y%m%d-%H%M%S", time.gmtime(now if now is not None else time.time()))
    pg = getattr(db, "backend", "sqlite") == "pg"
    path = os.path.join(directory, f"{PREFIX}{ts}.{'dump' if pg else 'db'}")
    try:
        await db.backup_to(path)
        await asyncio.to_thread(_check_pg_dump if pg else _check_integrity, path)
    except Exception:
        if os.path.exists(path):
            os.remove(path)
        raise
    return path


def rotate(directory: str, keep: int) -> int:
    files = sorted(f for f in os.listdir(directory) if f.startswith(PREFIX) and f.endswith((".db", ".dump")))
    old = files[:-keep] if keep > 0 else files
    for f in old:
        os.remove(os.path.join(directory, f))
    return len(old)


async def backup_once(db, directory: str, keep: int, notify: Callable[[str], Awaitable[None]],
                      now: int | None = None) -> bool:
    try:
        await make_backup(db, directory, now=now)
        rotate(directory, keep)
        return True
    except Exception as e:
        logging.exception("backup failed")
        try:
            await notify(f"⚠️ Автоматический бэкап базы не удался: {type(e).__name__}: {e}")
        except Exception:
            logging.exception("backup notify failed")
        return False


async def backup_loop(db, directory: str, keep: int, notify: Callable[[str], Awaitable[None]],
                      interval: int = 86400, first_delay: int = 300) -> None:
    await asyncio.sleep(first_delay)
    while True:
        await backup_once(db, directory, keep, notify)
        await asyncio.sleep(interval)

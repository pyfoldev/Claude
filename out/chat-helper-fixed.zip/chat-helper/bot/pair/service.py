"""Сервис пары: хранение и правила (искры, содержание, ссора и распад, действия, РП, серия). Без Telegram: возвращает данные
и «события» (ссора, распад, предупреждение, новый уровень), а сообщения в чат собирает обработчик.

Время считается лениво: при каждом обращении к паре settle() досчитывает содержание за прошедшие сутки; фоновый обход
(handlers/pair.py) нужен только чтобы вовремя объявить ссору и распад. Операции над одной парой идут под её замком."""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field

from bot.db import Database
from bot.pair import data, economy as eco, gifts as gf, quests as qs

_LOCKS: dict[int, asyncio.Lock] = {}


def _lock(pid: int) -> asyncio.Lock:
    if len(_LOCKS) > 20000:
        _LOCKS.clear()
    return _LOCKS.setdefault(pid, asyncio.Lock())


@dataclass
class Result:
    ok: bool
    error: str | None = None
    info: dict = field(default_factory=dict)
    events: list = field(default_factory=list)


def partner_of(p: dict, user: int) -> int:
    return p["u2"] if p["u1"] == user else p["u1"]


def side_of(p: dict, user: int) -> int:
    return 1 if p["u1"] == user else 2


def is_sleeping(p: dict, now: int) -> bool:
    return now - (p.get("last_active") or p["created"]) > eco.SLEEP_AFTER


def effective_streak(p: dict, now: int) -> int:
    """Серия, которая действует сейчас: если вчера день не засчитан и сегодня тоже — серия сгорела."""
    return p["streak"] if p["streak_day"] >= eco.day_index(now) - 1 else 0


class PairService:
    def __init__(self, db: Database):
        self.db = db

    # ---------- чтение ----------
    async def _one(self, sql: str, args: tuple = ()) -> dict | None:
        cur = await self.db.conn.execute(sql, args)
        r = await cur.fetchone()
        return dict(r) if r else None

    async def _all(self, sql: str, args: tuple = ()) -> list[dict]:
        cur = await self.db.conn.execute(sql, args)
        return [dict(r) for r in await cur.fetchall()]

    async def get(self, chat: int, user: int) -> dict | None:
        return await self._one("SELECT * FROM pairs WHERE chat_id=? AND (u1=? OR u2=?) AND ended_at IS NULL",
                               (chat, user, user))

    async def get_by_id(self, pid: int) -> dict | None:
        return await self._one("SELECT * FROM pairs WHERE id=?", (pid,))

    async def kids(self, p: dict) -> int:
        r = await self._one("SELECT COUNT(DISTINCT child) AS n FROM parents WHERE chat_id=? AND (parent=? OR parent=?)",
                            (p["chat_id"], p["u1"], p["u2"]))
        return int(r["n"]) if r else 0

    async def counters(self, pid: int) -> dict[str, int]:
        return {r["kind"]: r["n"] for r in await self._all("SELECT kind, n FROM pair_counters WHERE pair_id=?", (pid,))}

    # ---------- запись ----------
    async def _save(self, pid: int, fields: dict) -> None:
        sets = ",".join(f"{k}=?" for k in fields)
        await self.db.conn.execute(f"UPDATE pairs SET {sets} WHERE id=?", (*fields.values(), pid))

    async def _log(self, pid: int, ts: int, kind: str, amount: int, balance: int, warmth: int, actor: int | None,
                   detail: str = "") -> None:
        await self.db.conn.execute(
            "INSERT INTO pair_log(pair_id,ts,kind,amount,balance,warmth,actor,detail) VALUES(?,?,?,?,?,?,?,?)",
            (pid, ts, kind, amount, balance, warmth, actor, detail))

    async def create(self, chat: int, a: int, b: int, now: int, stage: str = "relation", *, sparks: int = eco.START_SPARKS,
                     warmth: int = 0, created: int | None = None, legacy_key: str | None = None) -> dict:
        u1, u2 = (a, b) if a < b else (b, a)
        level = eco.level_for(warmth)
        cur = await self.db.conn.execute(
            "INSERT INTO pairs(chat_id,u1,u2,stage,created,sparks,warmth,level,upkeep_at,last_active,legacy_key) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (chat, u1, u2, stage, created or now, sparks, warmth, level, now + eco.DAY, now, legacy_key))
        pid = cur.lastrowid
        await self._log(pid, now, "create", sparks, sparks, warmth, a, "новая пара")
        await self.db.conn.commit()
        return await self.get_by_id(pid)

    async def set_stage(self, pid: int, stage: str) -> None:
        await self._save(pid, {"stage": stage})
        await self.db.conn.commit()

    async def end(self, pid: int, reason: str, now: int, actor: int | None = None) -> dict | None:
        """Закрыть пару (расставание, развод, ссора без примирения). Запись остаётся в архиве."""
        async with _lock(pid):
            p = await self.get_by_id(pid)
            if p is None or p["ended_at"] is not None:
                return None
            await self._save(pid, {"ended_at": now, "ended_reason": reason})
            await self._log(pid, now, "end", 0, p["sparks"], 0, actor, reason)
            await self.db.conn.commit()
            return {**p, "ended_at": now, "ended_reason": reason}

    # ---------- время: содержание, ссора, распад ----------
    async def settle(self, pid: int, now: int) -> tuple[dict | None, list]:
        """Досчитать содержание и ссору до now. Возвращает (пара | None если распалась, события)."""
        async with _lock(pid):
            p = await self.get_by_id(pid)
            if p is None or p["ended_at"] is not None:
                return None, []
            events: list = []
            upd: dict = {}
            kids = await self.kids(p)
            guard = 0
            while p["state"] == "ok" and p["upkeep_at"] and now >= p["upkeep_at"] and guard < 90:
                guard += 1
                amt = eco.upkeep_amount(p["level"], kids, p["sparks"])
                if p["sparks"] <= amt:                       # кошелёк пуст — ссора
                    paid, at = p["sparks"], p["upkeep_at"]
                    p.update(sparks=0, state="quarrel", quarrel_until=at + eco.QUARREL_HOURS * 3600)
                    if paid:
                        await self._log(pid, at, "upkeep", -paid, 0, 0, None, "содержание")
                    await self._log(pid, at, "quarrel", 0, 0, 0, None, "искры кончились")
                    events.append(("quarrel", {"until": p["quarrel_until"]}))
                    break
                p["sparks"] -= amt
                await self._log(pid, p["upkeep_at"], "upkeep", -amt, p["sparks"], 0, None, "содержание")
                p["upkeep_at"] += eco.DAY
            if p["state"] == "quarrel" and now >= p["quarrel_until"]:
                await self._save(pid, {"sparks": 0, "state": "quarrel", "upkeep_at": p["upkeep_at"], "ended_at": now,
                                       "ended_reason": "sparks"})
                await self._log(pid, now, "end", 0, 0, 0, None, "не помирились")
                await self.db.conn.commit()
                events.append(("dissolved", {"since": p["created"]}))
                return None, events
            if p["state"] == "ok":                           # предупреждение за сутки до нехватки
                nxt = eco.upkeep_amount(p["level"], kids, p["sparks"])
                if p["sparks"] <= nxt and p["warned_day"] != eco.day_index(now) and p["upkeep_at"] - now <= eco.DAY:
                    p["warned_day"] = eco.day_index(now)
                    events.append(("warn", {"sparks": p["sparks"], "need": nxt}))
            await self._save(pid, {k: p[k] for k in ("sparks", "state", "quarrel_until", "upkeep_at", "warned_day")})
            await self.db.conn.commit()
            return p, events

    # ---------- искры ----------
    async def credit(self, pid: int, amount: int, kind: str, actor: int | None, now: int, detail: str = "") -> list:
        """Начислить искры. Любые искры помирят пару, если она в ссоре."""
        async with _lock(pid):
            p = await self.get_by_id(pid)
            if p is None or p["ended_at"] is not None or amount <= 0:
                return []
            events: list = []
            p["sparks"] += amount
            fields = {"sparks": p["sparks"], "last_active": now}
            if p["state"] == "quarrel":
                fields.update(state="ok", quarrel_until=0, upkeep_at=now + eco.DAY)
                events.append(("peace", {}))
            await self._save(pid, fields)
            await self._log(pid, now, kind, amount, p["sparks"], 0, actor, detail)
            await self.db.conn.commit()
            return events

    async def topup(self, pid: int, user: int, coins: int, now: int) -> Result:
        """Пополнить кошелёк пары своими монетами (1 монета = 1 искра, не больше TOPUP_DAILY за сутки на пару)."""
        p = await self.get_by_id(pid)
        if p is None or p["ended_at"] is not None:
            return Result(False, "Пары уже нет.")
        if coins < 1:
            return Result(False, "Сумма — от 1 монеты.")
        day = eco.day_index(now)
        used = p["topup_sum"] if p["topup_day"] == day else 0
        if used + coins > TOPUP_DAILY:
            left = max(TOPUP_DAILY - used, 0)
            return Result(False, f"Пополнить можно не больше {TOPUP_DAILY} искр в сутки (осталось {left}).")
        if not await self.db.try_spend(p["chat_id"], user, coins):
            return Result(False, "Не хватает монет.")
        await self._save(pid, {"topup_day": day, "topup_sum": used + coins})
        events = await self.credit(pid, coins, "topup", user, now, "пополнение монетами")
        return Result(True, info={"sparks": coins}, events=events)

    # ---------- действия ----------
    async def act(self, pid: int, user: int, key: str, now: int) -> Result:
        action = data.find_action(key)
        if action is None:
            return Result(False, "Нет такого действия.")
        p, events = await self.settle(pid, now)
        if p is None:
            return Result(False, "Пары уже нет.", events=events)
        async with _lock(pid):
            p = await self.get_by_id(pid)
            err = self._blocked(p, user)
            if err:
                return Result(False, err, events=events)
            side = side_of(p, user)
            nxt = p[f"next{side}"]
            if now < nxt:
                return Result(False, f"⏳ Рано: следующее действие через {eco.fmt_duration(nxt - now)}.", events=events)
            if action.level > p["level"]:
                return Result(False, f"🔒 «{action.key}» откроется на {action.level} уровне (сейчас {p['level']}).", events=events)
            day = eco.day_index(now)
            if p["day"] != day:
                p.update(day=day, mask=0, n1=0, n2=0, rp1=0, rp2=0)
            n = p[f"n{side}"]
            other_ts = p[f"act{3 - side}"]
            unison = bool(other_ts) and now - other_ts <= eco.UNISON_WINDOW
            streak = effective_streak(p, now)
            tired = n >= eco.DAILY_ACTIONS_BEFORE_TIRED
            sparks, warmth = eco.action_reward(action.sparks, action.cd, streak=streak, unison=unison, tired=tired)
            p[f"n{side}"] = n + 1
            p[f"act{side}"] = now
            p[f"next{side}"] = now + action.cd * 60
            p["mask"] |= side
            p["sparks"] += sparks
            together = False
            if p["mask"] == 3 and p["streak_day"] != day:        # оба сегодня делали действия — день вместе
                p["streak"] = p["streak"] + 1 if p["streak_day"] == day - 1 else 1
                p["streak_day"] = day
                warmth += eco.DAY_TOGETHER_WARMTH
                together = True
            events += await self._quest_progress(p, "act", 1, now)
            if together:
                events += await self._quest_progress(p, "together", 1, now)
            events += await self._grow(p, warmth, now)
            levelup = [e for e in events if e[0] == "levelup"]
            await self._save(pid, {k: p[k] for k in (
                "sparks", "warmth", "level", "streak", "streak_day", "day", "mask", "n1", "n2", "rp1", "rp2", "act1", "act2",
                "next1", "next2")} | {"last_active": now})
            await self._log(pid, now, "action", sparks, p["sparks"], warmth, user, action.key)
            await self.db.conn.commit()
            return Result(True, info={"action": action, "sparks": sparks, "warmth": warmth, "unison": unison, "tired": tired,
                                       "streak": p["streak"] if together else streak, "together": together,
                                       "cd": action.cd * 60, "level": p["level"], "levelup": bool(levelup)},
                          events=events)

    async def _grow(self, p: dict, warmth: int, now: int) -> list:
        """Прибавить тепло, пересчитать уровень; за каждый новый уровень — подарок искрами."""
        events: list = []
        p["warmth"] += warmth
        new = eco.level_for(p["warmth"])
        while p["level"] < new:
            p["level"] += 1
            gift = eco.level_gift(p["level"])
            p["sparks"] += gift
            events.append(("levelup", {"level": p["level"], "gift": gift}))
        return events

    # ---------- подарки ----------
    async def showcase(self, pid: int) -> dict[str, int]:
        return {r["gift"]: r["n"] for r in await self._all("SELECT gift, n FROM pair_gifts WHERE pair_id=? AND n>0", (pid,))}

    async def give(self, pid: int, user: int, word: str, now: int) -> Result:
        """Подарить половинке подарок за свои монеты: он ложится в витрину, пара получает тепло (первые 3 в сутки)."""
        gift = gf.find(word)
        if gift is None:
            return Result(False, "Нет такого подарка: список — «пара подарки».")
        p, events = await self.settle(pid, now)
        if p is None:
            return Result(False, "Пары уже нет.", events=events)
        async with _lock(pid):
            p = await self.get_by_id(pid)
            err = self._blocked(p, user)
            if err:
                return Result(False, err, events=events)
            if not await self.db.try_spend(p["chat_id"], user, gift.price):
                return Result(False, f"Не хватает монет: подарок стоит {gift.price}.", events=events)
            day = eco.day_index(now)
            given = p["gift_n"] if p["gift_day"] == day else 0
            warmth = gf.warmth(gift.price) if given < gf.GIFT_WARMTH_CAP_DAY else 0
            events += await self._grow(p, warmth, now)
            await self.db.conn.execute(
                "INSERT INTO pair_gifts(pair_id,gift,n) VALUES(?,?,1) ON CONFLICT(pair_id,gift) DO UPDATE SET n=pair_gifts.n+1",
                (pid, gift.key))
            await self._save(pid, {"warmth": p["warmth"], "level": p["level"], "sparks": p["sparks"], "gift_day": day,
                                   "gift_n": given + 1, "last_active": now})
            await self._log(pid, now, "gift", 0, p["sparks"], warmth, user, f"подарок: {gift.key}")
            await self.db.conn.commit()
            return Result(True, info={"gift": gift, "warmth": warmth}, events=events)

    # ---------- задания и сезон ----------
    async def quests(self, p: dict, now: int) -> list[dict]:
        """Задания на сегодня и неделю (создаются при первом обращении)."""
        pid, out = p["id"], []
        for scope, count in (("d", 2), ("w", 1)):
            per = qs.period(scope, now)
            rows = await self._all("SELECT * FROM pair_quests WHERE pair_id=? AND scope=? AND period=? ORDER BY slot",
                                   (pid, scope, per))
            if not rows:
                kinds = qs.DAILY_POOL if scope == "d" else [qs.WEEKLY]
                for slot in range(count):
                    kind = kinds[(per + slot) % len(kinds)] if scope == "d" else kinds[0]
                    goal = qs.goal_for(kind, scope, p["level"])
                    sp, wm = qs.reward_for(kind, scope, p["level"])
                    await self.db.conn.execute(
                        "INSERT INTO pair_quests(pair_id,scope,period,slot,kind,goal,progress,reward,warmth,done) "
                        "VALUES(?,?,?,?,?,?,0,?,?,0)", (pid, scope, per, slot, kind, goal, sp, wm))
                await self.db.conn.commit()
                rows = await self._all("SELECT * FROM pair_quests WHERE pair_id=? AND scope=? AND period=? ORDER BY slot",
                                       (pid, scope, per))
            out += rows
        return out

    async def season(self, p: dict, now: int) -> dict:
        key = f"season:{qs.month_key(now)}"
        pts = (await self.counters(p["id"])).get(key, 0)
        step = qs.season_step(pts)
        claimed = (await self.counters(p["id"])).get(f"claimed:{qs.month_key(now)}", 0)
        return {"points": pts, "step": step, "claimed": claimed, "max": qs.SEASON_STEPS, "per": qs.STEP_POINTS}

    async def _bump(self, pid: int, kind: str, n: int) -> None:
        await self.db.conn.execute(
            "INSERT INTO pair_counters(pair_id,kind,n) VALUES(?,?,?) ON CONFLICT(pair_id,kind) DO UPDATE SET n=pair_counters.n+?",
            (pid, kind, n, n))

    async def _quest_progress(self, p: dict, kind: str, n: int, now: int) -> list:
        """Засчитать прогресс заданий (под замком пары, без commit). Награда приходит сразу на кошелёк в p."""
        events: list = []
        await self.quests(p, now)
        for scope in ("d", "w"):
            per = qs.period(scope, now)
            rows = await self._all("SELECT * FROM pair_quests WHERE pair_id=? AND scope=? AND period=? AND kind=? AND done=0",
                                   (p["id"], scope, per, kind))
            for q in rows:
                prog = min(q["progress"] + n, q["goal"])
                done = prog >= q["goal"]
                await self.db.conn.execute(
                    "UPDATE pair_quests SET progress=?, done=? WHERE pair_id=? AND scope=? AND period=? AND slot=?",
                    (prog, 1 if done else 0, p["id"], scope, per, q["slot"]))
                if done:
                    p["sparks"] += q["reward"]
                    events += await self._grow(p, q["warmth"], now)
                    await self._log(p["id"], now, "quest", q["reward"], p["sparks"], q["warmth"], None, qs.text(q["kind"], q["goal"]))
                    await self._bump(p["id"], f"season:{qs.month_key(now)}", qs.POINTS[scope])
                    events.append(("quest", {"text": qs.text(q["kind"], q["goal"]), "sparks": q["reward"], "warmth": q["warmth"],
                                             "scope": scope}))
        return events

    async def claim_season(self, pid: int, user: int, now: int) -> Result:
        async with _lock(pid):
            p = await self.get_by_id(pid)
            err = self._blocked(p, user)
            if err:
                return Result(False, err)
            s = await self.season(p, now)
            if s["claimed"] >= s["step"]:
                return Result(False, "Награды сезона пока все забраны: делайте задания.")
            total = 0
            for step in range(s["claimed"] + 1, s["step"] + 1):
                total += qs.season_reward(step, p["level"])
            await self._bump(pid, f"claimed:{qs.month_key(now)}", s["step"] - s["claimed"])
            await self.db.conn.commit()
        events = await self.credit(pid, total, "season", user, now, f"сезон: ступень {s['step']}")
        return Result(True, info={"sparks": total, "step": s["step"]}, events=events)

    def _blocked(self, p: dict | None, user: int) -> str | None:
        if p is None or p["ended_at"] is not None:
            return "Пары уже нет."
        if user not in (p["u1"], p["u2"]):
            return "Это не ваша пара."
        if p["state"] == "quarrel":
            return "💢 Вы в ссоре: искры кончились, действия закрыты. Помирят любые искры — «пара пополнить 100»."
        if p["offended_by"] and p["offended_by"] != user:
            return "😢 Твоя половинка обижена: действия и РП закрыты, пока она не простит («пара обида»)."
        return None

    async def rp(self, pid: int, user: int, word: str, now: int) -> Result:
        item = data.find_rp(word)
        if item is None:
            return Result(False, "Нет такого действия.")
        p, events = await self.settle(pid, now)
        if p is None:
            return Result(False, "Пары уже нет.", events=events)
        async with _lock(pid):
            p = await self.get_by_id(pid)
            err = self._blocked(p, user)
            if err:
                return Result(False, err, events=events)
            side = side_of(p, user)
            day = eco.day_index(now)
            if p["day"] != day:
                p.update(day=day, mask=0, n1=0, n2=0, rp1=0, rp2=0)
            counted = p[f"rp{side}"] < eco.RP_WARMTH_PER_DAY
            warmth = eco.RP_WARMTH if counted else 0
            if counted:
                p[f"rp{side}"] += 1
            events += await self._quest_progress(p, "rp", 1, now)
            events += await self._grow(p, warmth, now)
            await self._save(pid, {k: p[k] for k in ("sparks", "warmth", "level", "day", "mask", "n1", "n2", "rp1", "rp2")}
                             | {"last_active": now})
            await self.db.conn.execute(
                "INSERT INTO pair_counters(pair_id,kind,n) VALUES(?,?,1) ON CONFLICT(pair_id,kind) DO UPDATE SET n=pair_counters.n+1",
                (pid, item.counter))
            await self.db.conn.commit()
            return Result(True, info={"rp": item, "warmth": warmth}, events=events)

    async def toggle_offense(self, pid: int, user: int, now: int) -> Result:
        async with _lock(pid):
            p = await self.get_by_id(pid)
            if p is None or p["ended_at"] is not None or user not in (p["u1"], p["u2"]):
                return Result(False, "Пары уже нет.")
            offended = p["offended_by"] != user and not p["offended_by"]
            if p["offended_by"] and p["offended_by"] != user:
                return Result(False, "Обиделась ваша половинка, а не вы: простить может только она.")
            new = user if offended else 0
            await self._save(pid, {"offended_by": new, "last_active": now})
            await self.db.conn.commit()
            return Result(True, info={"offended": bool(new)})

    # ---------- списки ----------
    async def history(self, pid: int, page: int, per: int = 10, kind: str = "all", now: int | None = None):
        now = int(time.time()) if now is None else now
        since = now - 30 * eco.DAY
        cond = {"all": "", "in": " AND amount>0", "out": " AND amount<0"}[kind]
        total = (await self._one(f"SELECT COUNT(*) AS n FROM pair_log WHERE pair_id=? AND ts>=? AND amount<>0{cond}",
                                 (pid, since)))["n"]
        rows = await self._all(
            f"SELECT * FROM pair_log WHERE pair_id=? AND ts>=? AND amount<>0{cond} ORDER BY ts DESC, id DESC LIMIT ? OFFSET ?",
            (pid, since, per, max(page, 0) * per))
        return rows, total

    async def list_chat(self, chat: int, now: int) -> tuple[list[dict], int]:
        rows = await self._all("SELECT * FROM pairs WHERE chat_id=? AND ended_at IS NULL ORDER BY created ASC, id", (chat,))
        awake = [r for r in rows if not is_sleeping(r, now)]
        return awake, len(rows) - len(awake)

    async def top(self, chat: int, by: str, now: int, limit: int = 10) -> list[dict]:
        rows, _ = await self.list_chat(chat, now)
        if by == "искры":
            rows.sort(key=lambda r: -r["sparks"])
        elif by == "длительность":
            rows.sort(key=lambda r: r["created"])
        elif by == "активность":
            totals = {r["pair_id"]: r["n"] for r in await self._all(
                "SELECT pair_id, SUM(n) AS n FROM pair_counters GROUP BY pair_id")}
            rows.sort(key=lambda r: -totals.get(r["id"], 0))
            for r in rows:
                r["activity"] = totals.get(r["id"], 0)
        else:
            rows.sort(key=lambda r: (-r["level"], -r["warmth"]))
        return rows[:limit]

    async def due(self, now: int, limit: int = 500) -> list[dict]:
        """Пары, которым пора что-то досчитать: содержание, конец ссоры, предупреждение для бедных кошельков."""
        return await self._all(
            "SELECT * FROM pairs WHERE ended_at IS NULL AND ((state='ok' AND (upkeep_at<=? OR sparks<?)) OR "
            "(state='quarrel' AND quarrel_until<=?)) LIMIT ?", (now, WARN_SPARKS, now, limit))

    # ---------- перенос старых браков и отношений ----------
    async def migrate_legacy(self, now: int | None = None) -> dict[str, int]:
        """Одноразово (идемпотентно): старые браки и отношения становятся парами. Тепло — по сроку вместе."""
        now = int(time.time()) if now is None else now
        done = {"marriage": 0, "relation": 0, "skipped": 0}
        for table, stage, sparks, per_day, cap in (("marriages", "marriage", 500, 20, 3000), ("relations", "relation", 200, 15, 2000)):
            try:
                rows = await self._all(f"SELECT * FROM {table}")
            except Exception:
                continue
            for r in rows:
                key = f"{stage[0]}:{r['chat_id']}:{r['u1']}:{r['u2']}"
                if await self._one("SELECT 1 AS x FROM pairs WHERE legacy_key=?", (key,)):
                    continue
                if await self.get(r["chat_id"], r["u1"]) or await self.get(r["chat_id"], r["u2"]):
                    done["skipped"] += 1
                    continue
                days = max((now - (r["since"] or now)) // eco.DAY, 0)
                await self.create(r["chat_id"], r["u1"], r["u2"], now, stage, sparks=sparks,
                                  warmth=min(days * per_day, cap), created=r["since"], legacy_key=key)
                done[stage] += 1
        return done


TOPUP_DAILY = 2000        # искр в сутки на пару можно докупить монетами
WARN_SPARKS = 400         # бедные кошельки проверяем чаще, чтобы вовремя предупредить

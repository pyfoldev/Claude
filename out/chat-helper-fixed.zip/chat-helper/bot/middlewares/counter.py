import time

from aiogram import BaseMiddleware
from aiogram.types import Message

from bot.db import Database


class CounterMiddleware(BaseMiddleware):
    """Считает каждое сообщение в группе (текст не сохраняется) и запоминает @username."""

    def __init__(self, db: Database):
        self.db = db

    async def __call__(self, handler, event: Message, data):
        u = event.from_user
        if event.chat.type in ("group", "supergroup") and u and not u.is_bot:
            await self.db.record_message(event.chat.id, u.id, int(time.time()))
        return await handler(event, data)

"""Экраны в стиле rich-сообщений Telegram: заголовок, текст, таблица команд и кнопки-«таблетки» по центру внутри самого
сообщения (с премиум-эмодзи в кнопках), а не отдельной клавиатурой под ним.

Один экран (Screen) умеет показываться двумя способами:
  • rich — настоящее rich-сообщение (Bot API 10.1+): блоки heading / paragraph / table / buttons;
  • classic — обычное сообщение с HTML-текстом и inline-клавиатурой (если Telegram или клиент rich не принял).
Выбор автоматический: сначала пробуем rich, при отказе помним об этом 10 минут и отвечаем обычным сообщением.

Экран, показанный как rich, править на месте нельзя (Bot API не даёт), поэтому при нажатии кнопки `show` отправляет новый
экран и удаляет старый — для пользователя это выглядит как переход."""
from __future__ import annotations

import html
import logging
import re
import time
from dataclasses import dataclass, field
from html.parser import HTMLParser

from aiogram.types import (InlineKeyboardButton, InlineKeyboardMarkup, InputRichBlockButtons, InputRichBlockDivider,
                           InputRichBlockFooter, InputRichBlockParagraph, InputRichBlockSectionHeading,
                           InputRichBlockTable, InputRichMessage, ReplyParameters, RichBlockTableCell,
                           RichMessageButton, RichTextBold, RichTextCode, RichTextCustomEmoji, RichTextItalic,
                           RichTextUnderline, RichTextUrl, WebAppInfo)

from bot import emoji_inject

_off_until = 0.0                         # rich недоступен — до этого момента не пробуем (секунды, time.time)
OFF_FOR = 600
MAX_ROW = 8                              # в одном блоке buttons — до 8 кнопок
_emap: dict | None = None


def _map() -> dict:
    global _emap
    if _emap is None:
        _emap = emoji_inject.load_map()
    return _emap


@dataclass
class Btn:
    """Кнопка экрана. Ровно одно из cb / url / web_app. style: primary | success | danger | link."""
    text: str
    cb: str | None = None
    url: str | None = None
    web_app: str | None = None
    style: str | None = None


@dataclass
class Screen:
    """title — заголовок; body — элементы: строка (абзац, мини-HTML: <b> <i> <code> <a>), ("table", [строки]) где строка —
    (команда, описание) или текст, ("rows", header, rows) — таблица из колонок, "---" — разделитель;
    rows — ряды кнопок; footer — мелкая подпись внизу; classic — готовый HTML для обычного сообщения (если нужен
    свой вид вместо автоматического)."""
    title: str | None = None
    body: list = field(default_factory=list)
    rows: list[list[Btn]] = field(default_factory=list)
    footer: str | None = None
    classic: str | None = None


# ---------- мини-HTML → rich text ----------
class _P(HTMLParser):
    def __init__(self, convert_emoji: bool):
        super().__init__(convert_charrefs=True)
        self.root: list = []
        self.stack: list[tuple[str, list, dict]] = []
        self.cur = self.root
        self.convert_emoji = convert_emoji
        self._skip_emoji_text = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("b", "strong", "i", "em", "code", "u", "a", "tg-emoji"):
            self.stack.append((tag, self.cur, dict(attrs)))
            self.cur = []

    def handle_endtag(self, tag):
        if tag == "strong":
            tag = "b"
        if tag == "em":
            tag = "i"
        if not self.stack or self.stack[-1][0] != tag:
            return
        t, parent, attrs = self.stack.pop()
        inner = _simplify(self.cur)
        self.cur = parent
        if t == "b":
            node = RichTextBold(text=inner)
        elif t == "i":
            node = RichTextItalic(text=inner)
        elif t == "code":
            node = RichTextCode(text=inner)
        elif t == "u":
            node = RichTextUnderline(text=inner)
        elif t == "a":
            href = attrs.get("href") or ""
            node = RichTextUrl(text=inner, url=href) if href else inner
        else:                                   # tg-emoji: <tg-emoji emoji-id="..">🛡</tg-emoji>
            cid = attrs.get("emoji-id")
            alt = inner if isinstance(inner, str) else "•"
            node = RichTextCustomEmoji(custom_emoji_id=cid, alternative_text=alt) if cid else inner
        self.cur.append(node)

    def handle_data(self, data):
        if not data:
            return
        inside_code = any(s[0] == "code" for s in self.stack)
        if self.convert_emoji and not inside_code and not any(s[0] == "tg-emoji" for s in self.stack):
            self.cur.extend(_split_emoji(data))
        else:
            self.cur.append(data)


def _split_emoji(text: str) -> list:
    """Известные эмодзи → премиум-эмодзи (как в обычных сообщениях через emoji_inject), остальное — текст."""
    emap = _map()
    if not emap:
        return [text]
    out, buf, i, budget = [], [], 0, 12
    while i < len(text):
        hit = emoji_inject._emoji_at(text, i, emap) if budget > 0 else None
        if hit:
            frag, cid, n = hit
            if buf:
                out.append("".join(buf))
                buf = []
            out.append(RichTextCustomEmoji(custom_emoji_id=cid, alternative_text=frag))
            budget -= 1
            i += n
        else:
            buf.append(text[i])
            i += 1
    if buf:
        out.append("".join(buf))
    return out


def _simplify(parts: list):
    parts = [p for p in parts if p != ""]
    if not parts:
        return ""
    return parts[0] if len(parts) == 1 else parts


def rich_text(html_text: str, convert_emoji: bool = True):
    """'<b>Привет</b> 🛡 мир' → RichText (строка, узлы или список узлов)."""
    p = _P(convert_emoji)
    p.feed(html_text or "")
    p.close()
    while p.stack:                              # незакрытые теги закрываем, чтобы не потерять текст
        p.handle_endtag(p.stack[-1][0])
    return _simplify(p.root)


# ---------- кнопки ----------
def _btn_text(text: str):
    """Ведущий эмодзи кнопки → премиум-эмодзи (как иконка слева на скриншотах)."""
    text = html.unescape(text)
    emap = _map()
    hit = emoji_inject._emoji_at(text, 0, emap) if emap and text else None
    if hit:
        frag, cid, n = hit
        rest = text[n:].lstrip()
        return [RichTextCustomEmoji(custom_emoji_id=cid, alternative_text=frag), " " + rest] if rest else \
            RichTextCustomEmoji(custom_emoji_id=cid, alternative_text=frag)
    return text


def _rich_button(b: Btn) -> RichMessageButton:
    kw = {"text": _btn_text(b.text), "style": b.style}
    if b.url:
        kw["url"] = b.url
    elif b.web_app:
        kw["web_app"] = WebAppInfo(url=b.web_app)
    else:
        kw["callback_data"] = b.cb or "noop"
    return RichMessageButton(**kw)


def _classic_button(b: Btn) -> InlineKeyboardButton:
    kw = {"text": b.text, "style": b.style if b.style in ("primary", "success", "danger") else None}
    if b.url:
        kw["url"] = b.url
    elif b.web_app:
        kw["web_app"] = WebAppInfo(url=b.web_app)
    else:
        kw["callback_data"] = b.cb or "noop"
    return InlineKeyboardButton(**kw)


# ---------- рендеры ----------
def _cell(text, header: bool = False):
    return RichBlockTableCell(align="left", valign="middle", text=text, is_header=True if header else None)


def to_rich(s: Screen) -> InputRichMessage:
    blocks: list = []
    if s.title:
        blocks.append(InputRichBlockSectionHeading(text=rich_text(s.title), size=3))
    for item in s.body:
        if item == "---":
            blocks.append(InputRichBlockDivider())
        elif isinstance(item, str):
            blocks.append(InputRichBlockParagraph(text=rich_text(item)))
        elif item[0] == "table":                 # строки «команда — описание»: одна колонка, команда кодом, описание курсивом
            cells = []
            for row in item[1]:
                if isinstance(row, (tuple, list)):
                    cmd, desc = row
                    cells.append([_cell([RichTextCode(text=cmd), " — ", RichTextItalic(text=rich_text(desc))])])
                else:
                    cells.append([_cell(rich_text(row))])
            blocks.append(InputRichBlockTable(cells=cells, is_bordered=True, is_compact=True))
        elif item[0] == "rows":                  # настоящая таблица из колонок
            _, header, rows = item
            cells = [[_cell(RichTextBold(text=h), True) for h in header]] + [[_cell(rich_text(str(c))) for c in r] for r in rows]
            blocks.append(InputRichBlockTable(cells=cells, is_bordered=True, is_striped=True))
    for row in s.rows:
        for i in range(0, len(row), MAX_ROW):
            blocks.append(InputRichBlockButtons(buttons=[_rich_button(b) for b in row[i:i + MAX_ROW]], align="center"))
    if s.footer:
        blocks.append(InputRichBlockFooter(text=rich_text(s.footer)))
    return InputRichMessage(blocks=blocks)


def to_classic(s: Screen) -> tuple[str, InlineKeyboardMarkup | None]:
    """Тот же экран обычным сообщением: HTML-текст + inline-клавиатура."""
    if s.classic is not None:
        kb = InlineKeyboardMarkup(inline_keyboard=[[_classic_button(b) for b in row] for row in s.rows]) if s.rows else None
        return s.classic, kb
    lines: list[str] = []
    if s.title:
        lines.append(f"<b>{s.title}</b>")
    for item in s.body:
        if item == "---":
            lines.append("")
        elif isinstance(item, str):
            lines.append(item)
        elif item[0] == "table":
            for row in item[1]:
                lines.append(f"<code>{html.escape(row[0])}</code> — <i>{row[1]}</i>" if isinstance(row, (tuple, list)) else row)
        elif item[0] == "rows":
            _, header, rows = item
            lines.extend(" · ".join(str(c) for c in r) for r in rows)
    if s.footer:
        lines.append(f"<i>{s.footer}</i>")
    kb = InlineKeyboardMarkup(inline_keyboard=[[_classic_button(b) for b in row] for row in s.rows]) if s.rows else None
    return "\n".join(lines), kb


# ---------- отправка ----------
async def send(bot, chat_id: int, s: Screen, *, thread_id: int | None = None, reply_to: int | None = None):
    """Показывает экран: rich, а если не вышло — обычным сообщением. Возвращает отправленное сообщение."""
    global _off_until
    reply = ReplyParameters(message_id=reply_to, allow_sending_without_reply=True) if reply_to else None
    if time.time() >= _off_until:
        try:
            return await bot.send_rich_message(chat_id=chat_id, rich_message=to_rich(s), message_thread_id=thread_id,
                                               reply_parameters=reply)
        except Exception as e:
            logging.info("rich-экран не отправлен, шлю обычным сообщением: %s", e)
            _off_until = time.time() + OFF_FOR
    text, kb = to_classic(s)
    return await bot.send_message(chat_id, text, reply_markup=kb, message_thread_id=thread_id, reply_parameters=reply,
                                  disable_web_page_preview=True)


async def show(cb, s: Screen) -> None:
    """Переход по кнопке: если сообщение — rich (или rich сейчас доступен), шлём новый экран и убираем старый;
    обычное сообщение при недоступном rich правим на месте."""
    msg = cb.message
    if msg is None:
        return
    thread = msg.message_thread_id if getattr(msg, "is_topic_message", False) else None
    if getattr(msg, "rich_message", None) is not None or time.time() >= _off_until:
        sent = await send(cb.bot, msg.chat.id, s, thread_id=thread)
        if sent is not None and getattr(sent, "rich_message", None) is None and getattr(msg, "rich_message", None) is None:
            # rich не удался, а старое сообщение обычное — лучше обновить его, чем плодить копии
            try:
                await cb.bot.delete_message(msg.chat.id, sent.message_id)
                text, kb = to_classic(s)
                await msg.edit_text(text, reply_markup=kb, disable_web_page_preview=True)
                return
            except Exception:
                return
        try:
            await msg.delete()
        except Exception:
            pass
        return
    text, kb = to_classic(s)
    try:
        await msg.edit_text(text, reply_markup=kb, disable_web_page_preview=True)
    except Exception:
        pass                                    # «message is not modified»

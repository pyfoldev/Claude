import os
from dataclasses import dataclass


@dataclass
class Config:
    bot_token: str
    webapp_url: str
    owner_id: int
    webhook_secret: str
    db_path: str
    mode: str
    port: int = 8080
    webhook_url: str = ""   # куда Telegram шлёт обновления (порт 88/443/8443); по умолчанию — WEBAPP_URL
    owner_ids: frozenset = frozenset()
    database_url: str = ""
    river_api_key: str = ""
    river_base_url: str = "https://api.river.ai/v1"
    river_model: str = "deepseek-ai/DeepSeek-V4.1-Flash"
    river_vision_model: str = ""
    mistral_api_key: str = ""
    mistral_base_url: str = "https://api.mistral.ai/v1"
    mistral_stt_model: str = "voxtral-mini-latest"
    update_workers: int = 64   # сколько обновлений обрабатывается одновременно (режим webhook)
    cf_account_id: str = ""        # Cloudflare Workers AI — генерация картинок
    cf_api_token: str = ""
    cf_image_model: str = "@cf/black-forest-labs/flux-1-schnell"
    premium_price: int = 70        # звёзд за 30 дней Premium


def _owner_ids() -> list[int]:
    """OWNER_ID=123 или несколько через запятую: OWNER_ID=123,456"""
    out = []
    for part in os.environ.get("OWNER_ID", "").replace(";", ",").split(","):
        part = part.strip()
        if part.lstrip("-").isdigit() and int(part) != 0:
            out.append(int(part))
    return out


def load_config() -> Config:
    # лёгкая загрузка .env без зависимостей
    if os.path.exists(".env"):
        with open(".env", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
    token = os.environ.get("BOT_TOKEN", "")
    if not token:
        raise SystemExit("BOT_TOKEN не задан (см. .env.example)")
    return Config(
        bot_token=token,
        webapp_url=os.environ.get("WEBAPP_URL", "").rstrip("/"),
        owner_id=_owner_ids()[0] if _owner_ids() else 0,
        owner_ids=frozenset(_owner_ids()),
        webhook_secret=os.environ.get("WEBHOOK_SECRET", ""),
        webhook_url=os.environ.get("WEBHOOK_URL", "").rstrip("/"),
        db_path=os.environ.get("DB_PATH", "data/bot.db"),
        mode=os.environ.get("MODE", "polling"),
        port=int(os.environ.get("PORT", "8080") or 8080),
        database_url=os.environ.get("DATABASE_URL", ""),
        cf_account_id=os.environ.get("CF_ACCOUNT_ID", ""),
        cf_api_token=os.environ.get("CF_API_TOKEN", ""),
        cf_image_model=os.environ.get("CF_IMAGE_MODEL", "") or "@cf/black-forest-labs/flux-1-schnell",
        premium_price=int(os.environ.get("PREMIUM_PRICE", "70") or 70),
        river_api_key=os.environ.get("RIVER_API_KEY", ""),
        river_base_url=os.environ.get("RIVER_BASE_URL", "https://api.river.ai/v1").rstrip("/"),
        river_model=os.environ.get("RIVER_MODEL", "deepseek-ai/DeepSeek-V4.1-Flash"),
        river_vision_model=os.environ.get("RIVER_VISION_MODEL", ""),
        mistral_api_key=os.environ.get("MISTRAL_API_KEY", ""),
        mistral_base_url=os.environ.get("MISTRAL_BASE_URL", "https://api.mistral.ai/v1").rstrip("/"),
        mistral_stt_model=os.environ.get("MISTRAL_STT_MODEL", "voxtral-mini-latest"),
        update_workers=max(1, int(os.environ.get("UPDATE_WORKERS", "64") or 64)),
    )

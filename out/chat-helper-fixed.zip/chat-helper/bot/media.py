"""Работа с файлами сообщений: скачивание, кадры из видео, звук для расшифровки (ffmpeg)."""
from __future__ import annotations

import asyncio
import io
import shutil
import tempfile
from pathlib import Path

MAX_DOWNLOAD = 20 * 1024 * 1024  # лимит Bot API на скачивание файлов


def ffmpeg_available() -> bool:
    return shutil.which("ffmpeg") is not None


async def download(bot, file_id: str, size: int | None = None, limit: int = MAX_DOWNLOAD) -> bytes | None:
    """Скачать файл в память. None — если файл больше лимита."""
    if size is not None and size > limit:
        return None
    buf = io.BytesIO()
    await bot.download(file_id, destination=buf)
    data = buf.getvalue()
    return data if len(data) <= limit else None


async def avatar_info(bot, user_id: int) -> tuple[bytes | None, str | None]:
    """(картинка, постоянный id аватарки) — id нужен, чтобы понимать, сменил ли человек аватарку."""
    try:
        photos = await bot.get_user_profile_photos(user_id, limit=1)
        if not photos or not photos.total_count or not photos.photos:
            return None, None
        sizes = photos.photos[0]
        pick = next((p for p in sizes if max(p.width, p.height) >= 480), sizes[-1])
        data = await download(bot, pick.file_id, getattr(pick, "file_size", None), 5 * 1024 * 1024)
        return data, getattr(sizes[0], "file_unique_id", None) if data else None
    except Exception:
        return None, None


async def avatar(bot, user_id: int) -> bytes | None:
    """Текущая аватарка пользователя (средний размер, ~640 px). None — фото нет, скрыто настройками или сбой."""
    return (await avatar_info(bot, user_id))[0]


async def _run(*args: str) -> int:
    proc = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
    try:
        return await asyncio.wait_for(proc.wait(), timeout=60)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        return -1


async def extract_frames(data: bytes, suffix: str = ".mp4", count: int = 3) -> list[bytes]:
    """До `count` кадров (раз в 2 секунды) из видео/гиф/кружка в виде JPEG."""
    if not ffmpeg_available():
        return []
    with tempfile.TemporaryDirectory() as d:
        src = Path(d) / f"in{suffix}"
        src.write_bytes(data)
        out = Path(d) / "f_%d.jpg"
        await _run("ffmpeg", "-v", "error", "-protocol_whitelist", "file", "-i", str(src), "-vf", "fps=1/2", "-frames:v", str(count), str(out))
        frames = sorted(Path(d).glob("f_*.jpg"))
        if not frames:  # очень короткий ролик: берём первый кадр
            await _run("ffmpeg", "-v", "error", "-protocol_whitelist", "file", "-i", str(src), "-frames:v", "1", str(Path(d) / "f_1.jpg"))
            frames = sorted(Path(d).glob("f_*.jpg"))
        return [f.read_bytes() for f in frames]


async def to_mp3(data: bytes, suffix: str = ".ogg") -> bytes | None:
    """Звук любого файла (голосовое, кружок, видео) → моно mp3 16 кГц для расшифровки."""
    if not ffmpeg_available():
        return None
    with tempfile.TemporaryDirectory() as d:
        src, dst = Path(d) / f"in{suffix}", Path(d) / "out.mp3"
        src.write_bytes(data)
        rc = await _run("ffmpeg", "-v", "error", "-protocol_whitelist", "file", "-i", str(src), "-vn", "-ac", "1", "-ar", "16000",
                        "-b:a", "48k", str(dst))
        return dst.read_bytes() if rc == 0 and dst.exists() else None

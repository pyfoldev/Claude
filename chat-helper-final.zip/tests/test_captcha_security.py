import asyncio
import os
import sys
import time
import unittest
from unittest.mock import AsyncMock, patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from aiohttp.test_utils import TestClient, TestServer
from bot import captcha_server as captcha


class CaptchaTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = AsyncMock()
        self.db.get_captcha.return_value = {'user_id': 7, 'chat_id': 8, 'message_id': 9,
                                             'expires_at': time.time() + 60, 'answer': 'ABCDE'}
        self.db.consume_captcha.return_value = True
        self.on_pass = AsyncMock(return_value="done")
        self.client = TestClient(TestServer(captcha.build_app(self.db, 'token', self.on_pass)))
        await self.client.start_server()
        self.addAsyncCleanup(self.client.close)

    async def test_turnstile_requires_matching_cdata(self):
        with patch.object(captcha, 'turnstile_keys', return_value=('site', 'secret')), \
             patch.object(captcha, 'validate_init_data', return_value={'user': {'id': 7}}), \
             patch.object(captcha, 'verify_turnstile', new_callable=AsyncMock) as verify:
            for cdata in (None, '', 'another'):
                verify.return_value = {'success': True, 'cdata': cdata}
                response = await self.client.post('/captcha/verify', json={'token': 'challenge', 'initData': 'signed', 'turnstile': 'response'})
                self.assertFalse((await response.json())['ok'])
            self.db.consume_captcha.assert_not_awaited()
            verify.return_value = {'success': True, 'cdata': 'challenge'}
            response = await self.client.post('/captcha/verify', json={'token': 'challenge', 'initData': 'signed', 'turnstile': 'response'})
            self.assertTrue((await response.json())['ok'])
            self.on_pass.assert_awaited_once()

    async def test_chunked_report_is_limited(self):
        async def chunks():
            yield b'a' * 600
            await asyncio.sleep(0)
            yield b'b' * 600
        response = await self.client.post('/captcha/report', data=chunks())
        self.assertEqual(response.status, 413)

    async def test_image_cache_is_bounded(self):
        captcha.render_image.cache_clear()
        first = captcha.render_image('ABCDE', 'seed', 0)
        self.assertEqual(first, captcha.render_image('ABCDE', 'seed', 0))
        self.assertEqual(captcha.render_image.cache_info().hits, 1)
        self.assertEqual(captcha.render_image.cache_info().maxsize, 128)

if __name__ == '__main__':
    unittest.main()

class LimitTests(unittest.TestCase):
    def tearDown(self):
        captcha._ts_attempts.clear()
        captcha._report_hits.clear()

    def test_capacity_never_resets_existing_attempts(self):
        with patch.object(captcha, '_TS_TRACKED_MAX', 1):
            for _ in range(captcha.TURNSTILE_ATTEMPTS):
                self.assertTrue(captcha.take_turnstile_attempt('first'))
            self.assertFalse(captcha.take_turnstile_attempt('second'))
            self.assertFalse(captcha.take_turnstile_attempt('first'))
            captcha.refund_turnstile_attempt('first')
            self.assertTrue(captcha.take_turnstile_attempt('first'))

class CaptchaOutcomeTests(unittest.IsolatedAsyncioTestCase):
    async def test_web_verification_reports_telegram_failure(self):
        from aiohttp.test_utils import TestClient, TestServer
        db = AsyncMock()
        db.get_captcha.return_value = {'user_id': 7, 'chat_id': 8, 'message_id': 9, 'expires_at': time.time()+60, 'answer':'ABCDE'}
        db.consume_captcha.return_value = True
        db.take_captcha_attempt.return_value = True
        on_pass = AsyncMock(side_effect=RuntimeError('Telegram unavailable'))
        client = TestClient(TestServer(captcha.build_app(db, 'token', on_pass)))
        await client.start_server()
        self.addAsyncCleanup(client.close)
        with patch.object(captcha, 'turnstile_keys', return_value=None), \
             patch.object(captcha, 'validate_init_data', return_value={'user': {'id': 7}}), \
             patch.object(captcha.asyncio, 'sleep', new=AsyncMock()):
            response = await client.post('/captcha/verify', json={'token':'challenge', 'initData':'signed', 'answer':'ABCDE'})
        data = await response.json()
        self.assertFalse(data['ok'])
        self.assertEqual(data['error'], 'release_failed')
        self.assertEqual(on_pass.await_count, 2)

    async def test_chat_permissions_preserved_and_network_failure_not_silenced(self):
        from types import SimpleNamespace
        from bot.handlers.captcha import make_on_pass
        perms = SimpleNamespace(can_send_messages=False)
        bot = SimpleNamespace(get_chat=AsyncMock(return_value=SimpleNamespace(permissions=perms)),
                              restrict_chat_member=AsyncMock(), delete_message=AsyncMock())
        on_pass = make_on_pass(bot)
        self.assertEqual(await on_pass(1, 2, 0), 'done')
        self.assertIs(bot.restrict_chat_member.await_args.kwargs['permissions'], perms)
        bot.get_chat.side_effect = RuntimeError('network')
        bot.restrict_chat_member.reset_mock()
        with self.assertRaises(RuntimeError):
            await on_pass(1, 2, 0)
        bot.restrict_chat_member.assert_not_awaited()

    async def test_guard_query_is_restored_on_failed_approval(self):
        from types import SimpleNamespace
        from bot.handlers.captcha import make_on_pass
        db = SimpleNamespace(guard_query_pop=AsyncMock(return_value='query'), guard_query_set=AsyncMock())
        bot = SimpleNamespace(answer_chat_join_request_query=AsyncMock(side_effect=RuntimeError('network')),
                              approve_chat_join_request=AsyncMock(side_effect=RuntimeError('network')))
        with self.assertRaises(RuntimeError):
            await make_on_pass(bot, db)(1, 2, 0, kind='guard')
        self.assertEqual(db.guard_query_set.await_args.args[:3], (1, 2, 'query'))

class AnswerValidationTests(unittest.TestCase):
    def test_unpaired_surrogates_do_not_crash(self):
        self.assertFalse(captcha.answer_matches('\ud800', 'ABCDE'))
        self.assertFalse(captcha.answer_matches('ＡＢＣＤＥ', 'ABCDE'))
        self.assertTrue(captcha.answer_matches(' abcde ', 'ABCDE'))
        self.assertFalse(captcha.answer_matches('a' * 100, 'ABCDE'))

class MalformedWebRequestTests(unittest.IsolatedAsyncioTestCase):
    async def test_invalid_unicode_answer_is_rejected_without_server_error(self):
        from aiohttp.test_utils import TestClient, TestServer
        db = AsyncMock()
        db.get_captcha.return_value = {'user_id': 7, 'chat_id': 8, 'message_id': 9, 'expires_at': time.time()+60, 'answer':'ABCDE'}
        db.take_captcha_attempt.return_value = True
        on_pass = AsyncMock()
        client = TestClient(TestServer(captcha.build_app(db, 'token', on_pass)))
        await client.start_server()
        self.addAsyncCleanup(client.close)
        with patch.object(captcha, 'turnstile_keys', return_value=None), \
             patch.object(captcha, 'validate_init_data', return_value={'user':{'id':7}}):
            response = await client.post('/captcha/verify', json={'token':'x', 'initData':'signed', 'answer':'\ud800'})
        self.assertEqual(response.status, 200)
        self.assertFalse((await response.json())['ok'])
        on_pass.assert_not_awaited()

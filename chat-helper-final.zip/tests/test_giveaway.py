import asyncio
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.db import Database

class GiveawayTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = await Database.connect(os.path.join(self.tmp.name, 'bot.db'))
        self.addAsyncCleanup(self.db.close)
        self.addCleanup(self.tmp.cleanup)
        self.gid = await self.db.gw_new_draft(1, 2, 0)
        await self.db.gw_update(self.gid, status='active', ends_at=1000)

    async def test_parallel_images_keep_same_check_and_attempts(self):
        await asyncio.gather(*(self.db.gw_check_new(self.gid, 10, f'code{i}', 200, 100) for i in range(10)))
        check = await self.db.gw_check_get(self.gid, 10)
        await self.db.gw_check_attempt(self.gid, 10, 5, check['answer'], 100)
        await self.db.gw_check_new(self.gid, 10, 'replacement', 300, 100)
        after = await self.db.gw_check_get(self.gid, 10)
        self.assertEqual(after['answer'], check['answer'])
        self.assertEqual(after['attempts'], 1)
        self.assertFalse(await self.db.gw_check_attempt(self.gid, 10, 5, 'wrong-generation', 100))
        self.assertFalse(await self.db.gw_check_attempt(self.gid, 10, 5, check['answer'], 200))

    async def test_join_requires_active_unexpired_giveaway(self):
        self.assertTrue(await self.db.gw_join(self.gid, 10, 999))
        self.assertFalse(await self.db.gw_join(self.gid, 11, 1000))
        await self.db.gw_claim(self.gid, 'active', 'finishing')
        self.assertFalse(await self.db.gw_join(self.gid, 12, 999))
        self.assertEqual(await self.db.gw_entries(self.gid), [10])

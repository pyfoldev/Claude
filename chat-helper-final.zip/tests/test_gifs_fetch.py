import io
import os
import sys
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot import gifs_fetch

class Response(io.BytesIO):
    def __enter__(self): return self
    def __exit__(self, *args): self.close()

class GifFetchTests(unittest.TestCase):
    def test_redirect_to_internal_service_is_denied(self):
        self.assertFalse(gifs_fetch._safe_url('https://cdn.gifukai.com@127.0.0.1/a'))
        with self.assertRaises(urllib.error.URLError):
            gifs_fetch._SafeRedirect().redirect_request(None, None, 302, '', {}, 'http://127.0.0.1/')

    def test_oversized_download_is_removed(self):
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / 'x.gif'
            with patch.object(gifs_fetch._OPENER, 'open', return_value=Response(b'a' * 1025)):
                self.assertFalse(gifs_fetch.download({'url':'https://cdn.gifukai.com/x.gif'}, dest, 1024))
            self.assertFalse(dest.exists())
            self.assertFalse(dest.with_suffix('.part').exists())

    def test_path_traversal_filename_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertIsNone(gifs_fetch.fetch_one({'filename':'../file.gif'}, Path(d), False, 100))

    def test_ffmpeg_timeout_removes_partial_file(self):
        import subprocess
        with tempfile.TemporaryDirectory() as d:
            gif, mp4 = Path(d) / 'x.gif', Path(d) / 'x.mp4'
            partial = mp4.with_suffix('.part.mp4')
            partial.write_bytes(b'broken')
            with patch('bot.gifs_fetch.subprocess.run', side_effect=subprocess.TimeoutExpired('ffmpeg', 120)):
                self.assertFalse(gifs_fetch.to_mp4(gif, mp4))
            self.assertFalse(partial.exists())

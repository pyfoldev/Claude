import os
import sys
import time
import unittest
from datetime import timedelta
from types import SimpleNamespace as N
from unittest.mock import AsyncMock, patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot import rules, wipe
from bot.db import Database
from bot.middlewares import rules as mw
from bot.parsing import parse_mod_command as pm


class ParsingTests(unittest.TestCase):
    def test_quoted_and_next_line_reason(self):
        self.assertEqual(pm('бан "спам"').reason, 'спам')
        self.assertEqual(pm('чс @a 1д\nреклама').reason, 'реклама')
        self.assertEqual(pm('мут @a 1ч «флуд»').duration, timedelta(hours=1))

    def test_silent_and_delete_variants(self):
        self.assertTrue(pm('тбан @a').silent)
        self.assertTrue(pm('дмут @a 1ч').delete_msg)
        self.assertTrue(pm('кик тихо @a').silent)
        self.assertEqual(pm('кик тихо @A').target, '@A')

    def test_synonyms_and_cooldown(self):
        self.assertEqual(pm('-мут @a').name, 'размут')
        self.assertEqual(pm('-варн').name, 'снять варн')
        self.assertEqual(pm('мут остыть').duration, timedelta(minutes=10))
        self.assertEqual(pm('амнистия').name, 'амнистия')
        self.assertEqual(pm('вайп @a').name, 'вайп')

    def test_chat_is_not_a_command(self):
        self.assertIsNone(pm('бан бы дать'))
        self.assertIsNone(pm('разбан "x"'))


class RulesLogicTests(unittest.TestCase):
    def test_events(self):
        m = N(text='ПРИВЕТ ВСЕМ ХОРОШО', caption=None, entities=[N(type='url')], sticker=None)
        self.assertEqual(rules.detect_events(m), {'капс', 'ссылка'})
        self.assertEqual(rules.detect_events(N(text=None, caption=None, voice=object())), {'голосовое'})

    def test_trigger_parsing(self):
        self.assertEqual(rules.parse_trigger('ссылка мут 10м "реклама"'), ('ссылка', 'mute', 600, 'реклама'))
        with self.assertRaises(rules.TriggerError):
            rules.parse_trigger('капс удалить 10м')
        with self.assertRaises(rules.TriggerError):
            rules.parse_trigger('что-то бан')

    def test_strongest(self):
        got = rules.strongest([{'id': 1, 'action': 'warn'}, {'id': 2, 'action': 'ban'}, {'id': 3, 'action': 'delete'}])
        self.assertEqual(got['id'], 2)

    def test_faq_and_buttons(self):
        items = [{'id': 1, 'keyword': 'где правила', 'answer': 'x'}]
        self.assertIsNotNone(rules.faq_match('Подскажите, где правила?', items))
        self.assertIsNone(rules.faq_match('правила где', items))
        self.assertEqual(rules.split_faq_answer('hi\nкнопка: A | https://x.y')[1], [('A', 'https://x.y')])

    def test_night_window(self):
        self.assertTrue(rules.in_night(23, 23, 7))
        self.assertTrue(rules.in_night(2, 23, 7))
        self.assertFalse(rules.in_night(7, 23, 7))
        self.assertFalse(rules.in_night(12, 23, 7))
        self.assertEqual(rules.parse_night('с 23 до 7'), (23, 7))
        self.assertIsNone(rules.parse_night('25-3'))

    def test_face_control_unknown_photo_is_not_punished(self):
        u = N(id=7_900_000_000, username='x', is_premium=True)
        self.assertEqual(rules.face_reasons(u, {'fc_photo': 1}, None), [])
        self.assertEqual(rules.face_reasons(u, {'fc_photo': 1}, False), ['нет фото профиля'])

    def test_id_age_is_monotonic(self):
        ages = [rules.estimate_age_days(i) for i in (2e8, 9e8, 3e9, 6.5e9, 7.9e9)]
        self.assertEqual(ages, sorted(ages, reverse=True))

    def test_periodic(self):
        self.assertEqual(rules.parse_periodic('2 часа привет'), (7200, 'привет'))
        with self.assertRaises(rules.TriggerError):
            rules.parse_periodic('1м привет')

    def test_wipe_window(self):
        wipe._seen.clear()
        now = int(time.time())
        wipe.remember(1, 2, 10, now - 49 * 3600)
        wipe.remember(1, 2, 11, now - 60)
        self.assertEqual(wipe.take(1, 2, now), [11])


def _msg(text=None, user=5, **kw):
    base = dict(text=text, caption=None, entities=None, caption_entities=None, sticker=None, animation=None, voice=None,
                video_note=None, photo=None, video=None, document=None, poll=None, dice=None, story=None,
                forward_origin=None, via_bot=None, new_chat_members=None, left_chat_member=None, pinned_message=None,
                new_chat_title=None, new_chat_photo=None, delete_chat_photo=None, video_chat_started=None,
                video_chat_ended=None, video_chat_participants_invited=None, sender_chat=None, message_id=77,
                chat=N(id=-100, type='supergroup'), from_user=N(id=user, is_bot=False, username='u'),
                is_automatic_forward=False)
    base.update(kw)
    return N(**base)


class MiddlewareTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = await Database.connect(':memory:')
        self.bot = N(delete_message=AsyncMock(), send_message=AsyncMock(), me=AsyncMock(return_value=N(id=1)))
        self.mw = mw.RulesMiddleware(self.db)
        mw._cache.clear(); mw._notices.clear(); mw._faq_last.clear()
        self.handler = AsyncMock(return_value='handled')

    async def asyncTearDown(self):
        await self.db.close()

    async def run_mw(self, m, admin=False):
        with patch.object(mw.AdminCache, 'is_admin', new=AsyncMock(return_value=admin)):
            return await self.mw(self.handler, m, {'bot': self.bot})

    async def test_toggle_deletes_without_punishment(self):
        await self.db.set_setting(-100, 'del_sticker', 1)
        res = await self.run_mw(_msg(sticker=N(file_unique_id='u', set_name='s')))
        self.assertIsNone(res)
        self.bot.delete_message.assert_awaited_once()
        self.handler.assert_not_awaited()

    async def test_admin_and_trusted_are_exempt(self):
        await self.db.set_setting(-100, 'del_sticker', 1)
        m = _msg(sticker=N(file_unique_id='u', set_name='s'))
        self.assertEqual(await self.run_mw(m, admin=True), 'handled')
        await self.db.add_trusted(-100, 5, 1, 1)
        self.assertEqual(await self.run_mw(m), 'handled')
        self.bot.delete_message.assert_not_awaited()

    async def test_trigger_punishes_with_strongest_action(self):
        await self.db.add_trigger(-100, 'капс', 'warn', 0, 'капс', 1, 1)
        await self.db.add_trigger(-100, 'капс', 'mute', 600, 'капс-мут', 1, 1)
        applied = []

        async def fake_apply(bot, db, cmd, chat, actor, target, now, gif=True):
            applied.append(cmd)
            return 'ok'
        with patch.object(mw.ms, 'apply', new=fake_apply):
            res = await self.run_mw(_msg('ПРИВЕТ ВСЕМ ХОРОШО ДРУЗЬЯ'))
            import asyncio
            await asyncio.sleep(0.05)
        self.assertIsNone(res)
        self.assertEqual([(c.name, c.duration) for c in applied], [('мут', timedelta(seconds=600))])
        self.bot.delete_message.assert_awaited_once()

    async def test_blocked_sticker_set(self):
        await self.db.block_sticker(-100, 'set', 'bad')
        mw.invalidate(-100)
        self.assertIsNone(await self.run_mw(_msg(sticker=N(file_unique_id='u', set_name='bad'))))
        self.assertEqual(await self.run_mw(_msg(sticker=N(file_unique_id='u2', set_name='ok'))), 'handled')

    async def test_faq_answers_but_keeps_flow(self):
        await self.db.add_faq(-100, 'где правила', 'тут\nкнопка: Правила | https://t.me/x', 1, 1)
        res = await self.run_mw(_msg('а где правила?'))
        import asyncio
        await asyncio.sleep(0.05)
        self.assertEqual(res, 'handled')
        self.bot.send_message.assert_awaited_once()
        self.assertIsNotNone(self.bot.send_message.await_args.kwargs['reply_markup'])
        await self.run_mw(_msg('а где правила?'))
        await asyncio.sleep(0.05)
        self.assertEqual(self.bot.send_message.await_count, 1)   # повторный ответ — только через минуту

    async def test_delete_service_messages(self):
        await self.db.set_setting(-100, 'del_service', 1)
        m = _msg(new_chat_members=[N(id=9)], from_user=N(id=9, is_bot=False, username='n'))
        await self.run_mw(m)
        import asyncio
        await asyncio.sleep(0.05)
        self.bot.delete_message.assert_awaited()
        self.handler.assert_awaited()


if __name__ == '__main__':
    unittest.main()


class MembershipTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = await Database.connect(':memory:')
        self.bot = N(ban_chat_member=AsyncMock(), unban_chat_member=AsyncMock(), restrict_chat_member=AsyncMock(),
                     send_message=AsyncMock(), me=AsyncMock(return_value=N(id=1)), delete_messages=AsyncMock(),
                     get_user_profile_photos=AsyncMock(return_value=N(total_count=0)),
                     get_chat_member=AsyncMock(return_value=N(user=N(first_name='V'))))
        self.mw = mw.MembershipMiddleware(self.db)
        self.handler = AsyncMock(return_value='handled')

    async def asyncTearDown(self):
        await self.db.close()

    def ev(self, old, new, uid=500, by=None):
        user = N(id=uid, is_bot=False, username=None, is_premium=False)
        return N(chat=N(id=-100, type='supergroup'), old_chat_member=N(status=old), new_chat_member=N(status=new, user=user),
                 from_user=N(id=by or uid))

    async def test_face_control_kicks_profile_without_photo(self):
        await self.db.set_setting(-100, 'fc_on', 1)
        await self.db.set_setting(-100, 'fc_photo', 1)
        res = await self.mw(self.handler, self.ev('left', 'member'), {'bot': self.bot})
        self.assertIsNone(res)
        self.handler.assert_not_awaited()
        self.bot.ban_chat_member.assert_awaited_once()
        self.bot.unban_chat_member.assert_awaited_once()                          # кик = бан + разбан

    async def test_face_control_skips_trusted_and_unknown_photo(self):
        await self.db.set_setting(-100, 'fc_on', 1)
        await self.db.set_setting(-100, 'fc_photo', 1)
        await self.db.add_trusted(-100, 500, 1, 1)
        self.assertEqual(await self.mw(self.handler, self.ev('left', 'member'), {'bot': self.bot}), 'handled')
        self.bot.get_user_profile_photos.side_effect = RuntimeError('boom')
        await self.db.remove_trusted(-100, 500)
        self.assertEqual(await self.mw(self.handler, self.ev('left', 'member'), {'bot': self.bot}), 'handled')
        self.bot.ban_chat_member.assert_not_awaited()

    async def test_quick_leave_is_banned_slow_leave_is_not(self):
        await self.db.set_setting(-100, 'leave_on', 1)
        now = int(time.time())
        with patch.object(self.db, 'member_joined_at', new=AsyncMock(return_value=now - 30)):
            self.assertIsNone(await self.mw(self.handler, self.ev('member', 'left'), {'bot': self.bot}))
        self.bot.ban_chat_member.assert_awaited_once()
        self.bot.ban_chat_member.reset_mock()
        with patch.object(self.db, 'member_joined_at', new=AsyncMock(return_value=now - 99999)):
            self.assertEqual(await self.mw(self.handler, self.ev('member', 'left'), {'bot': self.bot}), 'handled')
        self.bot.ban_chat_member.assert_not_awaited()

    async def test_kicked_by_admin_is_not_punished_again(self):
        await self.db.set_setting(-100, 'leave_on', 1)
        with patch.object(self.db, 'member_joined_at', new=AsyncMock(return_value=int(time.time()) - 5)):
            res = await self.mw(self.handler, self.ev('member', 'left', by=999), {'bot': self.bot})
        self.assertEqual(res, 'handled')
        self.bot.ban_chat_member.assert_not_awaited()

import os
import random
import sys
import unittest
from types import SimpleNamespace as N
from unittest.mock import AsyncMock, patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot import collectibles as col
from bot import services as svc
from bot.db import Database
from bot.handlers import collect, services as svc_h


class CollectTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = await Database.connect(':memory:')

    async def asyncTearDown(self):
        await self.db.close()

    async def give(self, uid, cid, n):
        await self.db.conn.execute("INSERT INTO cards_owned VALUES(?,?,?)", (uid, cid, n))
        await self.db.conn.commit()

    async def test_find_cooldown(self):
        self.assertIsNone(await self.db.cards_try_find(1, 5, 1000, col.COOLDOWN))
        self.assertEqual(await self.db.cards_try_find(1, 6, 1100, col.COOLDOWN), col.COOLDOWN - 100)
        self.assertEqual(sum((await self.db.cards_of(1)).values()), 1)
        self.assertIsNone(await self.db.cards_try_find(1, 6, 1000 + col.COOLDOWN, col.COOLDOWN))

    async def test_swap_only_spares_and_atomic(self):
        await self.give(1, 5, 2)
        await self.give(2, 9, 2)
        self.assertTrue(await self.db.cards_swap(1, 5, 2, 9))
        self.assertEqual(await self.db.cards_of(1), {5: 1, 9: 1})
        self.assertEqual(await self.db.cards_of(2), {9: 1, 5: 1})
        self.assertFalse(await self.db.cards_swap(1, 5, 2, 9))          # запасных больше нет
        self.assertEqual(await self.db.cards_of(1), {5: 1, 9: 1})

    def test_catalog_and_draw(self):
        self.assertEqual(col.TOTAL, 60)
        self.assertEqual(col.find('сатурн'), 12)
        self.assertIsNone(col.can_trade({5: 2}, 5, {9: 2}, 9))
        self.assertIsNotNone(col.can_trade({5: 1}, 5, {9: 2}, 9))        # своей запасной копии нет
        self.assertIsNotNone(col.can_trade({5: 2}, 5, {9: 1}, 9))        # у соперника нет запасной
        counts = [0, 0, 0, 0]
        for i in range(5000):
            counts[col.CARDS[col.draw(random.Random(i))]['rarity']] += 1
        self.assertTrue(counts[0] > counts[1] > counts[2] > counts[3] > 0, counts)

    def test_parse(self):
        self.assertEqual(collect.parse('обмен 12 на 15')[0], 'trade')
        self.assertEqual(collect.parse('Альбом @vasya')[1], ('@vasya',))
        self.assertIsNone(collect.parse('альбом фото семьи'))


class ServicesTests(unittest.IsolatedAsyncioTestCase):
    def test_calc(self):
        self.assertEqual(svc.calc('2+2*2'), '6')
        self.assertEqual(svc.calc('15% от 200'), '30')
        for bad in ('1/0', '__import__("os")', '9**9**9', 'a'):
            with self.assertRaises(svc.CalcError):
                svc.calc(bad)

    def test_money_and_route(self):
        self.assertEqual(svc.parse_money('100 usd eur'), (100.0, 'USD', 'EUR'))
        self.assertEqual(svc.convert({'USD': 90.0, 'EUR': 100.0}, 100, 'USD', 'EUR'), 90.0)
        self.assertEqual(svc.parse_route('Санкт-Петербург — Москва'), ('Санкт-Петербург', 'Москва'))
        self.assertEqual(svc.parse_sign('15.08'), 'Лев')
        self.assertIsNone(svc.parse_crypto('foo'))

    async def test_handler_calc_and_horoscope_without_ai(self):
        msg = N(text='калк (2+3)*4', from_user=N(id=11), reply=AsyncMock())
        svc_h._last.clear()
        await svc_h.on_service(msg)
        self.assertIn('20', msg.reply.await_args.args[0])
        msg2 = N(text='гороскоп лев', from_user=N(id=12), reply=AsyncMock())
        await svc_h.on_service(msg2, ai=None)
        self.assertIn('ИИ', msg2.reply.await_args.args[0])

    async def test_rate_handler_uses_cbr_data(self):
        msg = N(text='курс 10 usd', from_user=N(id=13), reply=AsyncMock())
        with patch.object(svc, 'fetch_rates', new=AsyncMock(return_value={'USD': 90.0})):
            await svc_h.on_service(msg, http=object())
        self.assertIn('900', msg.reply.await_args.args[0])

    def test_services_parse_ignores_chat(self):
        self.assertIsNone(svc_h.parse('курс валют упал вчера сильно очень'  * 20))
        self.assertEqual(svc_h.parse('вики Пушкин')[0], 'wiki')


if __name__ == '__main__':
    unittest.main()

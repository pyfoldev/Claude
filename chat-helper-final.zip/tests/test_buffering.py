import asyncio
import os
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.db import Database
from bot.pg import PgConn
from unittest.mock import AsyncMock

class BufferTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = await Database.connect(os.path.join(self.tmp.name, 'bot.db'))
        self.addAsyncCleanup(self.db.close)
        self.addCleanup(self.tmp.cleanup)

    async def test_flush_writes_counts_once(self):
        for i in range(1200):
            await self.db.record_message(1, i % 300, 3601)
        await self.db.flush_messages()
        await self.db.flush_messages()
        cur = await self.db.conn.execute('SELECT COUNT(*), SUM(n) FROM msg_hourly')
        row = await cur.fetchone()
        self.assertEqual(tuple(row), (300, 1200))

    async def test_failed_batch_is_restored(self):
        await self.db.record_message(1, 2, 3601)
        original = self.db.conn.executemany
        with patch.object(type(self.db.conn), 'executemany', side_effect=RuntimeError('write error')):
            with self.assertRaises(RuntimeError):
                await self.db.flush_messages()
        self.assertEqual(sum(self.db._msg_buf.values()), 1)
        await self.db.flush_messages()
        cur = await self.db.conn.execute('SELECT SUM(n) FROM msg_hourly')
        self.assertEqual((await cur.fetchone())[0], 1)

    async def test_pg_batch_translates_and_starts_transaction(self):
        raw = AsyncMock()
        pg = PgConn(raw)
        await pg.executemany('INSERT INTO msg_hourly VALUES(?,?,?,?)', [(1,2,3,4)])
        self.assertEqual(raw.execute.await_args.args[0], 'BEGIN')
        self.assertIn('$1,$2,$3,$4', raw.executemany.await_args.args[0])
        await pg.commit()
        self.assertEqual(raw.execute.await_args.args[0], 'COMMIT')

    async def test_identity_batch_rollback_on_second_batch_failure(self):
        await self.db.remember_user(42, 'name', 'Name')
        await self.db.touch_member(1, 42, 100)
        real = self.db._raw.executemany
        count = 0
        async def fail_second(sql, args):
            nonlocal count
            count += 1
            if count == 2:
                raise RuntimeError('failed batch')
            return await real(sql, args)
        with patch.object(self.db._raw, 'executemany', side_effect=fail_second):
            with self.assertRaises(RuntimeError):
                await self.db._flush_users()
        self.assertTrue(self.db._dirty)
        cur = await self.db._raw.execute('SELECT COUNT(*) FROM users WHERE user_id=42')
        self.assertEqual((await cur.fetchone())[0], 0)
        await self.db._flush_users()
        cur = await self.db._raw.execute('SELECT COUNT(*) FROM users WHERE user_id=42')
        self.assertEqual((await cur.fetchone())[0], 1)

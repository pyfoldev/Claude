import asyncio
import os
import sys
import tempfile
import unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.db import Database

class QuotaTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = await Database.connect(os.path.join(self.tmp.name, 'test.db'))
        self.addAsyncCleanup(self.db.close)
        self.addCleanup(self.tmp.cleanup)

    async def test_zero_quota_is_never_granted(self):
        self.assertFalse(await self.db.take_quota(1, 'x', 0, 0))
        self.assertFalse(await self.db.take_quota(1, 'x', 0, -1))

    async def test_concurrent_requests_cannot_exceed_quota(self):
        result = await asyncio.gather(*(self.db.take_quota(1, 'x', 0, 3) for _ in range(25)))
        self.assertEqual(sum(result), 3)

class TranscriptionQuotaTests(unittest.IsolatedAsyncioTestCase):
    async def test_failed_download_refunds_original_day(self):
        from types import SimpleNamespace
        from unittest.mock import AsyncMock, patch
        from bot.handlers import ai as handler
        media = SimpleNamespace(duration=1, file_size=1, file_id='file')
        message = SimpleNamespace(chat=SimpleNamespace(id=10,type='group'), voice=media, video_note=None, video=None, audio=None)
        db = SimpleNamespace(get_settings=AsyncMock(return_value={'transcribe_on':1,'transcribe_max':180}),
                             take_quota=AsyncMock(return_value=True), refund_quota=AsyncMock())
        engine = SimpleNamespace(has_stt=True)
        with patch.object(handler.time, 'time', return_value=86399), \
             patch.object(handler.media, 'download', new=AsyncMock(return_value=None)):
            await handler.transcribe(message, None, db, engine)
        db.refund_quota.assert_awaited_once_with(10, 'stt', 86399)

    async def test_cancelled_transcription_returns_quota(self):
        from types import SimpleNamespace
        from unittest.mock import AsyncMock, patch
        from bot.handlers import ai as handler
        obj = SimpleNamespace(duration=1, file_size=1, file_id='file')
        msg = SimpleNamespace(chat=SimpleNamespace(id=10, type='group'), voice=obj, video_note=None, video=None, audio=None)
        db = SimpleNamespace(get_settings=AsyncMock(return_value={'transcribe_on':1,'transcribe_max':180}),
                             take_quota=AsyncMock(return_value=True), refund_quota=AsyncMock())
        started = asyncio.Event()
        async def wait_download(*args):
            started.set()
            await asyncio.Event().wait()
        with patch.object(handler.time, 'time', return_value=100), \
             patch.object(handler.media, 'download', new=AsyncMock(side_effect=wait_download)):
            task = asyncio.create_task(handler.transcribe(msg, None, db, SimpleNamespace(has_stt=True)))
            await started.wait()
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
        db.refund_quota.assert_awaited_once_with(10, 'stt', 100)

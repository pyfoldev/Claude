import os
import sys
import time
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.handlers import votes, duels, economy

class VoteTests(unittest.IsolatedAsyncioTestCase):
    def tearDown(self): votes._votes.clear()
    async def test_former_member_cannot_vote(self):
        votes._votes['x'] = {'chat':10, 'target':2, 'voters':{1}, 'expires':time.time()+60, 'tname':'User'}
        cb = SimpleNamespace(data='vote:x:y', from_user=SimpleNamespace(id=3), message=SimpleNamespace(chat=SimpleNamespace(id=10)), answer=AsyncMock())
        bot = SimpleNamespace(get_chat_member=AsyncMock(return_value=SimpleNamespace(status='left')))
        db = SimpleNamespace(user_total=AsyncMock(return_value=20))
        await votes.vote_cb(cb, bot, db)
        self.assertEqual(votes._votes['x']['voters'], {1})
        db.user_total.assert_not_awaited()

    async def test_promoted_target_is_not_muted(self):
        votes._votes['x'] = {'chat':10, 'target':2, 'voters':{1,4,5,6}, 'expires':time.time()+60, 'tname':'User'}
        cb = SimpleNamespace(data='vote:x:y', from_user=SimpleNamespace(id=3),
                             message=SimpleNamespace(chat=SimpleNamespace(id=10),edit_text=AsyncMock()), answer=AsyncMock())
        bot = SimpleNamespace(get_chat_member=AsyncMock(side_effect=[SimpleNamespace(status='member'), SimpleNamespace(status='administrator')]))
        db = SimpleNamespace(user_total=AsyncMock(return_value=20), get_rank=AsyncMock(return_value=0))
        with patch.object(votes.ms, 'apply', new=AsyncMock()) as apply:
            await votes.vote_cb(cb, bot, db)
            apply.assert_not_awaited()
        self.assertIn('полномочия', cb.message.edit_text.await_args.args[0])

class DuelTests(unittest.IsolatedAsyncioTestCase):
    async def test_expired_duel_rejects_action(self):
        d = {'id':'x', 'chat_id':10, 'message_id':20, 'expires_at':int(time.time())-1}
        cb = SimpleNamespace(data='duel:x:accept', from_user=SimpleNamespace(id=1),
                             message=SimpleNamespace(chat=SimpleNamespace(id=10),message_id=20), answer=AsyncMock())
        db = SimpleNamespace(get_duel=AsyncMock(return_value=d), save_duel=AsyncMock())
        await duels.duel_cb(cb, db)
        db.save_duel.assert_not_awaited()
        self.assertIn('вышло', cb.answer.await_args.args[0])

    async def test_foreign_message_does_not_control_duel(self):
        d = {'id':'x', 'chat_id':10, 'message_id':20, 'expires_at':int(time.time())+60}
        cb = SimpleNamespace(data='duel:x:accept', from_user=SimpleNamespace(id=1),
                             message=SimpleNamespace(chat=SimpleNamespace(id=11),message_id=20), answer=AsyncMock())
        db = SimpleNamespace(get_duel=AsyncMock(return_value=d), save_duel=AsyncMock())
        await duels.duel_cb(cb, db)
        db.save_duel.assert_not_awaited()

    async def test_simultaneous_challenges_do_not_duplicate(self):
        import asyncio
        users = [SimpleNamespace(id=1, full_name='A', is_bot=False), SimpleNamespace(id=2, full_name='B', is_bot=False)]
        messages = [SimpleNamespace(chat=SimpleNamespace(id=10, type='group'), from_user=users[0],
                                    answer=AsyncMock(return_value=SimpleNamespace(message_id=20))) for _ in range(2)]
        stored = []
        async def save(item): stored.append(item)
        db = SimpleNamespace(get_settings=AsyncMock(return_value={'games_on':1}),
                             chat_duels=AsyncMock(side_effect=lambda _: list(stored)), save_duel=AsyncMock(side_effect=save))
        with patch.object(duels, 'real_reply', return_value=SimpleNamespace(from_user=users[1])), \
             patch.object(duels.ux, 'tell', new=AsyncMock()):
            await asyncio.gather(*(duels.challenge(msg, db) for msg in messages))
        self.assertEqual(len(stored), 1)
        self.assertEqual(sum(m.answer.await_count for m in messages), 1)

class DuelSettlementTests(unittest.IsolatedAsyncioTestCase):
    async def test_failed_winner_record_keeps_duel(self):
        import tempfile
        from bot.db import Database
        with tempfile.TemporaryDirectory() as d:
            db = await Database.connect(os.path.join(d, 'db'))
            try:
                duel = {'id':'safe', 'chat_id':10, 'challenger':{'id':1,'name':'A'}, 'opponent':{'id':2,'name':'B'}, 'expires_at':123}
                await db.save_duel(duel)
                with patch.object(duels, '_pair_win_allowed', return_value=True), \
                     patch.object(db, 'add_win', new=AsyncMock(side_effect=RuntimeError('database failure'))):
                    with self.assertRaises(RuntimeError):
                        await duels._finish(SimpleNamespace(edit_text=AsyncMock()), db, duel, 'result', duel['challenger'])
                self.assertIsNotNone(await db.get_duel('safe'))
            finally:
                await db.close()

class FailedPostTests(unittest.IsolatedAsyncioTestCase):
    def tearDown(self):
        economy._dice.clear()
        votes._votes.clear()

    async def test_failed_dice_post_does_not_leave_invisible_invitation(self):
        msg = SimpleNamespace(chat=SimpleNamespace(id=10), from_user=SimpleNamespace(id=1,full_name='A'),
                              answer=AsyncMock(side_effect=RuntimeError('network')))
        bot = SimpleNamespace(me=AsyncMock(return_value=SimpleNamespace(id=99)))
        with patch.object(economy, 'resolve_user', new=AsyncMock(return_value=(2,'B'))):
            with self.assertRaises(RuntimeError):
                await economy._dice_offer(msg, bot, None, (None, '@name'), None)
        self.assertFalse(economy._dice)

    async def test_failed_vote_post_does_not_block_future_votes(self):
        msg = SimpleNamespace(chat=SimpleNamespace(id=10,type='group'), from_user=SimpleNamespace(id=1),
                              text='гб @name', answer=AsyncMock(side_effect=RuntimeError('network')))
        bot = SimpleNamespace(me=AsyncMock(return_value=SimpleNamespace(id=99)))
        db = SimpleNamespace(user_total=AsyncMock(return_value=15), get_rank=AsyncMock(return_value=0))
        with patch.object(votes, 'resolve_user', new=AsyncMock(return_value=(2,'B'))), \
             patch.object(votes.ms, 'real_reply', return_value=None), \
             patch.object(votes.ms, 'get_member', new=AsyncMock(return_value=SimpleNamespace(status='member'))):
            with self.assertRaises(RuntimeError):
                await votes.start_vote(msg, bot, db)
        self.assertFalse(votes._votes)

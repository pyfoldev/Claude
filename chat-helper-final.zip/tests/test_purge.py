import asyncio
import os
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot import purge

class PurgeTests(unittest.IsolatedAsyncioTestCase):
    def tearDown(self): purge.JOBS.clear()
    async def test_simultaneous_start_only_creates_one_job(self):
        gate = asyncio.Event()
        async def status(*args, **kwargs):
            await gate.wait()
            return SimpleNamespace(message_id=500)
        bot = SimpleNamespace(send_message=AsyncMock(side_effect=status))
        running = asyncio.Event()
        async def worker(*args):
            await running.wait()
        with patch.object(purge, '_check_bot_rights', new=AsyncMock()), patch.object(purge, '_run', new=worker):
            first = asyncio.create_task(purge.start_purge(bot, None, 1, 2))
            await asyncio.sleep(0)
            second = asyncio.create_task(purge.start_purge(bot, None, 1, 2))
            gate.set()
            a, b = await asyncio.gather(first, second, return_exceptions=True)
            self.assertIsInstance(a, purge.PurgeJob)
            self.assertIsInstance(b, purge.PurgeError)
            self.assertEqual(bot.send_message.await_count, 1)
            a.task.cancel()
            await asyncio.gather(a.task, return_exceptions=True)

    async def test_cancelled_job_is_marked_stopped(self):
        started = asyncio.Event()
        async def delete(*args):
            started.set()
            await asyncio.Event().wait()
        bot = SimpleNamespace(delete_messages=AsyncMock(side_effect=delete), edit_message_text=AsyncMock())
        db = SimpleNamespace(log_action=AsyncMock())
        job = purge.PurgeJob(1, 2, 100, status_msg=101)
        task = asyncio.create_task(purge._run(bot, db, job))
        await started.wait()
        task.cancel()
        with self.assertRaises(asyncio.CancelledError): await task
        self.assertEqual(job.state, 'stopped')
        self.assertIn('остановлена', bot.edit_message_text.await_args.args[0])

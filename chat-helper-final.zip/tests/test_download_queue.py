import asyncio
import os
import sys
import threading
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.handlers import download
from bot.updatequeue import UpdateQueue


class DownloadTests(unittest.IsolatedAsyncioTestCase):
    async def test_timed_out_thread_retains_slot_and_directory(self):
        started, release = threading.Event(), threading.Event()
        paths = []
        def fetch(url, tmp, cookies):
            paths.append(tmp)
            started.set()
            release.wait(5)
            return SimpleNamespace(videos=[], photos=[])
        msg = SimpleNamespace(from_user=SimpleNamespace(id=123), chat=SimpleNamespace(id=55), reply=AsyncMock(return_value=SimpleNamespace(chat=SimpleNamespace(id=55), message_id=1)))
        db = SimpleNamespace(take_quota=AsyncMock(return_value=True), refund_quota=AsyncMock())
        bot = SimpleNamespace(delete_message=AsyncMock())
        sem = asyncio.Semaphore(1)
        download._last.clear()
        try:
            with patch.object(download, '_sem', sem), patch.object(download, 'DL_TIMEOUT', .05), patch.object(download.perf, 'chat_action'):
                await download._run(msg, bot, db, 'https://youtube.com/watch?v=abc', fetch, None, False)
                self.assertTrue(started.is_set())
                self.assertTrue(sem.locked())
                self.assertTrue(os.path.isdir(paths[0]))
                db.refund_quota.assert_awaited_once()
                release.set()
                for _ in range(100):
                    if not os.path.exists(paths[0]):
                        break
                    await asyncio.sleep(.01)
                self.assertFalse(sem.locked())
                self.assertFalse(os.path.exists(paths[0]))
        finally:
            release.set()


class QueueTests(unittest.IsolatedAsyncioTestCase):
    async def test_flush_batches_and_preserves_parameters(self):
        conn = SimpleNamespace(execute=AsyncMock(), commit=AsyncMock())
        queue = UpdateQueue(SimpleNamespace(conn=conn), None, None)
        queue._done = list(range(1201))
        await queue.flush_done()
        self.assertEqual(conn.execute.await_count, 3)
        params = [call.args[1] for call in conn.execute.await_args_list]
        self.assertEqual([len(p) for p in params], [500, 500, 201])
        self.assertEqual([item for group in params for item in group], list(range(1201)))
        conn.commit.assert_awaited_once()

    async def test_flush_failure_keeps_ids_for_retry(self):
        conn = SimpleNamespace(execute=AsyncMock(side_effect=RuntimeError('db')), commit=AsyncMock())
        queue = UpdateQueue(SimpleNamespace(conn=conn), None, None)
        queue._done = [1, 2]
        await queue.flush_done()
        self.assertEqual(queue._done, [1, 2])

if __name__ == '__main__':
    unittest.main()

class QueueCancellationTests(unittest.IsolatedAsyncioTestCase):
    async def test_cancelled_flush_keeps_ids_for_final_flush(self):
        started = asyncio.Event()
        async def blocked(*args):
            started.set()
            await asyncio.Event().wait()
        conn = SimpleNamespace(execute=AsyncMock(side_effect=blocked), commit=AsyncMock())
        queue = UpdateQueue(SimpleNamespace(conn=conn), None, None)
        queue._done = [42, 43]
        task = asyncio.create_task(queue.flush_done())
        await started.wait()
        queue._done.append(44)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertEqual(queue._done, [42, 43, 44])

class QueueCompletedDuplicateTests(unittest.IsolatedAsyncioTestCase):
    async def test_completed_id_remains_protected_until_cleanup(self):
        db = SimpleNamespace(conn=SimpleNamespace(execute=AsyncMock(), commit=AsyncMock()))
        queue = UpdateQueue(db, None, None)
        queue._done_ids.add(123)
        queue._done.append(123)
        self.assertFalse(await queue.put(SimpleNamespace(update_id=123), '{}'))
        self.assertEqual(queue.depth(), 0)
        await queue.flush_done()
        self.assertNotIn(123, queue._done_ids)

class CaptionTests(unittest.TestCase):
    def test_long_escaped_content_does_not_break_html(self):
        from html.parser import HTMLParser
        from bot.handlers.download import _caption
        class Checker(HTMLParser):
            def __init__(self): super().__init__(); self.stack = []
            def handle_starttag(self, tag, attrs): self.stack.append(tag)
            def handle_endtag(self, tag): self.assert_tag(tag)
            def assert_tag(self, tag):
                if not self.stack or self.stack.pop() != tag: raise AssertionError(tag)
        caption = _caption('YouTube', '&' * 150, 'https://youtube.com/?v=' + '&' * 1000)
        check = Checker(); check.feed(caption)
        self.assertFalse(check.stack)
        self.assertLessEqual(len(caption), 1000)

class WaitingDownloadTests(unittest.IsolatedAsyncioTestCase):
    async def test_timeout_cancels_download_that_has_not_started(self):
        from unittest.mock import Mock
        msg = SimpleNamespace(from_user=SimpleNamespace(id=9123), chat=SimpleNamespace(id=55), reply=AsyncMock(return_value=SimpleNamespace(chat=SimpleNamespace(id=55), message_id=1)))
        db = SimpleNamespace(take_quota=AsyncMock(return_value=True), refund_quota=AsyncMock())
        bot = SimpleNamespace(delete_message=AsyncMock())
        sem = asyncio.Semaphore(1)
        await sem.acquire()
        fetch = Mock()
        download._last.clear()
        with patch.object(download, '_sem', sem), patch.object(download, 'DL_TIMEOUT', .03), patch.object(download.perf, 'chat_action'):
            await download._run(msg, bot, db, 'https://youtube.com/watch?v=abc', fetch, None, False)
            sem.release()
            await asyncio.sleep(.02)
        fetch.assert_not_called()
        db.refund_quota.assert_awaited_once()

class DownloadCooldownTests(unittest.IsolatedAsyncioTestCase):
    async def test_parallel_user_requests_cannot_bypass_cooldown(self):
        from unittest.mock import Mock
        started, release = asyncio.Event(), asyncio.Event()
        async def quota(*args):
            started.set()
            await release.wait()
            return False
        msg = SimpleNamespace(from_user=SimpleNamespace(id=4711), chat=SimpleNamespace(id=55), reply=AsyncMock())
        db = SimpleNamespace(take_quota=AsyncMock(side_effect=quota))
        download._last.clear()
        with patch.object(download.ux, 'tell', new=AsyncMock()):
            first = asyncio.create_task(download._run(msg, None, db, 'https://youtube.com/watch?v=abc', Mock(), None, False))
            await started.wait()
            await download._run(msg, None, db, 'https://youtube.com/watch?v=abc', Mock(), None, False)
            release.set()
            await first
        db.take_quota.assert_awaited_once()

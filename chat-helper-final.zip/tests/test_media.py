import io
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from PIL import Image
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot import media

@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'ffmpeg not installed')
class MediaTests(unittest.IsolatedAsyncioTestCase):
    async def test_audio_is_converted(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / 'test.wav'
            subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','sine=frequency=440:duration=1', str(src)],check=True)
            output = await media.to_mp3(src.read_bytes(), '.wav')
            self.assertTrue(output and len(output) <= media.MAX_AUDIO_BYTES)

    async def test_frames_are_bounded(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / 'test.mp4'
            subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=1600x800:d=2','-c:v','mpeg4',str(src)],check=True)
            frames = await media.extract_frames(src.read_bytes(), '.mp4', 3)
            self.assertTrue(frames)
            for frame in frames:
                with Image.open(io.BytesIO(frame)) as img:
                    self.assertLessEqual(max(img.size), 1280)

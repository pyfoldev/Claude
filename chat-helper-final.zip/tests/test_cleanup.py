import os
import sys
import time
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.handlers import cleanup

class CleanupTests(unittest.IsolatedAsyncioTestCase):
    async def test_target_is_rechecked_before_removal(self):
        cleanup._pending['test'] = {'chat': 10, 'actor': 1, 'ids': [2, 3, 4], 'expires': time.time() + 60}
        cb = SimpleNamespace(data='cln:test:yes', from_user=SimpleNamespace(id=1),
                             message=SimpleNamespace(chat=SimpleNamespace(id=10), edit_text=AsyncMock()), answer=AsyncMock())
        db = SimpleNamespace(get_access=AsyncMock(return_value={}), get_rank=AsyncMock(side_effect=[1, 0, 0]),
                             set_member_active=AsyncMock(), log_action=AsyncMock())
        bot = SimpleNamespace(get_chat_member=AsyncMock(side_effect=[SimpleNamespace(status='left'), SimpleNamespace(status='member')]),
                              ban_chat_member=AsyncMock(), unban_chat_member=AsyncMock())
        with patch.object(cleanup.ms, 'effective_rank', new=AsyncMock(return_value=5)), patch.object(cleanup, 'KICK_DELAY', 0):
            await cleanup.confirm(cb, bot, db)
        bot.ban_chat_member.assert_awaited_once_with(10, 4)
        db.set_member_active.assert_awaited_once_with(10, 4, False)

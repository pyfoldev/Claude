import os
import sys
import unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.aimod import Cache, ModResult, parse_moderation

class AiModerationTests(unittest.TestCase):
    def test_cache_does_not_conflate_different_text_or_context(self):
        cache = Cache()
        verdict = ModResult('spam', .9, '')
        cache.put('hello', verdict, 'новый аккаунт')
        self.assertIs(cache.get('hello', 'новый аккаунт'), verdict)
        self.assertIsNone(cache.get('helloooo', 'новый аккаунт'))
        self.assertIsNone(cache.get('hello', 'другой контекст'))

    def test_invalid_model_verdict_is_rejected(self):
        for raw in ('{"category": [], "confidence": 0.9}', '{"category":"spam","confidence":NaN}',
                    '{"category":"spam","confidence":Infinity}', '{"category":"spam","confidence":101}',
                    '{"category":"spam","confidence":-2}'):
            self.assertIsNone(parse_moderation(raw))
        self.assertEqual(parse_moderation('{"category":"spam","confidence":90}').confidence, .9)

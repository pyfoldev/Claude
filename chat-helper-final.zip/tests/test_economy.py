import os
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.db import Database
from bot.handlers.economy import _settle_dice

class EconomyTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = await Database.connect(os.path.join(self.tmp.name, 'bot.db'))
        self.addAsyncCleanup(self.db.close)
        self.addCleanup(self.tmp.cleanup)

    async def test_win_transfers_exact_stake(self):
        self.assertIsNone(await _settle_dice(self.db, 1, 10, 20, 100, 10))
        self.assertEqual(await self.db.get_balance(1, 10), 1100)
        self.assertEqual(await self.db.get_balance(1, 20), 900)

    async def test_insufficient_funds_never_charges_other_player(self):
        await self.db.try_spend(1, 20, 950)
        self.assertEqual(await _settle_dice(self.db, 1, 10, 20, 100, 10), 20)
        self.assertEqual(await self.db.get_balance(1, 10), 1000)
        self.assertEqual(await self.db.get_balance(1, 20), 50)

    async def test_failure_rolls_back_transfer(self):
        await self.db.get_balance(1, 10)
        await self.db.get_balance(1, 20)
        with patch.object(self.db, 'add_win', side_effect=RuntimeError('failure')):
            with patch('bot.handlers.economy._pair_win_allowed', return_value=True):
                with self.assertRaises(RuntimeError):
                    await _settle_dice(self.db, 1, 10, 20, 100, 10)
        self.assertEqual(await self.db.get_balance(1, 10), 1000)
        self.assertEqual(await self.db.get_balance(1, 20), 1000)

class GardenTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = await Database.connect(os.path.join(self.tmp.name, 'bot.db'))
        self.addAsyncCleanup(self.db.close)
        self.addCleanup(self.tmp.cleanup)

    async def test_plant_rolls_back_charge_when_garden_save_fails(self):
        from types import SimpleNamespace
        from unittest.mock import AsyncMock
        from bot.handlers.garden import garden_cmd
        msg = SimpleNamespace(chat=SimpleNamespace(id=1, type='private'), from_user=SimpleNamespace(id=10),
                              text='посадить морковь', reply=AsyncMock())
        await self.db.get_balance(1, 10)
        with patch.object(self.db, 'save_garden', side_effect=RuntimeError('disk error')):
            with self.assertRaises(RuntimeError):
                await garden_cmd(msg, self.db)
        self.assertEqual(await self.db.get_balance(1, 10), 1000)
        self.assertIsNone(await self.db.get_garden(1, 10))

    async def test_harvest_rolls_back_if_credit_fails(self):
        from types import SimpleNamespace
        from unittest.mock import AsyncMock
        from bot.games.garden import new_garden, plant
        from bot.handlers.garden import garden_cmd
        gd = new_garden()
        plant(gd, 'морковь', 0)
        await self.db.save_garden(1, 10, gd)
        msg = SimpleNamespace(chat=SimpleNamespace(id=1, type='private'), from_user=SimpleNamespace(id=10),
                              text='собрать', reply=AsyncMock())
        with patch.object(self.db, 'change_balance', side_effect=RuntimeError('db error')):
            with self.assertRaises(RuntimeError):
                await garden_cmd(msg, self.db)
        self.assertIsNotNone((await self.db.get_garden(1, 10))['plots'][0])

import os
import sys
import unittest
from unittest.mock import AsyncMock, Mock
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.ai import AiClient, AiError

class Response:
    status = 200
    async def __aenter__(self): return self
    async def __aexit__(self, *args): pass
    async def json(self):
        return {'choices':[{'message':{'content':'','reasoning_content':'thinking'},'finish_reason':'length'}]}

class AiClientTests(unittest.IsolatedAsyncioTestCase):
    async def test_reasoning_retry_is_bounded(self):
        session = Mock()
        session.post.return_value = Response()
        client = AiClient(session, river_key='key', river_base='https://example.com', river_model='model',
                          mistral_key='', mistral_base='https://example.com', stt_model='model')
        with self.assertRaises(AiError):
            await client._chat([], max_tokens=800)
        self.assertEqual(session.post.call_count, 2)
        self.assertEqual([c.kwargs['json']['max_tokens'] for c in session.post.call_args_list], [800, 2000])

    async def test_malformed_response_returns_controlled_error(self):
        response = Response()
        response.json = AsyncMock(return_value={'choices':[{'message':{'content':['not text']}}]})
        session = Mock()
        session.post.return_value = response
        client = AiClient(session, river_key='key', river_base='https://example.com', river_model='model',
                          mistral_key='', mistral_base='https://example.com', stt_model='model')
        with self.assertRaises(AiError):
            await client._chat([], max_tokens=100)

    async def test_stream_limits_oversized_response(self):
        class Lines:
            def __aiter__(self):
                async def items():
                    import json
                    payload = {'choices':[{'delta':{'content':'x' * 50000}}]}
                    yield ('data: ' + json.dumps(payload)).encode()
                return items()
        response = Response()
        response.content = Lines()
        session = Mock()
        session.post.return_value = response
        client = AiClient(session, river_key='key', river_base='https://example.com', river_model='model',
                          mistral_key='', mistral_base='https://example.com', stt_model='model')
        results = [x async for x in client.ask_stream('hello')]
        self.assertEqual(len(results[-1]), 32000)

    async def test_parallel_free_requests_obey_cooldown(self):
        import asyncio
        from types import SimpleNamespace
        from unittest.mock import patch
        from bot.handlers import ai as handler
        from bot import plans
        started, release = asyncio.Event(), asyncio.Event()
        async def quota(*args):
            started.set()
            await release.wait()
            return False
        db = SimpleNamespace(get_settings=AsyncMock(return_value={'ai_on':1}), take_quota=AsyncMock(side_effect=quota))
        msg = SimpleNamespace(from_user=SimpleNamespace(id=5), chat=SimpleNamespace(id=9,type='group'), reply=AsyncMock())
        handler._last_ask.clear()
        with patch.object(handler.plans, 'plan_for', new=AsyncMock(return_value=plans.FREE)), \
             patch.object(handler.ux, 'tell', new=AsyncMock()):
            first = asyncio.create_task(handler._answer(msg, 'hello', db, SimpleNamespace(has_river=True), frozenset(), None))
            await started.wait()
            await handler._answer(msg, 'hello', db, SimpleNamespace(has_river=True), frozenset(), None)
            release.set()
            await first
        db.take_quota.assert_awaited_once()

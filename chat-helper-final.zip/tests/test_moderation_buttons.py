import os
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot import cas, dupes
from bot.handlers import premium

class ModerationButtonTests(unittest.IsolatedAsyncioTestCase):
    async def test_both_ban_buttons_respect_target_hierarchy(self):
        for module, prefix in ((cas, 'cas'), (dupes, 'dup')):
            with self.subTest(module=prefix):
                cb = SimpleNamespace(data=f'{prefix}:ban:123', message=SimpleNamespace(chat=SimpleNamespace(id=-1), edit_text=AsyncMock()),
                                     from_user=SimpleNamespace(id=9), answer=AsyncMock())
                db = SimpleNamespace(get_access=AsyncMock(return_value={}))
                bot = SimpleNamespace(ban_chat_member=AsyncMock())
                with patch.object(module.ms, 'effective_rank', new=AsyncMock(return_value=5)), \
                     patch.object(module.ms, 'can_act', new=AsyncMock(return_value=(False, 'Высокий ранг'))), \
                     patch.object(module.ms, 'apply', new=AsyncMock()) as apply:
                    await module.on_button(cb, bot, db)
                    apply.assert_not_awaited()
                    bot.ban_chat_member.assert_not_awaited()
                    self.assertEqual(cb.answer.await_args.args[0], 'Высокий ранг')

class PromoRateTests(unittest.TestCase):
    def tearDown(self):
        premium._promo_tries.clear()
    def test_full_tracker_does_not_reset_limits(self):
        import time
        now = time.monotonic()
        premium._promo_tries.update({i: [now] for i in range(20000)})
        premium._promo_tries[1] = [now] * premium.PROMO_TRIES
        self.assertFalse(premium._promo_rate_ok(20001))
        self.assertFalse(premium._promo_rate_ok(1))

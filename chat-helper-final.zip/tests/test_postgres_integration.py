"""Optional live PostgreSQL tests: set CHAT_HELPER_TEST_PG to a disposable database URI."""
import asyncio
import os
import sys
import unittest
import uuid
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.db import Database
from bot.handlers.economy import _settle_dice

@unittest.skipUnless(os.environ.get('CHAT_HELPER_TEST_PG'), 'CHAT_HELPER_TEST_PG is not set')
class PostgresIntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = await Database.connect(os.environ['CHAT_HELPER_TEST_PG'], schema='test_' + uuid.uuid4().hex)
        self.addAsyncCleanup(self.db.close)

    async def test_batch_counters_and_economy(self):
        for i in range(100):
            await self.db.record_message(1, i % 25, 3601)
        await self.db.flush_messages()
        row = await (await self.db.conn.execute('SELECT COUNT(*) AS n, SUM(n) AS total FROM msg_hourly')).fetchone()
        self.assertEqual((row['n'], row['total']), (25, 100))
        await _settle_dice(self.db, 1, 10, 20, 100, 10)
        self.assertEqual((await self.db.get_balance(1,10), await self.db.get_balance(1,20)), (1100,900))

    async def test_giveaway_concurrency_and_deadline(self):
        gid = await self.db.gw_new_draft(1, 2, 0)
        await self.db.gw_update(gid, status='active', ends_at=1000)
        await asyncio.gather(*(self.db.gw_check_new(gid, 3, f'code{i}', 200, 100) for i in range(10)))
        check = await self.db.gw_check_get(gid, 3)
        attempts = await asyncio.gather(*(self.db.gw_check_attempt(gid, 3, 5, check['answer'], 100) for _ in range(20)))
        self.assertEqual(sum(attempts), 5)
        self.assertTrue(await self.db.gw_join(gid, 3, 999))
        self.assertFalse(await self.db.gw_join(gid, 4, 1000))

    async def test_identity_flush_and_family_bonus(self):
        from bot.family import Family
        await self.db.remember_user(42, 'name', 'Name')
        await self.db.touch_member(10, 42, 100)
        await self.db.flush_messages()
        self.assertEqual(await self.db.user_name(42), 'Name')
        fam = Family(self.db)
        await fam.pairs.create(10, 1, 2, 100, 'marriage')
        self.assertEqual(await fam.claim_bonus(10, 1, 100), 300)
        self.assertIsNone(await fam.claim_bonus(10, 1, 100))

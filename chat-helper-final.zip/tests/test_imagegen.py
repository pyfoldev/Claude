import base64
import os
import sys
import unittest
from unittest.mock import patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from aiohttp import web, ClientSession
from aiohttp.test_utils import TestServer
from bot.imagegen import ImageGen, ImageError

class ImageGenTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.app = web.Application()
        self.response = lambda: web.Response(body=b'abc', content_type='image/png')
        async def handler(request):
            return self.response()
        self.app.router.add_post('/accounts/a/ai/run/model', handler)
        self.server = TestServer(self.app)
        await self.server.start_server()
        self.addAsyncCleanup(self.server.close)
        self.session = ClientSession()
        self.addAsyncCleanup(self.session.close)
        self.client = ImageGen(self.session, 'a', 'secret', 'model', str(self.server.make_url('/')).rstrip('/'))

    async def test_image_response(self):
        self.assertEqual(await self.client.generate('test'), b'abc')

    async def test_oversized_image_rejected(self):
        self.response = lambda: web.Response(body=b'12345', content_type='image/png')
        with patch('bot.imagegen.MAX_IMAGE_BYTES', 4):
            with self.assertRaises(ImageError):
                await self.client.generate('test')

    async def test_oversized_decoded_image_rejected(self):
        self.response = lambda: web.json_response({'success': True, 'result': {'image': base64.b64encode(b'12345').decode()}})
        with patch('bot.imagegen.MAX_IMAGE_BYTES', 4):
            with self.assertRaises(ImageError):
                await self.client.generate('test')

import os
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.db import Database
from bot.handlers import aimod

class UndoTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = await Database.connect(os.path.join(self.tmp.name, 'db'))
        self.addAsyncCleanup(self.db.close)
        self.addCleanup(self.tmp.cleanup)

    async def test_remove_only_matching_ai_warning(self):
        await self.db.add_warn(10, 20, now=100, actor=99, reason='ИИ [ai-msg:1]')
        await self.db.add_warn(10, 20, now=101, actor=5, reason='модератор')
        self.assertTrue(await self.db.remove_ai_warn(10,20,99,'[ai-msg:1]',102))
        cur = await self.db.conn.execute('SELECT actor FROM warn_events WHERE chat_id=10 AND user_id=20 AND (expires_at IS NULL OR expires_at>102)')
        self.assertEqual([row['actor'] for row in await cur.fetchall()], [5])

    async def test_undo_does_not_remove_newer_moderator_mute(self):
        eid = await self.db.add_aimod_event(10,20,1,'spam',90,'mute','text',100)
        await self.db.set_state(10,20,'mute',9999999999,'later moderator mute',5,101)
        cb = SimpleNamespace(data=f'aimod:{eid}', from_user=SimpleNamespace(id=6),
                             message=SimpleNamespace(edit_reply_markup=AsyncMock()), answer=AsyncMock())
        bot = SimpleNamespace(me=AsyncMock(return_value=SimpleNamespace(id=99)))
        with patch.object(aimod.ms, 'effective_rank', new=AsyncMock(return_value=5)), \
             patch.object(aimod.ms, 'apply', new=AsyncMock()) as apply:
            await aimod.error_button(cb,bot,self.db)
        apply.assert_not_awaited()
        self.assertIn('вручную', cb.answer.await_args.args[0])

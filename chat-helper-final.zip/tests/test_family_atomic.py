import asyncio
import os
import sys
import tempfile
import unittest
from unittest.mock import AsyncMock, patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.db import Database
from bot.family import Family
from bot.handlers.family import _apply

class FamilyAtomicTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = await Database.connect(os.path.join(self.tmp.name, 'test.db'))
        self.fam = Family(self.db)
        self.addAsyncCleanup(self.db.close)
        self.addCleanup(self.tmp.cleanup)

    async def test_bonus_flag_rolls_back_when_credit_fails(self):
        await self.fam.pairs.create(10, 1, 2, 100, 'marriage')
        with patch.object(self.db, 'change_balance', new=AsyncMock(side_effect=RuntimeError('failure'))):
            with self.assertRaises(RuntimeError):
                await self.fam.claim_bonus(10, 1, 100)
        self.assertEqual(await self.fam.claim_bonus(10, 1, 100), 300)
        self.assertEqual(await self.db.get_balance(10, 1), 1300)
        self.assertIsNone(await self.fam.claim_bonus(10, 1, 100))

    async def test_concurrent_relationships_cannot_share_one_member(self):
        with patch('bot.handlers.family._m', new=AsyncMock(return_value='User')):
            results = await asyncio.gather(_apply(self.db, self.fam, 'relation', 10, 1, 2, 100),
                                           _apply(self.db, self.fam, 'relation', 10, 1, 3, 100))
        cur = await self.db.conn.execute('SELECT COUNT(*) FROM pairs WHERE chat_id=? AND ended_at IS NULL', (10,))
        self.assertEqual((await cur.fetchone())[0], 1)
        self.assertEqual(sum('теперь пара' in r for r in results), 1)

    async def test_parallel_proposals_create_only_one_request(self):
        from types import SimpleNamespace
        from bot.handlers.family import _propose
        from unittest.mock import AsyncMock
        msgs = [SimpleNamespace(chat=SimpleNamespace(id=10), from_user=SimpleNamespace(id=1),
                                answer=AsyncMock(return_value=SimpleNamespace(message_id=20)), reply=AsyncMock()) for _ in range(2)]
        with patch('bot.handlers.family._m', new=AsyncMock(return_value='User')), \
             patch('bot.handlers.family.ux.tell', new=AsyncMock()):
            await asyncio.gather(*(_propose(m, None, self.db, self.fam, 'relation', 2, 100) for m in msgs))
        cur = await self.db.conn.execute('SELECT COUNT(*) FROM family_requests')
        self.assertEqual((await cur.fetchone())[0], 1)
        self.assertEqual(sum(m.answer.await_count for m in msgs), 1)

    async def test_failed_confirmation_keeps_request(self):
        from types import SimpleNamespace
        from bot.handlers.family import family_cb
        from unittest.mock import AsyncMock
        rid = await self.fam.create_request(10, 'relation', 1, 2, 20, 1000)
        cb = SimpleNamespace(data=f'fam:{rid}:yes', from_user=SimpleNamespace(id=2),
                             message=SimpleNamespace(chat=SimpleNamespace(id=10), message_id=20), answer=AsyncMock())
        with patch('bot.handlers.family.time.time', return_value=100), \
             patch('bot.handlers.family._apply', new=AsyncMock(side_effect=RuntimeError('failed'))):
            with self.assertRaises(RuntimeError):
                await family_cb(cb, self.db)
        self.assertIsNotNone(await self.fam.get_request(rid))

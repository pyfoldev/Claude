import os
import sys
import time
import unittest
from types import SimpleNamespace as N
from unittest.mock import AsyncMock, patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot import wipe
from bot.db import Database
from bot.handlers import moderation as mod, rulecmds


def msg(text, reply_user=None, uid=5):
    reply = N(from_user=N(id=reply_user), message_id=50, forum_topic_created=None) if reply_user else None
    return N(text=text, chat=N(id=-100, type='supergroup'), from_user=N(id=uid), message_id=60, reply_to_message=reply,
             message_thread_id=None, answer=AsyncMock(), reply=AsyncMock(), sender_chat=None)


class ModPlusTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = await Database.connect(':memory:')
        self.bot = N(delete_message=AsyncMock(), delete_messages=AsyncMock(), me=AsyncMock(return_value=N(id=1)))
        self.patches = [patch.object(mod.ms, 'can_act', new=AsyncMock(return_value=(True, ''))),
                        patch.object(mod.ms, 'apply', new=AsyncMock(return_value='готово'))]
        self.can, self.apply = [p.start() for p in self.patches]

    async def asyncTearDown(self):
        for p in self.patches:
            p.stop()
        await self.db.close()

    async def test_silent_ban_leaves_no_trace(self):
        m = msg('тбан 77777 "спам"')
        await mod.on_mod(m, self.bot, self.db)
        self.apply.assert_awaited_once()
        self.assertFalse(self.apply.await_args.kwargs['gif'])
        m.answer.assert_not_awaited()
        self.bot.delete_message.assert_awaited_with(-100, 60)                     # команда удалена

    async def test_dban_deletes_violators_message(self):
        m = msg('дбан', reply_user=777)
        await mod.on_mod(m, self.bot, self.db)
        self.bot.delete_message.assert_awaited_with(-100, 50)
        m.answer.assert_awaited()

    async def test_amnesty_lifts_all(self):
        now = int(time.time())
        await self.db.set_state(-100, 11, 'ban', None, 'x', 5, now)
        await self.db.set_state(-100, 12, 'mute', now + 999, 'x', 5, now)
        m = msg('амнистия')
        await mod.on_mod(m, self.bot, self.db)
        self.assertEqual(self.apply.await_count, 2)
        self.assertIn('2', m.answer.await_args.args[0])

    async def test_wipe_deletes_remembered_messages(self):
        wipe._seen.clear()
        now = int(time.time())
        for i in (1, 2, 3):
            wipe.remember(-100, 77777, i, now - 10)
        m = msg('вайп 77777')
        await mod.on_mod(m, self.bot, self.db)
        self.bot.delete_messages.assert_awaited_once_with(-100, [1, 2, 3])

    async def test_warn_limit_action_ban(self):
        # реальный apply: при лимите варнов действие берётся из настроек
        for p in self.patches:
            p.stop()
        from bot import mod_service as ms
        from bot.parsing import ModCommand
        await self.db.set_setting(-100, 'warn_limit', 1)
        await self.db.set_setting(-100, 'warn_action', 'ban')
        await self.db.set_setting(-100, 'warn_secs', 3600)
        bot = N(ban_chat_member=AsyncMock(), restrict_chat_member=AsyncMock(), unban_chat_member=AsyncMock(),
                get_chat_member=AsyncMock(return_value=N(user=N(first_name='V'))))
        text = await ms.apply(bot, self.db, ModCommand('варн', None, None, 'x'), -100, 5, 777, int(time.time()), gif=False)
        bot.ban_chat_member.assert_awaited_once()
        self.assertIn('бан', text)
        self.patches = [patch.object(mod.ms, 'can_act', new=AsyncMock()), patch.object(mod.ms, 'apply', new=AsyncMock())]
        for p in self.patches:
            p.start()

    async def test_default_mute_and_ban_from_settings(self):
        for p in self.patches:
            p.stop()
        from bot import mod_service as ms
        from bot.parsing import ModCommand
        await self.db.set_setting(-100, 'mute_secs', 7200)
        await self.db.set_setting(-100, 'ban_secs', 86400)
        bot = N(ban_chat_member=AsyncMock(), restrict_chat_member=AsyncMock(),
                get_chat_member=AsyncMock(return_value=N(user=N(first_name='V'))))
        now = int(time.time())
        await ms.apply(bot, self.db, ModCommand('мут', None, None, ''), -100, 5, 777, now, gif=False)
        self.assertEqual(bot.restrict_chat_member.await_args.kwargs['until_date'], now + 7200)
        await ms.apply(bot, self.db, ModCommand('бан', None, None, ''), -100, 5, 778, now, gif=False)
        self.assertEqual(bot.ban_chat_member.await_args.kwargs['until_date'], now + 86400)
        self.patches = [patch.object(mod.ms, 'can_act', new=AsyncMock()), patch.object(mod.ms, 'apply', new=AsyncMock())]
        for p in self.patches:
            p.start()


class RuleCmdTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = await Database.connect(':memory:')
        self.bot = N()
        self.p = patch.object(rulecmds.ms, 'effective_rank', new=AsyncMock(return_value=5))
        self.p.start()

    async def asyncTearDown(self):
        self.p.stop()
        await self.db.close()

    async def test_trigger_and_trusted_commands(self):
        m = msg('+триггер ссылка мут 1ч "реклама"')
        await rulecmds.on_rulecmd(m, self.bot, self.db)
        (t,) = await self.db.list_triggers(-100)
        self.assertEqual((t['event'], t['action'], t['secs'], t['reason']), ('ссылка', 'mute', 3600, 'реклама'))
        await rulecmds.on_rulecmd(msg('+доверять 77777'), self.bot, self.db)
        self.assertTrue(await self.db.is_trusted(-100, 77777))
        await rulecmds.on_rulecmd(msg('-триггер ссылка'), self.bot, self.db)
        self.assertEqual(await self.db.list_triggers(-100), [])

    async def test_period_defaults(self):
        await rulecmds.on_rulecmd(msg('мут период 2ч'), self.bot, self.db)
        await rulecmds.on_rulecmd(msg('бан период 7д'), self.bot, self.db)
        await rulecmds.on_rulecmd(msg('варны чс 3д'), self.bot, self.db)
        s = await self.db.get_settings(-100)
        self.assertEqual((s['mute_secs'], s['ban_secs'], s['warn_action'], s['warn_secs']), (7200, 604800, 'ban', 259200))

    async def test_night_and_faq_and_periodic(self):
        await rulecmds.on_rulecmd(msg('ночной режим 23-7'), self.bot, self.db)
        s = await self.db.get_settings(-100)
        self.assertEqual((s['night_on'], s['night_from'], s['night_to']), (1, 23, 7))
        await rulecmds.on_rulecmd(msg('+faq где правила = читай закреп'), self.bot, self.db)
        self.assertEqual((await self.db.list_faq(-100))[0]['keyword'], 'где правила')
        await rulecmds.on_rulecmd(msg('+повтор 6ч не флудим'), self.bot, self.db)
        self.assertEqual((await self.db.list_periodic(-100))[0]['every'], 21600)

    async def test_denied_without_rank(self):
        with patch.object(rulecmds.ms, 'effective_rank', new=AsyncMock(return_value=0)):
            await rulecmds.on_rulecmd(msg('+триггер капс варн'), self.bot, self.db)
        self.assertEqual(await self.db.list_triggers(-100), [])

    async def test_grid_global_ban(self):
        await self.db.grid_add(-100, 5, 1)
        await self.db.grid_add(-200, 5, 1)
        bot = N(ban_chat_member=AsyncMock())
        with patch.object(rulecmds.ms, 'get_member', new=AsyncMock(return_value=N(status='member'))):
            m = msg('глобан 77777')
            await rulecmds.on_rulecmd(m, bot, self.db)
        self.assertEqual(bot.ban_chat_member.await_count, 2)


if __name__ == '__main__':
    unittest.main()

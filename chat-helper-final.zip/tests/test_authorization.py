import os
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot import mod_service as ms
from bot.handlers import suggest, logchat

class AuthorizationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        ms._members.clear()
        self.db = SimpleNamespace(get_rank=AsyncMock(return_value=5), get_access=AsyncMock(return_value={}))

    async def test_saved_rank_does_not_authorize_former_member(self):
        for member in (SimpleNamespace(status='left'), SimpleNamespace(status='kicked'),
                       SimpleNamespace(status='restricted', is_member=False)):
            with patch.object(ms, 'get_member', new=AsyncMock(return_value=member)):
                self.assertEqual(await ms.effective_rank(None, self.db, 1, 2), 0)
                ok, _ = await ms.can_act(None, 1, 2, None, 'restrict', db=self.db, command='бан')
                self.assertFalse(ok)

    async def test_membership_failure_does_not_grant_rank(self):
        with patch.object(ms, 'get_member', new=AsyncMock(side_effect=RuntimeError('network'))):
            self.assertEqual(await ms.effective_rank(None, self.db, 1, 2), 0)

    async def test_suggestion_result_uses_authorized_chat(self):
        cb = SimpleNamespace(data='sga:9:acc:999:0:new', from_user=SimpleNamespace(id=7),
                             message=SimpleNamespace(edit_text=AsyncMock()), answer=AsyncMock())
        db = SimpleNamespace(sugg_get=AsyncMock(return_value={'id':9, 'chat_id':1, 'user_id':2}),
                             get_chat=AsyncMock(return_value={'title':'Чат'}), sugg_decide=AsyncMock(return_value=True))
        with patch.object(suggest, 'can_view', new=AsyncMock(return_value=True)), \
             patch.object(suggest, '_notify', new=AsyncMock()), \
             patch.object(suggest, '_card', new=AsyncMock(return_value=('ok', None))) as card:
            await suggest.action_cb(cb, None, db)
            self.assertEqual(card.await_args.args[1], 1)

    async def test_log_title_is_escaped(self):
        bot = SimpleNamespace(get_chat_member=AsyncMock(return_value=SimpleNamespace(status='creator')), send_message=AsyncMock())
        db = SimpleNamespace(set_setting=AsyncMock())
        ok, _ = await logchat.connect_log_chat(bot, db, 1, '<broken & title>', 2, 3)
        self.assertTrue(ok)
        self.assertIn('&lt;broken &amp; title&gt;', bot.send_message.await_args.args[1])

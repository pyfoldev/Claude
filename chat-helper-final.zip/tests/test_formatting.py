import html
import os
import sys
import unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.fmt import escaped_clip

class FormattingTests(unittest.TestCase):
    def test_html_entities_are_never_truncated(self):
        value = escaped_clip('&' * 3000, 4000, 3900)
        self.assertLessEqual(len(value), 4000)
        self.assertEqual(value, html.escape(html.unescape(value)))

    def test_utf16_limit_for_emoji(self):
        value = escaped_clip('😀' * 3000, 4000, 3900)
        self.assertLessEqual(len(value.encode('utf-16-le')) // 2, 3900)

import os
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.backup import rotate

class BackupTests(unittest.TestCase):
    def test_rotation_only_removes_known_regular_backups(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)
            old = p / 'bot-backup-20250101-000000.db'
            new = p / 'bot-backup-20260101-000000.db'
            unrelated = p / 'bot-backup-important.db'
            for file in (old, new, unrelated): file.write_text('data')
            link = p / 'bot-backup-20200101-000000.db'
            link.symlink_to(unrelated)
            self.assertEqual(rotate(d, 1), 1)
            self.assertFalse(old.exists())
            self.assertTrue(new.exists())
            self.assertTrue(unrelated.exists())
            self.assertTrue(link.is_symlink())

import asyncio
import os
import sys
import time
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot.nsfw import NsfwDetector, NsfwScanError
from bot.handlers import images
from bot import plans

class ScanTests(unittest.IsolatedAsyncioTestCase):
    async def test_failed_or_empty_scan_does_not_return_safe_score(self):
        detector = NsfwDetector()
        with self.assertRaises(NsfwScanError):
            await detector.score_images([])
        with patch.object(detector, 'score_image', side_effect=ValueError('broken')):
            with self.assertRaises(NsfwScanError):
                await detector.score_images([b'bad'])

    async def test_model_loaded_once_for_parallel_calls(self):
        created = []
        def factory():
            time.sleep(.02)
            item = object()
            created.append(item)
            return item
        detector = NsfwDetector()
        with patch.dict(sys.modules, {'nudenet':SimpleNamespace(NudeDetector=factory)}):
            result = await asyncio.gather(*(asyncio.to_thread(detector._load) for _ in range(12)))
        self.assertEqual(len(created), 1)
        self.assertTrue(all(x is created[0] for x in result))

    async def test_generated_image_is_not_sent_if_scan_fails(self):
        msg = SimpleNamespace(from_user=SimpleNamespace(id=10), chat=SimpleNamespace(id=20),
                              text='нарисуй кота', reply=AsyncMock(), reply_photo=AsyncMock())
        db = SimpleNamespace(take_quota=AsyncMock(return_value=True), refund_quota=AsyncMock())
        gen = SimpleNamespace(configured=True, generate=AsyncMock(return_value=b'image'))
        detector = SimpleNamespace(score_images=AsyncMock(side_effect=NsfwScanError('failed')))
        images._last.clear()
        with patch.object(images.plans, 'plan_for', new=AsyncMock(return_value=plans.FREE)), \
             patch.object(images.perf, 'chat_action'):
            await images.draw_cmd(msg, None, db, imagegen=gen, detector=detector)
        msg.reply_photo.assert_not_awaited()
        self.assertIn('Не удалось проверить', msg.reply.await_args.args[0])
        self.assertEqual(db.refund_quota.await_args.args[1], 'uimg')

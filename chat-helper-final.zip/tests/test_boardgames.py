import asyncio
import os
import random
import sys
import unittest
from types import SimpleNamespace as N
from unittest.mock import AsyncMock
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from bot import boardgames as bgm
from bot.db import Database
from bot.games import checkers as ck, chessgame as cg, seabattle as sb
from bot.handlers import boardgames as h


class EngineTests(unittest.TestCase):
    def test_chess_perft(self):
        s = cg.State()
        self.assertEqual([cg.perft(s, d) for d in (1, 2, 3)], [20, 400, 8902])

    def test_chess_special_rules(self):
        # рокировка и взятие на проходе: позиция «Kiwipete» даёт 48 ходов
        b = "r   k  r" + "p ppqpb " + "bn  pnp " + "   PN   " + " p  P   " + "  N  Q p" + "PPPBBPPP" + "R   K  R"
        self.assertEqual(len(cg.legal_moves(cg.State(b, "w", "KQkq"))), 48)

    def test_checkers_mandatory_capture(self):
        b = [" "] * 64
        b[42], b[35], b[56] = "w", "b", "w"           # белая на c3 бьёт чёрную на d4; вторая белая ходить не может
        self.assertEqual(list(ck.legal_moves(b, "w")), [42])
        self.assertEqual(ck.legal_moves(b, "w")[42], [(28, 35)])

    def test_sea_never_overlaps(self):
        for seed in range(100):
            cells = [c for s in sb.place_fleet(random.Random(seed)) for c in s]
            self.assertEqual(len(cells), len(set(cells)))

    def test_full_random_games_finish(self):
        for game in ("chess", "checkers", "sea"):
            rnd = random.Random(7)
            d = bgm.init_game(game, rnd)
            res = None
            for _ in range(3000):
                i = d["turn"]
                if game == "chess":
                    mv = rnd.choice(cg.legal_moves(bgm.chess_state(d)))
                    bgm.press(d, i, mv[0]); res = bgm.press(d, i, mv[1])
                elif game == "checkers":
                    mvs = ck.legal_moves(bgm.checkers_board(d), bgm.SIDE[i], d["lock"])
                    src = rnd.choice(list(mvs)); bgm.press(d, i, src); res = bgm.press(d, i, rnd.choice(mvs[src])[0])
                else:
                    free = [c for c in range(64) if str(c) not in bgm.sea_target(d)["shots"]]
                    res = bgm.press(d, i, rnd.choice(free))
                if res:
                    break
            self.assertIsNotNone(res, game)

    def test_turn_order_and_draw_offer(self):
        d = bgm.init_game("chess")
        with self.assertRaises(bgm.MoveError):
            bgm.press(d, 1, 12)
        self.assertIsNone(bgm.offer_draw(d, 0))
        self.assertIsNone(bgm.offer_draw(d, 0))       # повторное нажатие отзывает
        self.assertIsNone(bgm.offer_draw(d, 1))
        self.assertEqual(bgm.offer_draw(d, 0)["why"], "ничья по согласию")


class HandlerTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = await Database.connect(':memory:')

    async def asyncTearDown(self):
        await self.db.close()

    def cb(self, data, uid, msg_id=5, chat=-100):
        msg = N(chat=N(id=chat), message_id=msg_id, edit_text=AsyncMock())
        return N(data=data, from_user=N(id=uid, full_name=f'U{uid}'), message=msg, answer=AsyncMock())

    async def test_lobby_accept_move_resign(self):
        d = bgm.init_game('chess')
        d.update(id='g1', chat_id=-100, state='invite', players=[{'id': 1, 'name': 'A'}, None], message_id=5,
                 expires_at=9999999999)
        await self.db.save_bgame(d)
        await h.on_press(self.cb('bg:g1:acc', 1), self.db)                       # автор не может принять
        self.assertEqual((await self.db.get_bgame('g1'))['state'], 'invite')
        await h.on_press(self.cb('bg:g1:acc', 2), self.db)
        self.assertEqual((await self.db.get_bgame('g1'))['state'], 'play')
        await h.on_press(self.cb('bg:g1:s:52', 2), self.db)                      # не его ход
        await h.on_press(self.cb('bg:g1:s:52', 1), self.db)                      # e2
        await h.on_press(self.cb('bg:g1:s:36', 1), self.db)                      # e4
        g = await self.db.get_bgame('g1')
        self.assertEqual(g['turn'], 1)
        self.assertEqual(g['last'], 'e2–e4')
        c = self.cb('bg:g1:res', 2)
        await h.on_press(c, self.db)
        self.assertIsNone(await self.db.get_bgame('g1'))
        self.assertIn('Победил', c.message.edit_text.await_args.args[0])

    async def test_keyboards_render_for_all_games(self):
        for game in ('chess', 'checkers', 'sea'):
            d = bgm.init_game(game)
            d.update(id='x', players=[{'id': 1, 'name': 'A'}, {'id': 2, 'name': 'B'}])
            kb = h.play_keyboard(d)
            total = sum(len(r) for r in kb.inline_keyboard)
            self.assertLessEqual(total, 100)
            self.assertTrue(all(len(r) <= 8 for r in kb.inline_keyboard))
            self.assertIn('Ход', h.play_text(d))

    async def test_timeout_loses(self):
        d = bgm.init_game('checkers')
        self.assertEqual(bgm.timeout_result(d)['winner'], 1)


if __name__ == '__main__':
    unittest.main()

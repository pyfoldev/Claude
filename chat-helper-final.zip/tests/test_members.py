import os
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'source'))
from aiogram.exceptions import TelegramBadRequest
from bot import members

class MembersTests(unittest.IsolatedAsyncioTestCase):
    async def test_chat_error_does_not_deactivate_member(self):
        bot = SimpleNamespace(get_chat_member=AsyncMock(side_effect=TelegramBadRequest(method=None, message='Bad Request: chat not found')))
        db = SimpleNamespace(set_member_active=AsyncMock())
        self.assertIsNone(await members.check(bot, db, -100, 123))
        db.set_member_active.assert_not_awaited()

    async def test_user_not_found_deactivates_member(self):
        bot = SimpleNamespace(get_chat_member=AsyncMock(side_effect=TelegramBadRequest(method=None, message='Bad Request: user not found')))
        db = SimpleNamespace(set_member_active=AsyncMock())
        self.assertFalse(await members.check(bot, db, -100, 123))
        db.set_member_active.assert_awaited_once_with(-100, 123, False)

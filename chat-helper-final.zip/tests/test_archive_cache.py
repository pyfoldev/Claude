import os
import subprocess
import sys
import tempfile
import unittest
import zipapp
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

class ArchiveCacheTests(unittest.TestCase):
    def test_cache_rejects_world_writable_directory(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            source = root / 'src'
            source.mkdir()
            (source / '__main__.py').write_bytes((ROOT / 'source' / '__main__.py').read_bytes())
            (source / 'bot').mkdir()
            (source / 'bot' / '__init__.py').write_text('')
            (source / 'bot' / 'main.py').write_text('print("launched")')
            archive = root / 'bot.pyz'
            zipapp.create_archive(source, archive)
            cache = root / 'cache'
            cache.mkdir(mode=0o777)
            cache.chmod(0o777)
            env = dict(os.environ, CHAT_HELPER_CACHE=str(cache))
            result = subprocess.run([sys.executable, str(archive)], env=env, text=True, capture_output=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('Небезопасный каталог кэша', result.stderr)
            cache.chmod(0o700)
            result = subprocess.run([sys.executable, str(archive)], env=env, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn('launched', result.stdout)
